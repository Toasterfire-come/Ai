#!/usr/bin/env python3
"""
Build Feature Matrix — merge all data sources into one training-ready parquet.

Sources merged:
  p_*  — Price + technical indicators (from price_collector)
  f_*  — Fundamentals / financial ratios (from SEC XBRL company facts)
  n_*  — News sentiment readings (from news_collector)
  m_*  — Macro economic indicators (from macro_collector: FRED + SPY/QQQ)
  s_*  — Sector ETF returns (from macro_collector)
  i_*  — Insider trade counts (from form4_collector)
  a_*  — Analyst consensus (from analyst_collector)

Output: data/feature_matrix.parquet (~100+ feature columns, one row per ticker-date)
"""
import sys, gc, os
from pathlib import Path
from datetime import datetime

import numpy as np
import pandas as pd
import pyarrow.parquet as pq

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from stockpredict2.config import (
    DATA_DIR, FM_PATH, PRICES_DIR, FINANCIALS_DIR,
    NEWS_AGG_DIR, MACRO_DIR, FORM4_DIR, ANALYST_DIR,
    CLASS_BOUNDARIES, PREDICTION_HORIZON_DAYS, COMMON_WORD_TICKERS
)
from stockpredict2.collectors.ticker_list import get_ticker_symbols


def build_feature_matrix(force: bool = False, n_tickers: int = None) -> dict:
    """Build the feature matrix from all available data sources."""

    print(f"\n{'='*60}")
    print("  BUILDING FEATURE MATRIX")
    print(f"  Merging all data sources into one flat table")
    print(f"{'='*60}\n")

    if FM_PATH.exists() and not force:
        print(f"  Feature matrix exists at {FM_PATH}")
        print(f"  Use force=True to rebuild")
        pf = pq.ParquetFile(str(FM_PATH))
        print(f"  Current: {pf.metadata.num_rows:,} rows x {len(pf.schema_arrow)} cols")
        return {"rows": pf.metadata.num_rows, "cols": len(pf.schema_arrow)}

    tickers = get_ticker_symbols()
    if n_tickers:
        tickers = tickers[:n_tickers]

    print(f"  Tickers in universe: {len(tickers)}")
    print(f"  Date range: 2016 to {datetime.today().year}\n")

    # ── Load price data (the backbone — all other sources merge to this) ──
    print("1. Loading price data...")
    all_prices = []
    price_tickers_found = 0
    for t in tickers:
        path = PRICES_DIR / f"{t}.parquet"
        if not path.exists():
            continue
        df = pd.read_parquet(path)
        if df.empty or "date" not in df.columns or "close" not in df.columns:
            continue
        df["ticker"] = t
        all_prices.append(df[["ticker", "date", "open", "high", "low", "close",
                              "volume", "adj_close"]].copy())
        price_tickers_found += 1

    if not all_prices:
        print("  No price data found! Run pipeline prices first.")
        return {"error": "no price data"}

    fm = pd.concat(all_prices, ignore_index=True)
    fm["date"] = pd.to_datetime(fm["date"])
    fm = fm.sort_values(["ticker", "date"])
    print(f"  Price backbone: {len(fm):,} rows, {price_tickers_found}/{len(tickers)} tickers")
    del all_prices; gc.collect()

    # ── Compute technical indicators ──
    print("   Computing technical indicators per ticker...")
    for ticker, group in fm.groupby("ticker"):
        grp = group.sort_values("date")
        close = grp["close"].astype(float)

        # Rolling windows
        for w in [10, 20, 50, 200]:
            fm.loc[grp.index, f"p_sma_{w}"] = close.rolling(w).mean().values
        fm.loc[grp.index, "p_ema_12"] = close.ewm(span=12, adjust=False).mean().values
        fm.loc[grp.index, "p_ema_26"] = close.ewm(span=26, adjust=False).mean().values
        fm.loc[grp.index, "p_macd"] = (fm.loc[grp.index, "p_ema_12"].values
                                        - fm.loc[grp.index, "p_ema_26"].values)
        fm.loc[grp.index, "p_macd_signal"] = pd.Series(
            fm.loc[grp.index, "p_macd"].values
        ).ewm(span=9, adjust=False).mean().values

        # RSI
        delta = close.diff()
        gain = delta.where(delta > 0, 0.0).rolling(14).mean()
        loss = (-delta.where(delta < 0, 0.0)).rolling(14).mean()
        rs = gain / loss.replace(0, 1e-10)
        fm.loc[grp.index, "p_rsi_14"] = (100 - 100 / (1 + rs)).values

        # Bollinger Band width
        bb_mid = close.rolling(20).mean()
        bb_std = close.rolling(20).std()
        fm.loc[grp.index, "p_bb_width"] = (2 * bb_std / bb_mid.replace(0, 1e-10)).values

        # ATR
        high_low = grp["high"].astype(float) - grp["low"].astype(float)
        high_close = (grp["high"].astype(float) - close.shift(1)).abs()
        low_close = (grp["low"].astype(float) - close.shift(1)).abs()
        tr = pd.concat([high_low, high_close, low_close], axis=1).max(axis=1)
        fm.loc[grp.index, "p_atr_14"] = tr.rolling(14).mean().values

        # Volume
        vol = grp["volume"].astype(float)
        fm.loc[grp.index, "p_vol_sma_20"] = vol.rolling(20).mean().values
        fm.loc[grp.index, "p_vol_ratio"] = (vol / fm.loc[grp.index, "p_vol_sma_20"].replace(0, 1)).values

        # Returns
        fm.loc[grp.index, "p_pct_change_1d"] = close.pct_change().values * 100
        fm.loc[grp.index, "p_pct_change_5d"] = close.pct_change(5).values * 100
        fm.loc[grp.index, "p_pct_change_21d"] = close.pct_change(21).values * 100
        fm.loc[grp.index, "p_pct_change_63d"] = close.pct_change(63).values * 100

        # Volatility
        fm.loc[grp.index, "p_volatility_21d"] = fm.loc[grp.index, "p_pct_change_1d"].rolling(21).std().values
        fm.loc[grp.index, "p_volatility_63d"] = fm.loc[grp.index, "p_pct_change_1d"].rolling(63).std().values

    # Drop rows without enough history
    before = len(fm)
    fm = fm.dropna(subset=["p_sma_50", "p_rsi_14", "p_vol_sma_20"])
    print(f"   Technical indicators: {len(fm):,} rows (dropped {before - len(fm):,} without enough history)")

    # ── Merge financials (SEC XBRL) ──
    print("2. Loading fundamentals...")
    fin_cols = ["f_gross_margin", "f_op_margin", "f_net_margin", "f_roe", "f_roa",
                "f_revenue", "f_cost_of_revenue", "f_gross_profit", "f_sga_expense",
                "f_research_development", "f_net_income", "f_eps", "f_equity",
                "f_total_assets", "f_current_assets", "f_cash", "f_total_liabilities",
                "f_current_liabilities", "f_long_term_debt", "f_total_equity",
                "f_retained_earnings", "f_operating_cash_flow", "f_capex",
                "f_free_cash_flow", "f_shares_outstanding"]
    for c in fin_cols:
        fm[c] = np.nan

    fin_tickers = 0
    for ticker, group in fm.groupby("ticker"):
        fin_path = FINANCIALS_DIR / f"{ticker}.parquet"
        if not fin_path.exists():
            continue
        fin_df = pd.read_parquet(fin_path)
        if fin_df.empty or "date" not in fin_df.columns:
            continue
        fin_df["date"] = pd.to_datetime(fin_df["date"])
        fin_tickers += 1

        # SEC XBRL data is quarterly — forward fill to daily
        for concept in fin_df.columns:
            if concept in ("date", "fp", "ticker"):
                continue
            # Merge: for each date in the price data, use the most recent quarterly value
            for _, row in fin_df.iterrows():
                q_date = row["date"]
                mask = (group["date"] >= q_date) & (group["date"] < q_date + pd.Timedelta(days=95))
                idx = group.index[mask]
                if len(idx) > 0:
                    val = row[concept]
                    if val is not None:
                        try:
                            fm.loc[idx, f"f_{concept}"] = float(val)
                        except (ValueError, TypeError):
                            pass
            # Also assign to the quarter date itself
            for _, row in fin_df.iterrows():
                mask = group["date"] == row["date"]
                idx = group.index[mask]
                if len(idx) > 0:
                    for concept in fin_df.columns:
                        if concept in ("date", "fp", "ticker"):
                            continue
                        val = row[concept]
                        if val is not None:
                            try:
                                fm.loc[idx, f"f_{concept}"] = float(val)
                            except (ValueError, TypeError):
                                pass

    print(f"   Fundamentals: {fin_tickers} tickers with data")

    # ── Merge news sentiment ──
    print("3. Loading news sentiment...")
    news_tickers = 0
    fm["n_sentiment_pos"] = 0.0
    fm["n_sentiment_neg"] = 0.0
    fm["n_sentiment_neu"] = 0.0
    fm["n_article_count"] = 0

    for ticker, group in fm.groupby("ticker"):
        news_path = NEWS_AGG_DIR / f"{ticker}.parquet"
        if not news_path.exists():
            continue
        news_df = pd.read_parquet(news_path)
        if news_df.empty or "date" not in news_df.columns:
            continue
        news_df["date"] = pd.to_datetime(news_df["date"])
        news_tickers += 1

        for _, row in news_df.iterrows():
            ndate = row["date"]
            # Match to nearest trading day
            match = group[group["date"] == ndate]
            if len(match) > 0:
                idx = match.index
                fm.loc[idx, "n_sentiment_pos"] = row.get("sentiment_pos_mean",
                                                          row.get("sentiment_pos", 0))
                fm.loc[idx, "n_sentiment_neg"] = row.get("sentiment_neg_mean",
                                                          row.get("sentiment_neg", 0))
                fm.loc[idx, "n_sentiment_neu"] = row.get("sentiment_neu_mean",
                                                          row.get("sentiment_neu", 0))
                fm.loc[idx, "n_article_count"] = row.get("article_count", 1)

    print(f"   News sentiment: {news_tickers} tickers")

    # ── Merge macro data ──
    print("4. Loading macro indicators...")
    macro_path = MACRO_DIR / "master_macro.parquet"
    if macro_path.exists():
        macro_df = pd.read_parquet(macro_path)
        macro_df["date"] = pd.to_datetime(macro_df["date"])
        # Rename macro columns with m_ prefix
        macro_rename = {c: f"m_{c}" for c in macro_df.columns if c != "date"}
        macro_df = macro_df.rename(columns=macro_rename)
        fm = fm.merge(macro_df, on="date", how="left")
        # Forward fill
        macro_fill = [c for c in fm.columns if c.startswith("m_")]
        fm[macro_fill] = fm[macro_fill].ffill().bfill().fillna(0)
        print(f"   Macro: {len(macro_fill)} columns")

    # ── Merge insider trades ──
    print("5. Loading insider trades...")
    insider_path = FORM4_DIR / "form4_all.parquet"
    if insider_path.exists():
        insider_df = pd.read_parquet(insider_path)
        fm["i_buys_90d"] = 0
        fm["i_sells_90d"] = 0
        for ticker, group in fm.groupby("ticker"):
            ticker_insider = insider_df[insider_df["ticker"] == ticker]
            if ticker_insider.empty:
                continue
            ticker_insider = ticker_insider.copy()
            ticker_insider["transaction_date"] = pd.to_datetime(ticker_insider["transaction_date"])
            for i, row in group.iterrows():
                recent = ticker_insider[
                    (ticker_insider["transaction_date"] > row["date"] - pd.Timedelta(days=90)) &
                    (ticker_insider["transaction_date"] <= row["date"])
                ]
                fm.at[i, "i_buys_90d"] = len(recent[recent["transaction_type"] == "Buy"])
                fm.at[i, "i_sells_90d"] = len(recent[recent["transaction_type"] == "Sell"])
        print(f"   Insider trades: loaded")

    # ── Merge analyst consensus ──
    print("6. Loading analyst consensus...")
    for ticker in fm["ticker"].unique():
        analyst_path = ANALYST_DIR / f"{ticker}.parquet"
        if not analyst_path.exists():
            continue
        analyst_df = pd.read_parquet(analyst_path)
        if analyst_df.empty:
            continue
        # Forward fill price target data to all rows for this ticker
        mask = fm["ticker"] == ticker
        if "mean_price_target" in analyst_df.columns:
            pt = analyst_df["mean_price_target"].iloc[0]
            if pt and pt > 0:
                close_vals = fm.loc[mask, "close"].astype(float).replace(0, np.nan)
                fm.loc[mask, "a_target_upside_pct"] = (pt / close_vals - 1) * 100
        if "recommendation" in analyst_df.columns:
            rec = analyst_df["recommendation"].iloc[0]
            rec_map = {"Strong Buy": 4, "Buy": 3, "Hold": 2, "Underperform": 1, "Sell": 0}
            fm.loc[mask, "a_recommendation"] = rec_map.get(str(rec).strip(), 2)

    print(f"   Analyst data merged")

    # ── Compute target labels (forward 63-day return) ──
    print(f"\n7. Computing target labels ({PREDICTION_HORIZON_DAYS}d forward return)...")
    fm["pct_change_target"] = np.nan
    fm["class_label"] = -1

    for ticker, group in fm.groupby("ticker"):
        group = group.sort_values("date")
        dates = group["date"].values
        closes = group["close"].astype(float).values

        for i in range(len(closes) - PREDICTION_HORIZON_DAYS):
            # Forward N-day return from current close to close N days ahead
            future_close = closes[i + PREDICTION_HORIZON_DAYS]
            if future_close > 0 and closes[i] > 0:
                fwd_return = (future_close - closes[i]) / closes[i] * 100
                fwd_return = np.clip(fwd_return, -500, 500)
                idx = group.index[i]
                fm.at[idx, "pct_change_target"] = fwd_return

                # Class label
                if fwd_return < CLASS_BOUNDARIES[0]:
                    fm.at[idx, "class_label"] = 0  # super_negative
                elif fwd_return < CLASS_BOUNDARIES[1]:
                    fm.at[idx, "class_label"] = 1  # negative
                elif fwd_return < CLASS_BOUNDARIES[2]:
                    fm.at[idx, "class_label"] = 2  # neutral
                elif fwd_return < CLASS_BOUNDARIES[3]:
                    fm.at[idx, "class_label"] = 3  # positive
                else:
                    fm.at[idx, "class_label"] = 4  # super_positive

    # Drop rows without a target label (most recent N days)
    target_count = fm["class_label"].ge(0).sum()
    print(f"   Labels computed for {target_count:,} rows "
          f"({len(fm) - target_count:,} trailing rows dropped)")

    if target_count < 1000:
        print("  Warning: very few labeled rows — need more price history")
        return {"error": "insufficient labeled data"}

    # ── Final cleanup and save ──
    print(f"\n8. Final cleanup...")

    # Remove rows with insufficient features
    before = len(fm)
    fm = fm.dropna(subset=["p_sma_10", "p_rsi_14", "p_volatility_21d"]).copy()
    print(f"   Dropped {before - len(fm):,} rows with insufficient features")

    # Ensure all remaining rows have a target
    fm = fm[fm["class_label"] >= 0].copy()

    # Fill remaining NaN values
    feature_cols = [c for c in fm.columns
                    if c not in ("ticker", "date", "open", "high", "low", "close",
                                 "volume", "adj_close")]
    fm[feature_cols] = fm[feature_cols].fillna(0)

    # Class distribution
    class_dist = fm["class_label"].value_counts().sort_index()
    print(f"   Class distribution: {dict(zip(['super_neg','neg','neutral','pos','super_pos'], class_dist.tolist()))}")

    # Save
    fm = fm.sort_values(["date", "ticker"])
    fm.to_parquet(str(FM_PATH), index=False, compression="snappy")

    final_cols = [c for c in fm.columns
                  if c not in ("ticker", "date", "pct_change_target", "class_label")]
    print(f"\n{'='*60}")
    print(f"  FEATURE MATRIX COMPLETE")
    print(f"  {len(fm):,} rows x {len(fm.columns)} columns")
    print(f"  {len(final_cols)} features for training")
    print(f"  Saved: {FM_PATH}")
    print(f"  Size: {FM_PATH.stat().st_size / 1024 / 1024:.1f} MB")
    print(f"{'='*60}")

    return {
        "rows": len(fm),
        "cols": len(fm.columns),
        "features": len(final_cols),
        "tickers": fm["ticker"].nunique(),
        "date_range": f"{fm['date'].min()} to {fm['date'].max()}",
        "target_dist": class_dist.tolist(),
    }


if __name__ == "__main__":
    build_feature_matrix(force=True)