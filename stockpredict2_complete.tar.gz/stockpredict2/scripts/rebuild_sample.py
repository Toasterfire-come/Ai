#!/usr/bin/env python3
"""Rebuild training sample with full 2016-2026 data + sector z-score features."""
import pyarrow.parquet as pq
import pandas as pd, numpy as np, json, os, sys

sys.path.insert(0, '/Users/ckiefer/Documents/AI Training')
from stockpredict2.config import FM_PATH

TICKER_COLS = ['p_sma_10','p_sma_20','p_sma_50','p_sma_200','p_ema_12','p_ema_26',
               'p_macd','p_macd_signal','p_rsi_14','p_bb_width','p_atr_14',
               'p_vol_sma_20','p_vol_ratio','p_pct_change_1d','p_pct_change_5d',
               'p_pct_change_21d','p_volatility_21d','p_volatility_63d',
               'f_gross_margin','f_op_margin','f_net_margin','f_roe','f_roa',
               'f_revenue','f_net_income','f_eps','f_equity','f_total_assets',
               'f_free_cash_flow',
               'n_sentiment_pos','n_sentiment_neg','n_sentiment_neu','n_article_count',
               'i_buys_90d','i_sells_90d']

MACRO_COLS = ['m_SPY_CLOSE','m_SPY_RET_5D','m_SPY_RET_21D','m_VIX_CLOSE',
              'm_VIX_PCTILE_252','m_QQQ_CLOSE','m_IWM_CLOSE','m_TNX_CLOSE',
              'm_IRX_CLOSE','m_YIELD_SPREAD_10Y_3M','m_QQQ_SPY_RATIO','m_IWM_SPY_RATIO',
              'm_SECTOR_XLF_RET_5D','m_SECTOR_XLK_RET_5D','m_SECTOR_XLV_RET_5D',
              'm_SECTOR_XLI_RET_5D','m_SECTOR_XLP_RET_5D','m_SECTOR_XLE_RET_5D',
              'm_SECTOR_XLU_RET_5D','m_SECTOR_XLB_RET_5D','m_SECTOR_XLRE_RET_5D',
              'm_SECTOR_XLC_RET_5D','m_SECTOR_XLY_RET_5D']

REQUIRED = ['date','ticker','pct_change_target']
COLS = REQUIRED + TICKER_COLS + MACRO_COLS
OUT = '/Users/ckiefer/Documents/AI Training/stockpredict2/data/training_sample.parquet'

print("Building full 2016-2026 training sample...")
pf = pq.ParquetFile(str(FM_PATH))
ng = pf.metadata.num_row_groups
print(f"Row groups: {ng}")

# Load sector map
sector_map = {}
sector_path = '/Users/ckiefer/Documents/AI Training/stockpredict2/data/ticker_sector.json'
if os.path.exists(sector_path):
    with open(sector_path) as f:
        sector_map = json.load(f)
    print(f"Sector map: {sum(1 for v in sector_map.values() if v != 'Unknown')} mapped")

# Load S&P 500 as fallback
import requests
try:
    resp = requests.get('https://raw.githubusercontent.com/datasets/s-and-p-500-companies/main/data/constituents.csv', timeout=10)
    if resp.status_code == 200:
        for line in resp.text.strip().split('\n')[1:]:
            parts = line.split(',')
            if len(parts) >= 3:
                sector_map.setdefault(parts[0], parts[2])
    print(f"S&P sectors added: {len([t for t in sector_map if sector_map[t] != 'Unknown'])} total")
except Exception as e:
    print(f"S&P fallback: {e}")

# Read all years, subsample per year for balance
parts = []
total_target = 500000
samples_per_group = max(1, total_target // ng)

for i in range(ng):
    table = pf.read_row_group(i, columns=COLS)
    df = table.to_pandas()
    df['date'] = pd.to_datetime(df['date'])
    df['pct_change_target'] = np.clip(df['pct_change_target'].astype(np.float32), -500, 500)
    df = df.dropna(subset=['pct_change_target'])

    # Add sector column
    df['sector'] = df['ticker'].map(sector_map).fillna('Unknown')

    if len(df) > samples_per_group:
        df = df.sample(n=samples_per_group, random_state=42 + i)
    parts.append(df)
    if (i + 1) % 6 == 0:
        print(f"  Group {i+1}/{ng}: {len(parts[-1])} rows (total so far: {sum(len(p) for p in parts):,})")

sampled = pd.concat(parts, ignore_index=True)
print(f"\nTotal: {len(sampled):,} rows, {sampled['ticker'].nunique():,} tickers, "
      f"{sampled['date'].nunique():,} dates")
print(f"Date range: {sampled['date'].min()} to {sampled['date'].max()}")
print(f"Years: {sorted(sampled['date'].dt.year.unique())}")
print(f"Sectors: {sampled['sector'].nunique()} ({sampled['sector'].value_counts().head(10).to_dict()})")

sampled.to_parquet(OUT, index=False)
import os; print(f"Saved: {OUT}, {os.path.getsize(OUT)/1024/1024:.1f} MB")