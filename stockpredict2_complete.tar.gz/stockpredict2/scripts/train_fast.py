#!/usr/bin/env python3
"""
Fast risk-aware training — single 70/30 chronological split.
Full feature set: z-scores + raw factors + macro + interactions.
~140 features.
"""
import sys, os, gc, json, time, warnings
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
warnings.filterwarnings('ignore')
os.environ["OMP_NUM_THREADS"] = "8"

import numpy as np
import pandas as pd
import pyarrow.parquet as pq
import xgboost as xgb
from scipy.stats import rankdata

from stockpredict2.config import FM_PATH, MODELS_DIR

print("=" * 60, flush=True)
print("  RISK-AWARE TRAINING — Full Feature Set", flush=True)
print("=" * 60, flush=True)

SEEDS = [42, 99]  # 2 seeds for speed (3rd+ in production run)
TRAIN_PCT = 0.70
TW = {"vol": 0.0, "dd": 0.0, "beta": 0.0, "quality": 0.0}  # pure rank baseline

FACTORS = ["mom_6m","mom_1m","trend_str","earn_yield","fcf_yield",
           "book_yield","quality","beta","ivol","max_dd_90d",
           "rsi_mom","vol_trend","bb_compress","log_mcap"]

# Columns that vary per ticker (get z-scored)
P_TICKER_COLS = ["p_sma_10","p_sma_20","p_sma_50","p_sma_200","p_ema_12","p_ema_26",
                 "p_macd","p_macd_signal","p_rsi_14","p_bb_width","p_atr_14",
                 "p_vol_sma_20","p_vol_ratio","p_pct_change_1d","p_pct_change_5d",
                 "p_pct_change_21d","p_pct_change_63d","p_volatility_21d","p_volatility_63d"]
F_TICKER_COLS = ["f_gross_margin","f_op_margin","f_net_margin","f_roe","f_roa",
                 "f_revenue","f_net_income","f_eps","f_equity","f_total_assets",
                 "f_free_cash_flow","f_effective_tax_rate"]
N_TICKER_COLS = ["n_sentiment_pos","n_sentiment_neg","n_sentiment_neu","n_article_count"]
I_TICKER_COLS = ["i_buys_90d","i_sells_90d"]

TICKER_VARY = P_TICKER_COLS + F_TICKER_COLS + N_TICKER_COLS + I_TICKER_COLS

# Interaction pairs (z_feat × z_feat for important combos)
INTERACTIONS = [("quality","book_yield"), ("mom_6m","trend_str"),
                ("earn_yield","fcf_yield"), ("rsi_mom","ivol"),
                ("mom_1m","vol_trend"), ("quality","earn_yield"),
                ("beta","ivol"), ("trend_str","bb_compress")]

# ── Load data ──
print("\nLoading data...", flush=True)
t0 = time.time()
pf = pq.ParquetFile(str(FM_PATH))
col_names = [pf.schema_arrow.field(i).name for i in range(len(pf.schema_arrow))]
need_cols = [c for c in col_names if c not in (
    "open","high","low","volume","adj_close","class_label","c_trades_90d")]
table = pf.read(columns=need_cols)
X = table.to_pandas(); del table; gc.collect()
X["date"] = pd.to_datetime(X["date"])
X["pct_change_target"] = np.clip(X["pct_change_target"].values.astype(np.float32), -500, 500)
X = X.dropna(subset=["pct_change_target"]).copy()
print(f"  {len(X):,} rows, {len(X.columns)} cols in {time.time()-t0:.0f}s", flush=True)

# ── Compute factors ──
print("Computing factors...", flush=True)
t0 = time.time()
price = X.get("p_sma_10", pd.Series(1)).replace(0, 1)
eps = X.get("f_eps", pd.Series(0)).fillna(0)
equity = X.get("f_equity", pd.Series(0)).fillna(0)
roe = X.get("f_roe", pd.Series(0)).fillna(0)
gm = X.get("f_gross_margin", pd.Series(0)).fillna(0)
fcf = X.get("f_free_cash_flow", pd.Series(0)).fillna(0)
rsi = X.get("p_rsi_14", pd.Series(50)).fillna(50)
ivol = X.get("p_volatility_21d", pd.Series(0)).fillna(0)
mkt_vol = X.get("m_MARKET_VOL", pd.Series(1)).fillna(1).replace(0, 1)
vol_ratio = X.get("p_vol_ratio", pd.Series(1)).fillna(1)
bb = X.get("p_bb_width", pd.Series(0)).fillna(0)
sma50 = X.get("p_sma_50", pd.Series(0))
sma200 = X.get("p_sma_200", pd.Series(1)).replace(0, 1)
mkt_rsi = X.get("m_MARKET_RSI", pd.Series(50)).fillna(50)

X["mom_6m"] = X.get("p_pct_change_21d", 0).fillna(0)
X["mom_1m"] = X.get("p_pct_change_5d", 0).fillna(0)
X["trend_str"] = (sma50 / sma200 - 1) * 100
X["earn_yield"] = eps / price * 100
X["fcf_yield"] = fcf / price * 100
X["book_yield"] = np.log1p(np.abs(equity) / price) * np.sign(equity)
X["quality"] = (roe + gm) * 0.5
X["beta"] = rsi - mkt_rsi
X["ivol"] = (ivol - mkt_vol) / mkt_vol * 100
X["max_dd_90d"] = -ivol * 3
X["rsi_mom"] = rsi - 50
X["vol_trend"] = (vol_ratio - 1) * 100
X["bb_compress"] = -bb * 100
X["log_mcap"] = np.log1p(np.abs(equity))
print(f"  Factors: {time.time()-t0:.0f}s", flush=True)

# ── Chronological split ──
X = X.sort_values("date")
split_idx = int(len(X) * TRAIN_PCT)
train_all = X.iloc[:split_idx].copy()
test = X.iloc[split_idx:].copy()
del X; gc.collect()

# Subsample training to 500K rows for speed (cross-sectional ranking quality is preserved)
if len(train_all) > 500000:
    train = train_all.sample(n=500000, random_state=42).copy()
    del train_all; gc.collect()
else:
    train = train_all
print(f"  Train: {len(train):,} rows (subsampled), Test: {len(test):,} rows", flush=True)

# ── Identify macro columns (same for all tickers on a date — keep raw, don't z-score) ──
macro_cols = sorted([c for c in train.columns if c.startswith("m_")
                     and c not in TICKER_VARY + FACTORS
                     and c not in ("m_MARKET_RSI","m_MARKET_VOL")])

# Z-score columns (vary per ticker)
z_cols = TICKER_VARY + FACTORS
z_cols = [c for c in z_cols if c in train.columns]

# ── Z-score on train ──
print(f"Z-scoring {len(z_cols)} per-ticker features...", flush=True)
t0 = time.time()
dg = train.groupby("date")
for col in z_cols:
    means = dg[col].transform("mean")
    stds = dg[col].transform("std").replace(0, 1e-8)
    train[f"z_{col}"] = ((train[col] - means) / stds).fillna(0).astype(np.float32)
print(f"  Z-scored: {time.time()-t0:.0f}s", flush=True)

# ── Interaction features on train ──
print(f"Computing {len(INTERACTIONS)} interaction features...", flush=True)
for a, b in INTERACTIONS:
    za, zb = f"z_{a}", f"z_{b}"
    if za in train.columns and zb in train.columns:
        train[f"x_{a}_{b}"] = (train[za] * train[zb]).astype(np.float32)

# ── Risk-aware target on train ──
print("Computing risk-aware target...", flush=True)
t0 = time.time()
for date in train["date"].unique():
    mask = train["date"] == date
    g = train[mask]
    ret_r = rankdata(g["pct_change_target"].values) / max(len(g), 1)
    vz = g.get("z_p_volatility_21d", pd.Series(0)).fillna(0).values
    dz = g.get("z_max_dd_90d", pd.Series(0)).fillna(0).values
    bz = g.get("z_beta", pd.Series(0)).fillna(0).values
    ql = g.get("quality", pd.Series(0)).fillna(0).values
    tgt = ret_r - vz*TW["vol"] - dz*TW["dd"] - bz*TW["beta"] + ql*TW["quality"]
    train.loc[mask, "target_rank"] = rankdata(tgt) / max(len(tgt), 1) * 100
print(f"  Target: {time.time()-t0:.0f}s", flush=True)

# ── Same for test set ──
print("Z-scoring test set...", flush=True)
dg_test = test.groupby("date")
for col in z_cols:
    means = dg_test[col].transform("mean")
    stds = dg_test[col].transform("std").replace(0, 1e-8)
    test[f"z_{col}"] = ((test[col] - means) / stds).fillna(0).astype(np.float32)

for a, b in INTERACTIONS:
    za, zb = f"z_{a}", f"z_{b}"
    if za in train.columns and zb in test.columns:
        test[f"x_{a}_{b}"] = (test[za] * test[zb]).astype(np.float32)

for date in test["date"].unique():
    mask = test["date"] == date
    g = test[mask]
    ret_r = rankdata(g["pct_change_target"].values) / max(len(g), 1)
    vz = g.get("z_p_volatility_21d", pd.Series(0)).fillna(0).values
    dz = g.get("z_max_dd_90d", pd.Series(0)).fillna(0).values
    bz = g.get("z_beta", pd.Series(0)).fillna(0).values
    ql = g.get("quality", pd.Series(0)).fillna(0).values
    tgt = ret_r - vz*TW["vol"] - dz*TW["dd"] - bz*TW["beta"] + ql*TW["quality"]
    test.loc[mask, "target_rank"] = rankdata(tgt) / max(len(tgt), 1) * 100

# ── Build model feature set ──
# z-scores (52) + factors raw (14) + macro raw (65) + interactions (8) = ~139
z_feats = [c for c in train.columns if c.startswith("z_")]
fact_feats = [c for c in FACTORS if c in train.columns]
macro_feats = [c for c in macro_cols if c in train.columns]
interact_feats = [c for c in train.columns if c.startswith("x_")]

model_feats = z_feats + fact_feats + macro_feats + interact_feats
print(f"  Model features: {len(z_feats)} z + {len(fact_feats)} factors "
      f"+ {len(macro_feats)} macro + {len(interact_feats)} interact = {len(model_feats)} total",
      flush=True)

# Align test features
for feat in model_feats:
    if feat not in test.columns:
        test[feat] = 0.0

# ── Train ──
tri = train["target_rank"].dropna().values.astype(np.float32)
train_idx = train["target_rank"].dropna().index
dtrain = xgb.DMatrix(train.loc[train_idx, model_feats], tri)
dtest = xgb.DMatrix(test[model_feats])

models = []
print("\nTraining models...", flush=True)
for seed in SEEDS:
    t0 = time.time()
    m = xgb.train({
        "objective":"reg:squarederror","tree_method":"hist","max_depth":6,"learning_rate":0.05,"subsample":0.8,"colsample_bytree":0.7,
        "min_child_weight":5,"gamma":0.1,"reg_alpha":0.01,"reg_lambda":0.01,
        "verbosity":0,"seed":seed,"random_state":seed,"n_jobs":8,
    }, dtrain, num_boost_round=1500,
       evals=[(dtrain,"train")], early_stopping_rounds=80, verbose_eval=False)
    models.append(m)
    print(f"  Seed {seed}: {m.best_iteration} rounds, {time.time()-t0:.0f}s", flush=True)

# ── Evaluate ──
print("\nEvaluating...", flush=True)
test_dates = sorted(test["date"].unique())
results = []
for date in test_dates:
    mask = test["date"] == date
    day = test[mask].copy()
    if len(day) < 30: continue
    dday = xgb.DMatrix(day[model_feats])
    preds = np.zeros(len(day))
    for m in models:
        p = m.predict(dday, iteration_range=(0, m.best_iteration+1))
        preds += p
    preds /= len(models)

    qmask = pd.Series(True, index=day.index)
    if "p_sma_10" in day.columns: qmask &= day["p_sma_10"].fillna(0) >= 5.0
    if "f_equity" in day.columns: qmask &= day["f_equity"].fillna(0) >= 300e6
    if "p_vol_sma_20" in day.columns: qmask &= day["p_vol_sma_20"].fillna(0) >= 100000
    n_picks = max(3, int(len(day) * 0.01))
    top_idx = np.argsort(-preds)[:n_picks]
    picks = day.iloc[top_idx]
    quality_picks = picks[qmask.iloc[top_idx].values]
    if len(quality_picks) < 3: quality_picks = picks
    rets = day.loc[quality_picks.index, "pct_change_target"].values
    results.append({"date": str(date)[:10], "ret": float(np.mean(rets)),
                    "market": float(np.mean(day["pct_change_target"].values)),
                    "excess": float(np.mean(rets) - np.mean(day["pct_change_target"].values)),
                    "win": float((rets > 0).mean()), "picks": len(quality_picks)})

df = pd.DataFrame(results)
mean_ret = df["ret"].mean()
mean_excess = df["excess"].mean()
mean_win = df["win"].mean()
mean_picks = df["picks"].mean()
std_ret = df["ret"].std()
daily = (1 + mean_ret/100) ** (1/63) - 1 if abs(mean_ret) < 100 else 0
monthly = ((1 + daily) ** 21 - 1) * 100 if daily else 0
df = df.sort_values("date")
df["cum"] = (1 + df["ret"]/100).fillna(0).cumprod()
df["peak"] = df["cum"].cummax()
df["dd"] = (df["cum"] - df["peak"]) / df["peak"].replace(0, 1e-10) * 100
max_dd = min(df["dd"].min(), 0.0)
sharpe = mean_ret / max(std_ret, 0.001) * np.sqrt(252/63)

print(f"\n{'='*60}", flush=True)
print(f"  RESULTS — {len(results)} cycles, {len(model_feats)} features", flush=True)
print(f"{'='*60}", flush=True)
print(f"  Avg cycle return:   {mean_ret:+.2f}%", flush=True)
print(f"  Monthly equiv:      {monthly:+.2f}%", flush=True)
print(f"  Market avg:         {df['market'].mean():+.2f}%", flush=True)
print(f"  Avg excess:         {mean_excess:+.2f}%", flush=True)
print(f"  Win rate:           {mean_win:.1%}", flush=True)
print(f"  Max drawdown:       {max_dd:.2f}%", flush=True)
print(f"  Sharpe (annual):    {sharpe:.2f}", flush=True)
print(f"  Avg quality picks:  {df['picks'].mean():.0f}", flush=True)
print(f"{'='*60}", flush=True)
print(f"  4%+ monthly:  {'✓' if monthly >= 4 else '✗'} ({monthly:+.2f}%)")
print(f"  <5% max DD:   {'✓' if abs(max_dd) < 5 else '✗'} ({max_dd:.2f}%)")
print(f"  70%+ win rate:{'✓' if mean_win >= 0.70 else '✗'} ({mean_win:.1%})")

# Save
ts = int(time.time())
os.makedirs(str(MODELS_DIR), exist_ok=True)
for i, m in enumerate(models):
    path = MODELS_DIR / f"f_flag_full_s{SEEDS[i]}_r{monthly:.1f}pct_v{ts}.json"
    m.save_model(str(path))
    print(f"  Model: {path.name}")
results_path = Path(sys.path[0]) / "data/training_full_results.csv"
df.to_csv(results_path, index=False)
summary = {"timestamp": ts, "n_train": len(train), "n_test": len(test),
           "n_cycles": len(results), "features": len(model_feats),
           "avg_return": round(mean_ret, 2), "monthly": round(monthly, 2),
           "win_rate": round(float(mean_win), 4), "max_dd": round(float(max_dd), 2),
           "sharpe": round(float(sharpe), 2), "n_models": len(models)}
with open(MODELS_DIR / f"training_summary_v{ts}.json", "w") as f:
    json.dump(summary, f, indent=2)
print(f"\nDone. Summary: {MODELS_DIR / f'training_summary_v{ts}.json'}", flush=True)