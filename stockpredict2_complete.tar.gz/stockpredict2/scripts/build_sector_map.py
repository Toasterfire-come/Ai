#!/usr/bin/env python3
"""
Incremental sector map builder — batch-aware for cron.
Collects 250 tickers per run, resumes next time.
"""
import sys, json, time, re, os
from concurrent.futures import ThreadPoolExecutor, as_completed
import requests

OUT = os.path.expanduser('~/Documents/AI Training/stockpredict2/data/ticker_sector.json')
HEADERS = {'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7)'}

# Parse batch limit
BATCH = int(sys.argv[sys.argv.index('--batch')+1]) if '--batch' in sys.argv else 250

# Seed S&P 500 sectors
sector_map = {}
if os.path.exists(OUT):
    with open(OUT) as f:
        sector_map = json.load(f)

# Always seed S&P 500
try:
    resp = requests.get(
        'https://raw.githubusercontent.com/datasets/s-and-p-500-companies/main/data/constituents.csv',
        timeout=10)
    if resp.status_code == 200:
        for line in resp.text.strip().split('\n')[1:]:
            parts = line.split(',')
            if len(parts) >= 3:
                sector_map[parts[0]] = parts[2]
except Exception:
    pass

sys.path.insert(0, os.path.expanduser('~/Documents/AI Training'))
from stockpredict2.collectors.ticker_list import get_ticker_symbols
all_tickers = get_ticker_symbols()
remaining = [t for t in all_tickers if t not in sector_map or sector_map.get(t) == "Unknown"]
print(f"Sector map: {len(sector_map)} mapped, {len(remaining)} remaining, batch={BATCH}")

# Take only BATCH tickers
to_process = remaining[:BATCH]
if not to_process:
    print("All tickers mapped!")
    sys.exit(0)

def fetch(ticker):
    """Try multiple sources for sector data."""
    # Source 1: Yahoo Finance profile page
    try:
        url = f"https://finance.yahoo.com/quote/{ticker}/profile/"
        r = requests.get(url, timeout=10, headers=HEADERS)
        if r.status_code == 200:
            m = re.search(r'Sector</span><span[^>]*>([^<]+)', r.text)
            if m:
                return ticker, m.group(1).strip()
    except Exception:
        pass
    return ticker, "Unknown"

saved = sum(1 for v in sector_map.values() if v != "Unknown")
start = time.time()

with ThreadPoolExecutor(max_workers=3) as pool:
    for i in range(0, len(to_process), 50):
        batch = to_process[i:i+50]
        futures = {pool.submit(fetch, t): t for t in batch}
        for future in as_completed(futures):
            t, sec = future.result()
            if sec != "Unknown":
                sector_map[t] = sec
                saved += 1
            else:
                sector_map.setdefault(t, "Unknown")
        time.sleep(0.5)

with open(OUT, 'w') as f:
    json.dump(sector_map, f)

found = sum(1 for v in sector_map.values() if v != "Unknown")
print(f"Done: {found}/{len(all_tickers)} mapped ({BATCH} attempted this run)")
print(f"Time: {(time.time()-start)/60:.1f} min")