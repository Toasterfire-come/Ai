#!/usr/bin/env python3
"""
Fast parallel SEC Company Facts collector.
SEC API is free and unlimited at 10 req/sec.
10 workers → all 6,600 tickers in ~3 minutes.
"""
import sys, json, time
from concurrent.futures import ThreadPoolExecutor, as_completed
sys.path.insert(0, '/Users/ckiefer/Documents/AI Training')

import pandas as pd
import requests
from stockpredict2.storage import CheckpointTracker, ParquetStore
from stockpredict2.config import DATA_DIR

HEADERS = {'User-Agent': 'StockPredictBot/2.0 (ckiefer@dropkit.me)'}

# GAAP concepts to extract (key financial metrics)
KEY_CONCEPTS = {
    'RevenueFromContractWithCustomerExcludingAssessedTax': 'revenue',
    'CostOfRevenue': 'cost_of_revenue', 'GrossProfit': 'gross_profit',
    'ResearchAndDevelopmentExpense': 'r_and_d',
    'SellingGeneralAndAdministrativeExpense': 'sga',
    'OperatingIncomeLoss': 'operating_income',
    'NetIncomeLoss': 'net_income',
    'EarningsPerShareBasic': 'eps_basic',
    'EarningsPerShareDiluted': 'eps_diluted',
    'Assets': 'total_assets', 'AssetsCurrent': 'current_assets',
    'CashAndCashEquivalentsAtCarryingValue': 'cash',
    'Liabilities': 'total_liabilities', 'LiabilitiesCurrent': 'current_liabilities',
    'LongTermDebtNoncurrent': 'long_term_debt',
    'StockholdersEquity': 'equity',
    'RetainedEarningsAccumulatedDeficit': 'retained_earnings',
    'NetCashProvidedByUsedInOperatingActivities': 'operating_cash_flow',
    'PaymentsToAcquirePropertyPlantAndEquipment': 'capex',
    'WeightedAverageNumberOfSharesOutstandingBasic': 'shares_outstanding',
    'CommonStockDividendsPerShareDeclared': 'dividend_per_share',
}


def fetch_company_facts(ticker: str, cik: str) -> dict:
    """Fetch and parse Company Facts for one ticker. Returns dict of quarterly data."""
    url = f"https://data.sec.gov/api/xbrl/companyfacts/CIK{cik.zfill(10)}.json"
    try:
        resp = requests.get(url, headers=HEADERS, timeout=30)
        if resp.status_code != 200:
            return {"ticker": ticker, "error": f"HTTP {resp.status_code}"}
        data = resp.json()
        facts = data.get("facts", {}).get("us-gaap", {})

        # Build quarterly records keyed by date
        quarters = {}
        for concept, mapped_name in KEY_CONCEPTS.items():
            if concept not in facts:
                continue
            for unit_data in facts[concept].get("units", {}).values():
                for point in unit_data:
                    end_date = point.get("end", "")[:10]
                    if not end_date:
                        continue
                    fp = point.get("fp", "")  # FY/Q1/Q2/Q3/Q4
                    val = point.get("val")
                    if val is None:
                        continue
                    if end_date not in quarters:
                        quarters[end_date] = {"date": end_date, "fiscal_period": fp}
                    quarters[end_date][mapped_name] = val

        if not quarters:
            return {"ticker": ticker, "error": "no data"}

        result = {"ticker": ticker}
        result["quarters"] = quarters
        return result
    except Exception as e:
        return {"ticker": ticker, "error": str(e)[:80]}


def store_company_facts(result: dict):
    """Save fetched company facts to parquet."""
    ticker = result["ticker"]
    if "error" in result:
        return False
    quarters = result.get("quarters", {})
    if not quarters:
        return False
    df = pd.DataFrame(list(quarters.values()))
    df = df.sort_values("date")
    # Compute derived metrics
    if "revenue" in df.columns and "net_income" in df.columns:
        df["net_margin"] = (df["net_income"] / df["revenue"].replace(0, float('nan'))) * 100
    if "equity" in df.columns and df["equity"].notna().any():
        if "net_income" in df.columns:
            df["roe"] = (df["net_income"] / df["equity"].replace(0, float('nan'))) * 100
    if "shares_outstanding" in df.columns and df["shares_outstanding"].notna().any():
        if "net_income" in df.columns:
            df["eps_calculated"] = df["net_income"] / df["shares_outstanding"]
    if "operating_cash_flow" in df.columns and "capex" in df.columns:
        df["free_cash_flow"] = df["operating_cash_flow"] - df["capex"].abs()

    ParquetStore.save_financial(ticker, df)
    return True


def run():
    """Main: collect SEC Company Facts for all tickers."""
    from stockpredict2.collectors.ticker_list import get_ticker_symbols

    tickers = get_ticker_symbols()
    print(f"SEC Company Facts: {len(tickers)} tickers")

    # Load CIK map
    cik_path = DATA_DIR / "cik_map.json"
    if cik_path.exists():
        with open(cik_path) as f:
            cik_to_ticker = json.load(f)
        ticker_to_cik = {v.upper(): k for k, v in cik_to_ticker.items()}
    else:
        print("Downloading CIK map...")
        resp = requests.get("https://www.sec.gov/files/company_tickers.json",
                          headers=HEADERS, timeout=60)
        data = resp.json()
        ticker_to_cik = {}
        for entry in data.values():
            t = entry.get("ticker", "").upper()
            cik = str(entry.get("cik_str", "")).zfill(10)
            if t and cik:
                ticker_to_cik[t] = cik
        with open(cik_path, "w") as f:
            json.dump({v: k for k, v in ticker_to_cik.items()}, f)
    print(f"  CIK map: {len(ticker_to_cik)} tickers")

    cp = CheckpointTracker()
    remaining = cp.get_remaining("fundamentals_facts", tickers)
    print(f"  Remaining: {len(remaining)} of {len(tickers)}")

    if not remaining:
        print("  All done!")
        return

    succeeded = 0
    errors = 0
    start = time.time()

    with ThreadPoolExecutor(max_workers=10) as pool:
        futures = {}
        for ticker in remaining:
            cik = ticker_to_cik.get(ticker.upper())
            if not cik:
                cp.mark_completed("fundamentals_facts", ticker, rows=0)
                continue
            futures[pool.submit(fetch_company_facts, ticker, cik)] = ticker

        for i, future in enumerate(as_completed(futures)):
            ticker = futures[future]
            try:
                result = future.result()
                if store_company_facts(result):
                    cp.mark_completed("fundamentals_facts", ticker,
                                      rows=len(result.get("quarters", {})))
                    succeeded += 1
                else:
                    cp.mark_completed("fundamentals_facts", ticker, rows=0)
                    errors += 1
            except Exception:
                cp.mark_completed("fundamentals_facts", ticker, rows=0)
                errors += 1

            if (i + 1) % 500 == 0:
                rate = (i + 1) / max((time.time() - start) / 60, 0.01)
                print(f"  [{i+1}/{len(remaining)}] {succeeded} ok, "
                      f"{errors} err, {rate:.0f}/min", flush=True)

    elapsed = (time.time() - start) / 60
    print(f"\nDone: {succeeded} ok, {errors} err in {elapsed:.1f} min")


if __name__ == "__main__":
    run()