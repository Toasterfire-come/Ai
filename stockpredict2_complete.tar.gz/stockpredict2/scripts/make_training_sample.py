#!/usr/bin/env python3
"""Create a small training sample using pyarrow filter pushdown (no full-load)."""
import pyarrow.dataset as ds, pyarrow.parquet as pq, pyarrow.compute as pc
import pandas as pd, numpy as np, os

# Column groups needed for training
TICKER_COLS = ['p_sma_10','p_sma_20','p_sma_50','p_sma_200','p_ema_12','p_ema_26',
               'p_macd','p_macd_signal','p_rsi_14','p_bb_width','p_atr_14',
               'p_vol_sma_20','p_vol_ratio','p_pct_change_1d','p_pct_change_5d',
               'p_pct_change_21d','p_volatility_21d','p_volatility_63d',
               'f_gross_margin','f_op_margin','f_net_margin','f_roe','f_roa',
               'f_revenue','f_net_income','f_eps','f_equity','f_total_assets',
               'f_free_cash_flow',
               'n_sentiment_pos','n_sentiment_neg','n_sentiment_neu','n_article_count',
               'i_buys_90d','i_sells_90d']

MACRO_COLS = ['m_SPY_CLOSE','m_SPY_RET_5D','m_SPY_RET_21D','m_VIX_CLOSE',
              'm_VIX_PCTILE_252','m_QQQ_CLOSE','m_IWM_CLOSE','m_TNX_CLOSE',
              'm_IRX_CLOSE','m_YIELD_SPREAD_10Y_3M','m_QQQ_SPY_RATIO','m_IWM_SPY_RATIO',
              'm_SECTOR_XLF_RET_5D','m_SECTOR_XLK_RET_5D','m_SECTOR_XLV_RET_5D',
              'm_SECTOR_XLI_RET_5D','m_SECTOR_XLP_RET_5D','m_SECTOR_XLE_RET_5D',
              'm_SECTOR_XLU_RET_5D','m_SECTOR_XLB_RET_5D','m_SECTOR_XLRE_RET_5D',
              'm_SECTOR_XLC_RET_5D','m_SECTOR_XLY_RET_5D']

REQUIRED = ['date','ticker','pct_change_target']
COLS = REQUIRED + TICKER_COLS + MACRO_COLS

print("Loading training sample with filter pushdown...")
ds = ds.dataset('stockpredict2/data/feature_matrix.parquet', format='parquet')

# Year filter: only 2022-2026 (avoid exchange year for pct_change_target which needs 63d ahead)
# For pct_change_target = forward 63d return, data after 2025-10 lacks target
# But we already dropna on target, so any data works
pf = pq.ParquetFile('stockpredict2/data/feature_matrix.parquet')

# Read row group by row group to avoid OOM, filter and sample
n_groups = pf.metadata.num_row_groups
print(f"Row groups: {n_groups}")

parts = []
samples_per_group = max(1, 300000 // n_groups)

for i in range(n_groups):
    table = pf.read_row_group(i, columns=COLS)
    df = table.to_pandas()
    df['date'] = pd.to_datetime(df['date'])
    df['pct_change_target'] = np.clip(df['pct_change_target'].astype(np.float32), -500, 500)
    df = df.dropna(subset=['pct_change_target'])
    
    # Filter to 2022+ and subsample
    df = df[df['date'] >= '2022-01-01']
    if len(df) > samples_per_group:
        df = df.sample(n=samples_per_group, random_state=42+i)
    parts.append(df)
    print(f"  Group {i+1}/{n_groups}: {len(df)} rows")

sampled = pd.concat(parts, ignore_index=True)
print(f"\nTotal: {len(sampled)} rows, {sampled['ticker'].nunique()} tickers, "
      f"{sampled['date'].nunique()} dates")
print(f"Date range: {sampled['date'].min()} to {sampled['date'].max()}")

out = 'stockpredict2/data/training_sample.parquet'
sampled.to_parquet(out, index=False)
print(f"Saved: {out}, size: {os.path.getsize(out)/1024/1024:.1f} MB")