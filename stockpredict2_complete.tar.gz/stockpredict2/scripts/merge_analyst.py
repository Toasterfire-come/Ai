#!/usr/bin/env python3
"""
Merge analyst consensus data into the feature matrix.
Run after analyst_collector completes.

Adds:
  a_target_upside_pct  — (price_target / current_price - 1) * 100
  a_recommendation     — numeric: 4=Strong Buy, 3=Buy, 2=Hold, 1=Underperform, 0=Sell
"""
import sys, gc
from pathlib import Path

import numpy as np
import pandas as pd
import pyarrow.parquet as pq

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from stockpredict2.config import FM_PATH, ANALYST_DIR
from stockpredict2.collectors.ticker_list import get_ticker_symbols


def merge_analyst_into_fm():
    print(f"Loading feature matrix...")
    pf = pq.ParquetFile(str(FM_PATH))
    fm = pf.read().to_pandas()
    fm["date"] = pd.to_datetime(fm["date"])
    print(f"  FM: {len(fm):,} rows x {len(fm.columns)} cols")

    # Create analyst columns (default NaN)
    fm["a_target_upside_pct"] = np.nan
    fm["a_recommendation"] = 2  # default Hold

    analyst_files = list(ANALYST_DIR.glob("*.parquet"))
    print(f"  Analyst files: {len(analyst_files)}")

    merged = 0
    for path in analyst_files:
        ticker = path.stem.upper()
        mask = fm["ticker"] == ticker
        if mask.sum() == 0:
            continue

        df = pd.read_parquet(path)
        if df.empty:
            continue

        # Use the most recent analyst data for this ticker
        if "mean_price_target" in df.columns:
            pt = df["mean_price_target"].iloc[0]
            if pt and pt > 0:
                close_vals = fm.loc[mask, "close"].astype(float).replace(0, np.nan)
                fm.loc[mask, "a_target_upside_pct"] = (pt / close_vals - 1) * 100

        if "recommendation" in df.columns:
            rec = str(df["recommendation"].iloc[0]).strip()
            rec_map = {"Strong Buy": 4, "Buy": 3, "Hold": 2,
                       "Underperform": 1, "Sell": 0}
            fm.loc[mask, "a_recommendation"] = rec_map.get(rec, 2)

        merged += 1

    print(f"  Analyst data merged for {merged} tickers")

    # Fill remaining NaN
    fm["a_target_upside_pct"] = fm["a_target_upside_pct"].fillna(0)
    fm["a_recommendation"] = fm["a_recommendation"].fillna(2).astype(np.int8)

    # Save
    print(f"  Saving updated FM: {len(fm):,} rows x {len(fm.columns)} cols")
    fm = fm.sort_values(["date", "ticker"])
    fm.to_parquet(str(FM_PATH), index=False, compression="snappy")
    print(f"  Size: {FM_PATH.stat().st_size / 1024 / 1024:.1f} MB")

    feature_cols = [c for c in fm.columns
                    if c not in ("ticker", "date", "pct_change_target", "class_label",
                                 "open", "high", "low", "close", "volume", "adj_close")]
    print(f"  Features for training: {len(feature_cols)}")
    print(f"  New features added: a_target_upside_pct, a_recommendation")

    # Show distribution
    print(f"\n  Recommendation distribution:")
    dist = fm["a_recommendation"].value_counts().sort_index()
    labels = {4: "Strong Buy", 3: "Buy", 2: "Hold", 1: "Underperform", 0: "Sell"}
    for k, v in dist.items():
        print(f"    {labels.get(int(k), k)}: {v:,} rows")

    print(f"\n  Target upside stats:")
    ups = fm["a_target_upside_pct"]
    print(f"    Mean: {ups.mean():.1f}%")
    print(f"    Median: {ups.median():.1f}%")
    print(f"    > 50% upside: {(ups > 50).sum():,} rows")
    print(f"    Negative (stock above target): {(ups < 0).sum():,} rows")

    return {"rows": len(fm), "cols": len(fm.columns), "features": len(feature_cols)}


if __name__ == "__main__":
    merge_analyst_into_fm()