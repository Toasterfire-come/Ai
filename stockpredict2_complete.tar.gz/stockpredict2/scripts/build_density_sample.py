#!/usr/bin/env python3
"""Build density-weighted training sample: full 2016-2026, weighted toward recent years."""
import pyarrow.parquet as pq, pandas as pd, numpy as np, json, time, os

FM_PATH = '/Users/ckiefer/Documents/AI Training/stockpredict2/data/feature_matrix.parquet'
OUT = '/Users/ckiefer/Documents/AI Training/stockpredict2/data/training_sample.parquet'
SECTOR_PATH = '/Users/ckiefer/Documents/AI Training/stockpredict2/data/ticker_sector.json'

# Density weights by year (more recent = more samples)
DENSITY = {2016: 0.05, 2017: 0.08, 2018: 0.12, 2019: 0.15,
           2020: 0.25, 2021: 0.40, 2022: 0.80, 2023: 1.0, 2024: 1.0, 2025: 1.0, 2026: 1.0}
TARGET_ROWS = 600000

print(f"Building density-weighted sample ({TARGET_ROWS} target)...")
t0 = time.time()

# Load sector map
sector_map = {}
if os.path.exists(SECTOR_PATH):
    with open(SECTOR_PATH) as f:
        sector_map = json.load(f)

# Load columns needed
EXCLUDE = {'open','high','low','volume','adj_close','class_label','c_trades_90d',
           '__fragment_index','__batch_index','__last_in_fragment','__filename'}
pf = pq.ParquetFile(FM_PATH)
all_cols = [pf.schema_arrow.field(i).name for i in range(len(pf.schema_arrow))]
cols = [c for c in all_cols if c not in EXCLUDE]

ng = pf.metadata.num_row_groups
parts = []
total_weight = sum(4 if y >= 2022 else DENSITY.get(y, 0.3) for y in range(2016, 2027))
rows_per_group = int(TARGET_ROWS / total_weight * 4)  # bias toward recent groups

for i in range(ng):
    table = pf.read_row_group(i, columns=cols)
    df = table.to_pandas()
    df['date'] = pd.to_datetime(df['date'])
    df['pct_change_target'] = np.clip(df['pct_change_target'].astype(np.float32), -500, 500)
    df = df.dropna(subset=['pct_change_target'])

    # Add sector
    df['sector'] = df['ticker'].map(sector_map).fillna('Unknown')

    # Apply density weight by year
    df['year'] = df['date'].dt.year
    df['weight'] = df['year'].map(DENSITY).fillna(0.3)
    
    # Stratified sampling with density weights
    target_n = max(1000, int(rows_per_group))
    if len(df) > target_n:
        df = df.sample(n=target_n, weights='weight', random_state=42+i)

    df = df.drop(columns=['year', 'weight'])
    parts.append(df)
    print(f"  Group {i+1}/{ng}: {len(df)} rows", flush=True)

sampled = pd.concat(parts, ignore_index=True)
print(f"\nTotal: {len(sampled):,} rows, {sampled['ticker'].nunique():,} tickers, "
      f"{sampled['date'].nunique():,} dates")
print(f"Date range: {sampled['date'].min()} to {sampled['date'].max()}")
print(f"Years: {dict(sorted(sampled['date'].dt.year.value_counts().to_dict().items()))}")
print(f"Sectors: {sampled['sector'].nunique()} ({sampled['sector'].value_counts().head(8).to_dict()})")
print(f"Time: {time.time()-t0:.0f}s")

# Merge SEC quarterly financials where available
print("\nMerging SEC quarterly fundamentals...")
fin_dir = '/Users/ckiefer/Documents/AI Training/stockpredict2/data/financials'
sec_added = 0
for ticker in sampled['ticker'].unique():
    path = f'{fin_dir}/{ticker}.parquet'
    if not os.path.exists(path): continue
    fin = pd.read_parquet(path)
    if 'fiscal_period' not in fin.columns: continue  # only new SEC format
    if 'roe' not in fin.columns: continue
    sec_added += 1
    
    # Compute rolling/derived metrics from quarterly data
    fin = fin.sort_values('date').copy()
    for col in ['revenue','net_income','operating_cash_flow','free_cash_flow']:
        if col in fin.columns:
            fin[f'{col}_yoy'] = fin[col].pct_change(4) * 100  # YoY growth
    if 'revenue' in fin.columns and 'total_assets' in fin.columns:
        fin['asset_turnover'] = fin['revenue'] / fin['total_assets'].replace(0, np.nan)
    if 'equity' in fin.columns and 'long_term_debt' in fin.columns:
        fin['debt_to_equity'] = fin['long_term_debt'] / fin['equity'].replace(0, np.nan)
    
    # Forward fill quarterly values to daily
    fin['date'] = pd.to_datetime(fin['date'])
    for _, row in fin.iterrows():
        q_date = row['date']
        mask = (sampled['ticker'] == ticker) & (sampled['date'] >= q_date) & \
               (sampled['date'] < q_date + pd.Timedelta(days=95))
        idx = sampled.index[mask]
        if len(idx) == 0: continue
        for col in fin.columns:
            if col in ('date','fiscal_period','form','total_liabilities_equity'): continue
            val = row[col]
            if val is not None and not (isinstance(val, float) and np.isnan(val)):
                try: sampled.loc[idx, f'sec_{col}'] = float(val)
                except: pass

print(f"  SEC data merged for {sec_added} tickers")
print(f"  Total columns: {len(sampled.columns)}")
print(f"  New SEC cols: {[c for c in sampled.columns if c.startswith('sec_')][:10]}...")

sampled.to_parquet(OUT, index=False)
print(f"\nSaved: {OUT}, {os.path.getsize(OUT)/1024/1024:.0f} MB")