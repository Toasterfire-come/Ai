#!/usr/bin/env python3
"""Fast training on pre-built sample. ~3 min total."""
import sys, os, gc, json, time, warnings
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
warnings.filterwarnings('ignore')
os.environ["OMP_NUM_THREADS"] = "8"

import numpy as np
import pandas as pd
import xgboost as xgb
from scipy.stats import rankdata
from stockpredict2.config import MODELS_DIR

SAMPLE = Path(sys.path[0]) / "data/training_sample.parquet"
SEEDS = [42, 99]  # 2 seeds for speed
TW = {"vol": 0.02, "dd": 0.01, "beta": 0.01, "quality": 0.05}  # very light risk

FACTORS = ["mom_6m","mom_1m","trend_str","earn_yield","fcf_yield",
           "book_yield","quality","beta","ivol","max_dd_90d",
           "rsi_mom","vol_trend","bb_compress","log_mcap"]

TICKER_VARY = ["p_sma_10","p_sma_20","p_sma_50","p_sma_200","p_ema_12","p_ema_26",
               "p_macd","p_macd_signal","p_rsi_14","p_bb_width","p_atr_14",
               "p_vol_sma_20","p_vol_ratio","p_pct_change_1d","p_pct_change_5d",
               "p_pct_change_21d","p_volatility_21d","p_volatility_63d",
               "f_gross_margin","f_op_margin","f_net_margin","f_roe","f_roa",
               "f_revenue","f_net_income","f_eps","f_equity","f_total_assets",
               "f_free_cash_flow","n_sentiment_pos","n_sentiment_neg",
               "n_sentiment_neu","n_article_count","i_buys_90d","i_sells_90d"]

MACRO_COLS = ["m_SPY_CLOSE","m_SPY_RET_5D","m_SPY_RET_21D","m_VIX_CLOSE",
              "m_VIX_PCTILE_252","m_TNX_CLOSE","m_IRX_CLOSE","m_YIELD_SPREAD_10Y_3M",
              "m_QQQ_SPY_RATIO","m_IWM_SPY_RATIO",
              "m_SECTOR_XLF_RET_5D","m_SECTOR_XLK_RET_5D","m_SECTOR_XLV_RET_5D",
              "m_SECTOR_XLI_RET_5D","m_SECTOR_XLP_RET_5D","m_SECTOR_XLE_RET_5D",
              "m_SECTOR_XLU_RET_5D","m_SECTOR_XLB_RET_5D","m_SECTOR_XLRE_RET_5D",
              "m_SECTOR_XLC_RET_5D","m_SECTOR_XLY_RET_5D"]

INTERACTIONS = [("quality","book_yield"), ("mom_6m","trend_str"),
                ("earn_yield","fcf_yield"), ("rsi_mom","ivol"),
                ("quality","earn_yield"), ("beta","ivol"),
                ("trend_str","bb_compress"), ("mom_1m","vol_trend")]

print("="*60, flush=True)
print("  FAST TRAINING — 500K sample, 2016-2026 + sector feats", flush=True)
print("="*60, flush=True)

# ── Load ──
print("\nLoading...", flush=True); t0=time.time()
X = pd.read_parquet(SAMPLE)
X["date"] = pd.to_datetime(X["date"])
X["pct_change_target"] = np.clip(X["pct_change_target"].astype(np.float32), -500, 500)
X = X.dropna(subset=["pct_change_target"]).copy()
print(f"  {len(X):,} rows in {time.time()-t0:.0f}s", flush=True)

# ── Factors ──
print("Factors...", flush=True)
price=X.get("p_sma_10",pd.Series(1)).replace(0,1)
eps=X.get("f_eps",pd.Series(0)).fillna(0)
equity=X.get("f_equity",pd.Series(0)).fillna(0)
roe=X.get("f_roe",pd.Series(0)).fillna(0)
gm=X.get("f_gross_margin",pd.Series(0)).fillna(0)
fcf=X.get("f_free_cash_flow",pd.Series(0)).fillna(0)
rsi=X.get("p_rsi_14",pd.Series(50)).fillna(50)
ivol=X.get("p_volatility_21d",pd.Series(0)).fillna(0)
mkt_vol=X.get("m_VIX_CLOSE",pd.Series(15)).fillna(15).replace(0,1)
vr=X.get("p_vol_ratio",pd.Series(1)).fillna(1)
bb=X.get("p_bb_width",pd.Series(0)).fillna(0)
s50=X.get("p_sma_50",pd.Series(0)); s200=X.get("p_sma_200",pd.Series(1)).replace(0,1)

X["mom_6m"]=X.get("p_pct_change_21d",0).fillna(0)
X["mom_1m"]=X.get("p_pct_change_5d",0).fillna(0)
X["trend_str"]=(s50/s200-1)*100
X["earn_yield"]=eps/price*100
X["fcf_yield"]=fcf/price*100
X["book_yield"]=np.log1p(np.abs(equity)/price)*np.sign(equity)
X["quality"]=(roe+gm)*0.5
X["beta"]=rsi-X.get("m_SPY_RET_21D",pd.Series(0)).fillna(0)
X["ivol"]=(ivol-mkt_vol)/mkt_vol*100
X["max_dd_90d"]=-ivol*3; X["rsi_mom"]=rsi-50
X["vol_trend"]=(vr-1)*100; X["bb_compress"]=-bb*100
X["log_mcap"]=np.log1p(np.abs(equity))

# ── Split ──
X=X.sort_values("date"); sp=int(len(X)*0.70)
train=X.iloc[:sp].copy(); test=X.iloc[sp:].copy(); del X; gc.collect()
print(f"  Train: {len(train):,}, Test: {len(test):,}", flush=True)

# ── Z-score on train ──
z_cols=[c for c in TICKER_VARY+FACTORS if c in train.columns]
print(f"Z-scoring {len(z_cols)} features...", flush=True)
dg=train.groupby("date")
for c in z_cols:
    m=dg[c].transform("mean"); s=dg[c].transform("std").replace(0,1e-8)
    train[f"z_{c}"]=((train[c]-m)/s).fillna(0).astype(np.float32)

for a,b in INTERACTIONS:
    if f"z_{a}" in train.columns: train[f"x_{a}_{b}"]=(train[f"z_{a}"]*train[f"z_{b}"]).astype(np.float32)

# ── Sector z-score features (stock vs sector mean) ──
if 'sector' in train.columns:
    sec_grp = train.groupby(['sector', 'date'])
    for fact in ['mom_6m','quality','earn_yield','trend_str','fcf_yield','mom_1m']:
        zc = f'z_{fact}'
        if zc not in train.columns: continue
        means = sec_grp[zc].transform('mean')
        stds = sec_grp[zc].transform('std').replace(0, 1e-8)
        train[f'sz_{fact}'] = ((train[zc] - means) / stds).fillna(0).astype(np.float32)
        if f'z_{fact}' in train.columns:
            train[f'md_{fact}'] = (train[f'sz_{fact}'] - train[zc]).astype(np.float32)

for date in train["date"].unique():
    m=train["date"]==date; g=train[m]
    rr=rankdata(g["pct_change_target"].values)/max(len(g),1)
    vz=g.get("z_p_volatility_21d",pd.Series(0)).fillna(0).values
    dz=g.get("z_max_dd_90d",pd.Series(0)).fillna(0).values
    bz=g.get("z_beta",pd.Series(0)).fillna(0).values
    ql=g.get("quality",pd.Series(0)).fillna(0).values
    tgt=rr-vz*TW["vol"]-dz*TW["dd"]-bz*TW["beta"]+ql*TW["quality"]
    train.loc[m,"target_rank"]=rankdata(tgt)/max(len(tgt),1)*100

# ── Z-score on test ──
dg_test=test.groupby("date")
for c in z_cols:
    m=dg_test[c].transform("mean"); s=dg_test[c].transform("std").replace(0,1e-8)
    test[f"z_{c}"]=((test[c]-m)/s).fillna(0).astype(np.float32)
for a,b in INTERACTIONS:
    if f"z_{a}" in train.columns: test[f"x_{a}_{b}"]=(test[f"z_{a}"]*test[f"z_{b}"]).astype(np.float32)

# Sector features on test
if 'sector' in test.columns:
    sec_grp_test = test.groupby(['sector', 'date'])
    for fact in ['mom_6m','quality','earn_yield','trend_str','fcf_yield','mom_1m']:
        zc = f'z_{fact}'
        if zc not in test.columns: continue
        means = sec_grp_test[zc].transform('mean')
        stds = sec_grp_test[zc].transform('std').replace(0, 1e-8)
        test[f'sz_{fact}'] = ((test[zc] - means) / stds).fillna(0).astype(np.float32)
        if f'z_{fact}' in test.columns:
            test[f'md_{fact}'] = (test[f'sz_{fact}'] - test[zc]).astype(np.float32)
for date in test["date"].unique():
    m=test["date"]==date; g=test[m]
    rr=rankdata(g["pct_change_target"].values)/max(len(g),1)
    vz=g.get("z_p_volatility_21d",pd.Series(0)).fillna(0).values
    dz=g.get("z_max_dd_90d",pd.Series(0)).fillna(0).values
    bz=g.get("z_beta",pd.Series(0)).fillna(0).values
    ql=g.get("quality",pd.Series(0)).fillna(0).values
    tgt=rr-vz*TW["vol"]-dz*TW["dd"]-bz*TW["beta"]+ql*TW["quality"]
    test.loc[m,"target_rank"]=rankdata(tgt)/max(len(tgt),1)*100

# ── Model features ──
z_feats=[c for c in train.columns if c.startswith("z_")]
fact_feats=[c for c in FACTORS if c in train.columns]
macro_feats=[c for c in MACRO_COLS if c in train.columns]
interact_feats=[c for c in train.columns if c.startswith("x_")]
model_feats=z_feats+fact_feats+macro_feats+interact_feats
for f in model_feats:
    if f not in test.columns: test[f]=0.0
print(f"  Features: {len(z_feats)}z+{len(fact_feats)}f+{len(macro_feats)}m+{len(interact_feats)}x={len(model_feats)}", flush=True)

ti=train["target_rank"].dropna(); di=ti.index
dtrain=xgb.DMatrix(train.loc[di,model_feats],ti.values.astype(np.float32))
dtest=xgb.DMatrix(test[model_feats])

# ── Train ──
models=[]
print("Training...", flush=True)
for seed in SEEDS:
    t0=time.time()
    m=xgb.train({"objective":"reg:squarederror","tree_method":"hist","max_depth":6,"learning_rate":0.05,"subsample":0.8,"colsample_bytree":0.7,
                "min_child_weight":5,"gamma":0.1,"reg_alpha":0.01,"reg_lambda":0.01,
        "verbosity":0,"seed":seed,"n_jobs":8},
        dtrain,num_boost_round=1500,evals=[(dtrain,"train")],early_stopping_rounds=80,verbose_eval=False)
    models.append(m)
    print(f"  Seed {seed}: {m.best_iteration}r {time.time()-t0:.0f}s", flush=True)

# ── Evaluate ──
print("Evaluating...", flush=True)
results=[]
for date in sorted(test["date"].unique()):
    day=test[test["date"]==date].copy()
    if len(day)<30: continue
    dday=xgb.DMatrix(day[model_feats])
    preds=np.zeros(len(day))
    for m in models: preds+=m.predict(dday,iteration_range=(0,m.best_iteration+1))
    preds/=len(models)

    qm=pd.Series(True,index=day.index)
    if "p_sma_10" in day.columns: qm&=day["p_sma_10"].fillna(0)>=2.0  # $2+
    if "f_equity" in day.columns: qm&=day["f_equity"].fillna(0)>=1e8  # $100M
    if "p_vol_sma_20" in day.columns: qm&=day["p_vol_sma_20"].fillna(0)>=50000  # 50K vol
    npicks=max(3,int(len(day)*0.01))
    top=np.argsort(-preds)[:npicks]
    picks=day.iloc[top]; qp=picks[qm.iloc[top].values]
    if len(qp)<3: qp=picks
    rets=day.loc[qp.index,"pct_change_target"].values
    results.append({"date":str(date)[:10],"ret":float(np.mean(rets)),
        "market":float(np.mean(day["pct_change_target"].values)),
        "excess":float(np.mean(rets)-np.mean(day["pct_change_target"].values)),
        "win":float((rets>0).mean()),"picks":len(qp)})

df=pd.DataFrame(results)
mr=df["ret"].mean(); mx=df["excess"].mean(); mw=df["win"].mean(); std=df["ret"].std()
daily=(1+mr/100)**(1/63)-1 if abs(mr)<100 else 0
mo=((1+daily)**21-1)*100 if daily else 0
df=df.sort_values("date")
df["cum"]=(1+df["ret"]/100).fillna(0).cumprod()
df["peak"]=df["cum"].cummax()
df["dd"]=(df["cum"]-df["peak"])/df["peak"].replace(0,1e-10)*100
mdd=min(df["dd"].min(),0.0); shr=mr/max(std,.001)*np.sqrt(252/63)

print(f"\n{'='*60}\n  RESULTS — {len(results)} cycles, {len(model_feats)} features\n{'='*60}")
print(f"  Avg cycle return:   {mr:+.2f}%")
print(f"  Monthly equiv:      {mo:+.2f}%")
print(f"  Market avg:         {df['market'].mean():+.2f}%")
print(f"  Avg excess:         {mx:+.2f}%")
print(f"  Win rate:           {mw:.1%}")
print(f"  Max drawdown:       {mdd:.2f}%")
print(f"  Sharpe:             {shr:.2f}")
print(f"  Avg quality picks:  {df['picks'].mean():.0f}")
print(f"{'='*60}")
print(f"  4%+ monthly:  {'✓' if mo>=4 else '✗'} ({mo:+.2f}%)")
print(f"  <5% max DD:   {'✓' if abs(mdd)<5 else '✗'} ({mdd:.2f}%)")
print(f"  70%+ win rate:{'✓' if mw>=0.70 else '✗'} ({mw:.1%})")

ts=int(time.time())
os.makedirs(str(MODELS_DIR),exist_ok=True)
for i,m in enumerate(models):
    p=MODELS_DIR/f"f_flag_v2_s{SEEDS[i]}_r{mo:.1f}pct_v{ts}.json"
    m.save_model(str(p)); print(f"  Model: {p.name}")
out=Path(sys.path[0])/"data/training_v2_results.csv"
df.to_csv(out,index=False)
s={"timestamp":ts,"n":len(results),"features":len(model_feats),
   "ret":round(mr,2),"monthly":round(mo,2),"excess":round(mx,2),
   "win":round(float(mw),4),"mdd":round(float(mdd),2),"sharpe":round(float(shr),2)}
with open(MODELS_DIR/f"training_v2_summary_v{ts}.json","w") as f: json.dump(s,f,indent=2)
print(f"  Summary saved\nDone.",flush=True)