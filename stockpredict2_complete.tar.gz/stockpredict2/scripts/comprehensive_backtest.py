#!/usr/bin/env python3
"""
Comprehensive backtest suite for the 5.13%/70.9% win model.
Tests: walk-forward, year-by-year CV, Monte Carlo noise, transaction costs, market regimes.
"""
import sys, os, gc, json, time, warnings
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
warnings.filterwarnings('ignore')
os.environ["OMP_NUM_THREADS"] = "8"

import numpy as np
import pandas as pd
import xgboost as xgb
from scipy.stats import rankdata

from stockpredict2.config import MODELS_DIR

SAMPLE = Path(sys.path[0]) / "data/training_sample.parquet"
MODEL_PATH = MODELS_DIR / "f_flag_v2_s42_r5.1pct_v1790386485.json"
RESULTS_DIR = Path(sys.path[0]) / "data"

print("=" * 65)
print("  COMPREHENSIVE BACKTEST SUITE")
print("=" * 65)

# ── Load model ──
print("\nLoading model...")
model = xgb.Booster()
model.load_model(str(MODEL_PATH))
print(f"  Model loaded: {MODEL_PATH.name}")

# ── Load and prepare data ──
print("Loading data...")
t0 = time.time()
df = pd.read_parquet(SAMPLE)
df['date'] = pd.to_datetime(df['date'])
df['pct_change_target'] = np.clip(df['pct_change_target'].astype(np.float32), -500, 500)
df = df.dropna(subset=['pct_change_target']).copy()
print(f"  {len(df):,} rows in {time.time()-t0:.0f}s")

# Get model's expected features
expected = model.feature_names or []

# Build features same as in training
FACTORS = ["mom_6m","mom_1m","trend_str","earn_yield","fcf_yield",
           "book_yield","quality","beta","ivol","max_dd_90d",
           "rsi_mom","vol_trend","bb_compress","log_mcap"]

# ── Compute factors on full dataframe ──
print("Computing factors...")
price=df.get("p_sma_10",pd.Series(1)).replace(0,1)
eps=df.get("f_eps",pd.Series(0)).fillna(0)
equity=df.get("f_equity",pd.Series(0)).fillna(0)
roe=df.get("f_roe",pd.Series(0)).fillna(0)
gm=df.get("f_gross_margin",pd.Series(0)).fillna(0)
fcf=df.get("f_free_cash_flow",pd.Series(0)).fillna(0)
rsi=df.get("p_rsi_14",pd.Series(50)).fillna(50)
ivol=df.get("p_volatility_21d",pd.Series(0)).fillna(0)
mkt_vol=df.get("m_VIX_CLOSE",pd.Series(15)).fillna(15).replace(0,1)
vr=df.get("p_vol_ratio",pd.Series(1)).fillna(1)
bb=df.get("p_bb_width",pd.Series(0)).fillna(0)
s50=df.get("p_sma_50",pd.Series(0)); s200=df.get("p_sma_200",pd.Series(1)).replace(0,1)

df["mom_6m"]=df.get("p_pct_change_21d",0).fillna(0)
df["mom_1m"]=df.get("p_pct_change_5d",0).fillna(0)
df["trend_str"]=(s50/s200-1)*100
df["earn_yield"]=eps/price*100; df["fcf_yield"]=fcf/price*100
df["book_yield"]=np.log1p(np.abs(equity)/price)*np.sign(equity)
df["quality"]=(roe+gm)*0.5
df["beta"]=rsi-df.get("m_SPY_RET_21D",pd.Series(0)).fillna(0)
df["ivol"]=(ivol-mkt_vol)/mkt_vol*100; df["max_dd_90d"]=-ivol*3
df["rsi_mom"]=rsi-50; df["vol_trend"]=(vr-1)*100
df["bb_compress"]=-bb*100; df["log_mcap"]=np.log1p(np.abs(equity))

# Z-score factors and ticker-varying columns (same as training)
TICKER_VARY = ["p_sma_10","p_sma_20","p_sma_50","p_sma_200","p_ema_12","p_ema_26",
               "p_macd","p_macd_signal","p_rsi_14","p_bb_width","p_atr_14",
               "p_vol_sma_20","p_vol_ratio","p_pct_change_1d","p_pct_change_5d",
               "p_pct_change_21d","p_volatility_21d","p_volatility_63d",
               "f_gross_margin","f_op_margin","f_net_margin","f_roe","f_roa",
               "f_revenue","f_net_income","f_eps","f_equity","f_total_assets",
               "f_free_cash_flow",
               "n_sentiment_pos","n_sentiment_neg","n_sentiment_neu","n_article_count",
               "i_buys_90d","i_sells_90d"]
MACRO = ["m_SPY_CLOSE","m_SPY_RET_5D","m_SPY_RET_21D","m_VIX_CLOSE",
         "m_VIX_PCTILE_252","m_TNX_CLOSE","m_IRX_CLOSE","m_YIELD_SPREAD_10Y_3M",
         "m_QQQ_SPY_RATIO","m_IWM_SPY_RATIO",
         "m_SECTOR_XLF_RET_5D","m_SECTOR_XLK_RET_5D","m_SECTOR_XLV_RET_5D",
         "m_SECTOR_XLI_RET_5D","m_SECTOR_XLP_RET_5D","m_SECTOR_XLE_RET_5D",
         "m_SECTOR_XLU_RET_5D","m_SECTOR_XLB_RET_5D","m_SECTOR_XLRE_RET_5D",
         "m_SECTOR_XLC_RET_5D","m_SECTOR_XLY_RET_5D"]

# Z-score all per-ticker varying columns
z_cols = FACTORS + TICKER_VARY
z_cols = [c for c in z_cols if c in df.columns]
INTERACTIONS = [("quality","book_yield"),("mom_6m","trend_str"),("earn_yield","fcf_yield"),
                ("rsi_mom","ivol"),("quality","earn_yield"),("beta","ivol"),
                ("trend_str","bb_compress"),("mom_1m","vol_trend")]

# Build feature list matching model expectations  
raw_model_feats = list(expected)
FEATURES = [f for f in raw_model_feats if f in df.columns or f.startswith("z_") 
            and f[2:] in z_cols or f in MACRO or f.startswith("x_")]
# Actually just take what the model expects and fill missing with 0
FEATURES = [f for f in expected if f in df.columns or f.startswith("z_") 
            or f.startswith("x_") or f in MACRO]
print(f"  {len(FEATURES)}/{len(expected)} features mappable")

def evaluate_cycle(predictions, test_day, cycle_name):
    """Simulate one cycle: score → post-filter → metrics."""
    qm = pd.Series(True, index=test_day.index)
    if "p_sma_10" in test_day.columns: qm &= test_day["p_sma_10"].fillna(0) >= 2.0
    if "f_equity" in test_day.columns: qm &= test_day["f_equity"].fillna(0) >= 1e8
    
    npicks = max(3, int(len(test_day) * 0.01))
    top = np.argsort(-predictions)[:npicks]
    picks = test_day.iloc[top]
    qp = picks[qm.iloc[top].values]
    if len(qp) < 3: qp = picks
    rets = test_day.loc[qp.index, "pct_change_target"].values
    return {
        "cycle": cycle_name, "n_picks": len(qp),
        "ret": float(np.mean(rets)),
        "market": float(np.mean(test_day["pct_change_target"].values)),
        "win": float((rets > 0).mean()) if len(rets) > 0 else 0,
    }

def score_and_evaluate(df_slice, label=""):
    """Score all dates in a df, evaluate each cycle."""
    dates = sorted(df_slice["date"].unique())
    results = []
    for date in dates:
        day = df_slice[df_slice["date"] == date].copy()
        if len(day) < 30: continue
        dmat = xgb.DMatrix(day[FEATURES])
        preds = model.predict(dmat)
        results.append(evaluate_cycle(preds, day, str(date)[:10]))
    return pd.DataFrame(results) if results else pd.DataFrame()

def compute_metrics(df):
    if df.empty or len(df) < 3: return {}
    df = df.sort_values("cycle")
    mean_ret = df["ret"].mean(); mean_win = df["win"].mean(); std_ret = df["ret"].std()
    daily = (1 + mean_ret/100) ** (1/63) - 1 if abs(mean_ret) < 100 else 0
    monthly = ((1 + daily) ** 21 - 1) * 100 if daily else 0
    df["cum"] = (1 + df["ret"]/100).fillna(0).cumprod()
    df["peak"] = df["cum"].cummax()
    df["dd"] = (df["cum"] - df["peak"]) / df["peak"].replace(0, 1e-10) * 100
    max_dd = min(df["dd"].min(), 0.0)
    sharpe = mean_ret / max(std_ret, 0.001) * np.sqrt(252/63)
    return {"cycles": len(df), "ret": round(mean_ret, 2), "monthly": round(monthly, 2),
            "win": round(float(mean_win), 4), "max_dd": round(float(max_dd), 2),
            "sharpe": round(float(sharpe), 2)}

# ════════════════════════════════════════════════════════════════
print("\n" + "=" * 65)
print("  BACKTEST 1: WALK-FORWARD (expanding windows, 63d steps)")
print("=" * 65)

dates = sorted(df["date"].unique())
wf_windows = []
for i in range(252*3, len(dates) - 63, 63):
    train_end = dates[i - 1]
    test_start = dates[i]
    test_end = min(dates[i + 62], dates[-1])
    wf_windows.append((train_end, test_start, test_end))
print(f"  {len(wf_windows)} windows")

wf_results = []
for wi, (t_end, t_start, t_end_date) in enumerate(wf_windows):
    t0 = time.time()
    train = df[df["date"] <= t_end].copy()
    test = df[(df["date"] >= t_start) & (df["date"] <= t_end_date)].copy()
    
    # Z-score on train, apply to test
    dg = train.groupby("date")
    for feat in [c for c in FEATURES if c.startswith("z_")]:
        zcol = feat[2:]
        if zcol in train.columns:
            means = dg[zcol].transform("mean")
            stds = dg[zcol].transform("std").replace(0, 1e-8)
            train[feat] = ((train[zcol] - means) / stds).fillna(0).astype(np.float32)
    
    dg_test = test.groupby("date")
    for feat in [c for c in FEATURES if c.startswith("z_")]:
        zcol = feat[2:]
        if zcol in test.columns:
            means = dg_test[zcol].transform("mean")
            stds = dg_test[zcol].transform("std").replace(0, 1e-8)
            test[feat] = ((test[zcol] - means) / stds).fillna(0).astype(np.float32)
    
    result = score_and_evaluate(test, f"wf_{wi}")
    if not result.empty:
        m = compute_metrics(result)
        wf_results.append(m)
        print(f"  Window {wi+1}: {m.get('monthly','?'):.1f}%/mo, {m.get('win','?'):.1%} win", flush=True)

if wf_results:
    wf_df = pd.DataFrame(wf_results)
    print(f"\n  WALK-FORWARD AVG ({len(wf_results)} windows):")
    print(f"    Monthly: {wf_df['monthly'].mean():.2f}% ± {wf_df['monthly'].std():.2f}%")
    print(f"    Win rate: {wf_df['win'].mean():.1%} ± {wf_df['win'].std():.1%}")
    print(f"    Sharpe: {wf_df['sharpe'].mean():.2f}")

# ════════════════════════════════════════════════════════════════
print("\n" + "=" * 65)
print("  BACKTEST 2: YEAR-BY-YEAR CROSS-VALIDATION")
print("=" * 65)

years = sorted(df['date'].dt.year.unique())
print(f"  Years: {years}")

year_results = []
df_sorted = df.sort_values('date')

for test_year in years:
    test = df_sorted[df_sorted['date'].dt.year == test_year].copy()
    train = df_sorted[df_sorted['date'].dt.year < test_year].copy()
    if len(train) < 10000 or len(test) < 100:
        continue
    
    t0 = time.time()
    dg = train.groupby("date")
    for feat in [c for c in FEATURES if c.startswith("z_")]:
        zcol = feat[2:]
        if zcol in train.columns:
            means = dg[zcol].transform("mean"); stds = dg[zcol].transform("std").replace(0,1e-8)
            train[feat] = ((train[zcol] - means) / stds).fillna(0).astype(np.float32)
    
    dg_test = test.groupby("date")
    for feat in [c for c in FEATURES if c.startswith("z_")]:
        zcol = feat[2:]
        if zcol in test.columns:
            means = dg_test[zcol].transform("mean"); stds = dg_test[zcol].transform("std").replace(0,1e-8)
            test[feat] = ((test[zcol] - means) / stds).fillna(0).astype(np.float32)
    
    result = score_and_evaluate(test, str(test_year))
    if not result.empty:
        m = compute_metrics(result)
        year_results.append({"year": test_year, **m})
        print(f"  {test_year}: {m.get('monthly','?'):.1f}%/mo, {m.get('win','?'):.1%} win", flush=True)

if year_results:
    yr_df = pd.DataFrame(year_results)
    yr_df.to_csv(RESULTS_DIR / "backtest_yearly.csv", index=False)
    print(f"\n  Saved to backtest_yearly.csv")

# ════════════════════════════════════════════════════════════════
print("\n" + "=" * 65)
print("  BACKTEST 3: MONTE CARLO NOISE INJECTION (10 runs)")
print("=" * 65)

# Score once, then inject noise to predictions
dates = sorted(df["date"].unique())
test_dates = dates[len(dates)//2:]  # last 50%
test = df[df["date"].isin(test_dates)].copy()

dg_test = test.groupby("date")
for feat in [c for c in FEATURES if c.startswith("z_")]:
    zcol = feat[2:]
    if zcol in test.columns:
        means = dg_test[zcol].transform("mean"); stds = dg_test[zcol].transform("std").replace(0,1e-8)
        test[feat] = ((test[zcol] - means) / stds).fillna(0).astype(np.float32)

mc_results = []
for run in range(10):
    np.random.seed(42 + run)
    noise_std = 0.05  # 5% noise on predictions
    run_results = []
    
    for date in sorted(test["date"].unique()):
        day = test[test["date"] == date].copy()
        if len(day) < 30: continue
        dmat = xgb.DMatrix(day[FEATURES])
        preds = model.predict(dmat)
        preds += np.random.normal(0, noise_std * preds.std(), len(preds))
        run_results.append(evaluate_cycle(preds, day, f"mc{run}_{str(date)[:10]}"))
    
    rd = pd.DataFrame(run_results)
    m = compute_metrics(rd)
    mc_results.append(m)
    print(f"  Run {run+1}: {m.get('monthly','?'):.1f}%/mo, {m.get('win','?'):.1%} win", flush=True)

if mc_results:
    mc_df = pd.DataFrame(mc_results)
    print(f"\n  MONTE CARLO ({len(mc_results)} runs):")
    print(f"    Monthly: {mc_df['monthly'].mean():.2f}% ± {mc_df['monthly'].std():.2f}%")
    print(f"    Win rate: {mc_df['win'].mean():.1%} ± {mc_df['win'].std():.1%}")

# ════════════════════════════════════════════════════════════════
print("\n" + "=" * 65)
print("  BACKTEST 4: TRANSACTION COSTS (0.1%, 0.5%, 1% per trade)")
print("=" * 65)

# Use the same test set (last 50%)
for cost_pct in [0.001, 0.005, 0.01]:
    tc_results = []
    for date in sorted(test["date"].unique()):
        day = test[test["date"] == date].copy()
        if len(day) < 30: continue
        dmat = xgb.DMatrix(day[FEATURES])
        preds = model.predict(dmat)
        
        qm = pd.Series(True, index=day.index)
        if "p_sma_10" in day.columns: qm &= day["p_sma_10"].fillna(0) >= 2.0
        if "f_equity" in day.columns: qm &= day["f_equity"].fillna(0) >= 1e8
        npicks = max(3, int(len(day) * 0.01))
        top = np.argsort(-preds)[:npicks]
        picks = day.iloc[top]
        qp = picks[qm.iloc[top].values]
        if len(qp) < 3: qp = picks
        rets = day.loc[qp.index, "pct_change_target"].values
        avg_ret = float(np.mean(rets)) - cost_pct * 100  # subtract transaction cost
        tc_results.append({
            "cycle": str(date)[:10], "ret": avg_ret,
            "market": float(np.mean(day["pct_change_target"].values)),
            "win": float((rets > 0).mean()), "n_picks": len(qp)
        })
    tcd = pd.DataFrame(tc_results)
    m = compute_metrics(tcd)
    print(f"  {cost_pct*100:.1f}% cost: {m.get('monthly','?'):.1f}%/mo, {m.get('win','?'):.1%} win")

# ════════════════════════════════════════════════════════════════
print("\n" + "=" * 65)
print("  BACKTEST 5: MARKET REGIME BREAKDOWN")
print("=" * 65)

# Simple regime: SPY 21d return > 0 = bull, < 0 = bear
test = test.copy()
test['regime'] = test['m_SPY_RET_21D'].apply(lambda x: 'bull' if x > 0 else 'bear')

for regime in ['bull', 'bear']:
    regime_data = test[test['regime'] == regime]
    result = score_and_evaluate(regime_data, regime)
    if not result.empty:
        m = compute_metrics(result)
        print(f"  {regime.upper()}: {m.get('monthly','?'):.1f}%/mo, {m.get('win','?'):.1%} win, {m.get('cycles','?')} cycles")
    else:
        print(f"  {regime}: no cycles")

# ════════════════════════════════════════════════════════════════
print("\n" + "=" * 65)
print("  BACKTEST 6: ENSEMBLE (5 seeds, average predictions)")
print("=" * 65)

# Find multiple models
seed_models = []
for seed in [42, 99, 107, 203, 555]:
    mp = list(MODELS_DIR.glob(f"f_flag_v2_s{seed}_r*.json"))
    if mp:
        m = xgb.Booster(); m.load_model(str(mp[0]))
        seed_models.append(m)
        print(f"  Loaded seed {seed}: {mp[0].name}")

if len(seed_models) >= 2:
    ens_results = []
    for date in sorted(test["date"].unique()):
        day = test[test["date"] == date].copy()
        if len(day) < 30: continue
        dmat = xgb.DMatrix(day[FEATURES])
        preds = np.zeros(len(day))
        for m in seed_models:
            preds += m.predict(dmat)
        preds /= len(seed_models)
        ens_results.append(evaluate_cycle(preds, day, str(date)[:10]))
    
    ed = pd.DataFrame(ens_results)
    m = compute_metrics(ed)
    print(f"\n  ENSEMBLE ({len(seed_models)} models):")
    print(f"    Monthly: {m.get('monthly','?'):.1f}%/mo")
    print(f"    Win rate: {m.get('win','?'):.1%}")
    ed.to_csv(RESULTS_DIR / "backtest_ensemble.csv", index=False)

# ════════════════════════════════════════════════════════════════
print("\n" + "=" * 65)
print("  FINAL SUMMARY")
print("=" * 65)
print(f"\nBest model: {MODEL_PATH.name}")
print(f"Backtest complete. Results saved to {RESULTS_DIR}/backtest_*.csv")