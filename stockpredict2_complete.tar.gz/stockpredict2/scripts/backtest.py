#!/usr/bin/env python3
"""Comprehensive backtest — computes features from raw data, no alignment issues."""
import sys, os, gc, json, time, warnings
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
warnings.filterwarnings('ignore')
os.environ["OMP_NUM_THREADS"] = "8"

import numpy as np
import pandas as pd
import xgboost as xgb
from scipy.stats import rankdata

print("="*65); print("  COMPREHENSIVE BACKTEST"); print("="*65)

# Load model
# Load newest model
models_dir = Path(__file__).resolve().parent.parent / "models"
MODEL_PATH = models_dir / "f_flag_v2_s42_r5.7pct_v1790442625.json"
print(f"Using model: {MODEL_PATH.name}")
model = xgb.Booster(); model.load_model(str(MODEL_PATH))
expected = list(model.feature_names)  # preserve model's feature order
print(f"Model: {len(expected)} features")

# Load sample
df = pd.read_parquet(Path(__file__).resolve().parent.parent / "data/training_sample.parquet")
df['date'] = pd.to_datetime(df['date'])
df['pct_change_target'] = np.clip(df['pct_change_target'].astype(np.float32), -500, 500)
df = df.dropna(subset=['pct_change_target']).copy()
print(f"Data: {len(df):,} rows")

# Compute factors (same as training)
price=df.get("p_sma_10",pd.Series(1)).replace(0,1)
eps=df.get("f_eps",pd.Series(0)).fillna(0); equity=df.get("f_equity",pd.Series(0)).fillna(0)
roe=df.get("f_roe",pd.Series(0)).fillna(0); gm=df.get("f_gross_margin",pd.Series(0)).fillna(0)
fcf=df.get("f_free_cash_flow",pd.Series(0)).fillna(0)
rsi=df.get("p_rsi_14",pd.Series(50)).fillna(50); ivol=df.get("p_volatility_21d",pd.Series(0)).fillna(0)
mv=df.get("m_VIX_CLOSE",pd.Series(15)).fillna(15).replace(0,1)
vr=df.get("p_vol_ratio",pd.Series(1)).fillna(1); bb=df.get("p_bb_width",pd.Series(0)).fillna(0)
s50=df.get("p_sma_50",pd.Series(0)); s200=df.get("p_sma_200",pd.Series(1)).replace(0,1)

df["mom_6m"]=df.get("p_pct_change_21d",0).fillna(0); df["mom_1m"]=df.get("p_pct_change_5d",0).fillna(0)
df["trend_str"]=(s50/s200-1)*100; df["earn_yield"]=eps/price*100; df["fcf_yield"]=fcf/price*100
df["book_yield"]=np.log1p(np.abs(equity)/price)*np.sign(equity); df["quality"]=(roe+gm)*0.5
df["beta"]=rsi-df.get("m_SPY_RET_21D",pd.Series(0)).fillna(0)
df["ivol"]=(ivol-mv)/mv*100; df["max_dd_90d"]=-ivol*3; df["rsi_mom"]=rsi-50
df["vol_trend"]=(vr-1)*100; df["bb_compress"]=-bb*100; df["log_mcap"]=np.log1p(np.abs(equity))

# Z-score all per-ticker-varying columns within each date (vectorized)
z_cols = [c for c in df.columns if c not in ('date','ticker','pct_change_target','sector','year','weight') 
          and not c.startswith('m_SECTOR_') and c not in ['m_SPY_CLOSE','m_SPY_RET_5D','m_SPY_RET_21D',
          'm_VIX_CLOSE','m_VIX_PCTILE_252','m_TNX_CLOSE','m_IRX_CLOSE','m_YIELD_SPREAD_10Y_3M',
          'm_QQQ_SPY_RATIO','m_IWM_SPY_RATIO']]
z_cols = [c for c in z_cols if c in df.columns]
dg = df.groupby('date')
for c in z_cols:
    m = dg[c].transform('mean'); s = dg[c].transform('std').replace(0,1e-8)
    df[f'z_{c}'] = ((df[c] - m) / s).fillna(0).astype(np.float32)

# Interaction features
INTER = [("quality","book_yield"),("mom_6m","trend_str"),("earn_yield","fcf_yield"),
         ("rsi_mom","ivol"),("quality","earn_yield"),("beta","ivol"),
         ("trend_str","bb_compress"),("mom_1m","vol_trend")]
for a,b in INTER:
    za, zb = f'z_{a}', f'z_{b}'
    if za in df.columns and zb in df.columns: df[f'x_{a}_{b}'] = (df[za]*df[zb]).astype(np.float32)

# Align features with model
model_feats = [f for f in expected if f in df.columns]
for f in expected:
    if f not in df.columns: df[f] = 0.0
print(f"  {len(model_feats)}/{len(expected)} features aligned")

# Evaluate function
def eval_cycle(day, preds):
    qm = pd.Series(True, index=day.index)
    if "p_sma_10" in day.columns: qm &= day["p_sma_10"].fillna(0) >= 2.0
    if "f_equity" in day.columns: qm &= day["f_equity"].fillna(0) >= 1e8
    npicks = max(3, int(len(day)*0.01))
    top = np.argsort(-preds)[:npicks]
    picks = day.iloc[top]; qp = picks[qm.iloc[top].values]
    if len(qp) < 3: qp = picks
    rets = day.loc[qp.index, 'pct_change_target'].values
    return {"ret": float(np.mean(rets)), "market": float(np.mean(day['pct_change_target'].values)),
            "win": float((rets>0).mean()) if len(rets)>0 else 0, "n_picks": len(qp)}

def run_test(df, label=""):
    results = []
    for date in sorted(df['date'].unique()):
        day = df[df['date']==date].copy()
        if len(day) < 30: continue
        for f in expected:
            if f not in day.columns: day[f] = 0.0
        dmat = xgb.DMatrix(day[list(expected)])
        preds = model.predict(dmat)
        r = eval_cycle(day, preds)
        r['cycle'] = str(date)[:10]; results.append(r)
    return pd.DataFrame(results) if results else pd.DataFrame()

def metrics(df):
    if df.empty or len(df) < 3: return {}
    df = df.sort_values('cycle')
    mr = df['ret'].mean(); mw = df['win'].mean(); std = df['ret'].std()
    daily = (1+mr/100)**(1/63)-1 if abs(mr)<100 else 0
    mo = ((1+daily)**21-1)*100 if daily else 0
    df['cum'] = (1+df['ret']/100).fillna(0).cumprod()
    df['peak'] = df['cum'].cummax()
    df['dd'] = (df['cum']-df['peak'])/df['peak'].replace(0,1e-10)*100
    return {"cycles": len(df), "ret": round(mr,2), "monthly": round(mo,2),
            "win": round(float(mw),4), "mdd": round(min(df['dd'].min(),0.0),2),
            "sharpe": round(mr/max(std,.001)*np.sqrt(252/63),2)}

# ══ 1. FULL TEST SET (last 50%) ══
dates = sorted(df['date'].unique())
sp = len(dates)//2
test = df[df['date'].isin(dates[sp:])].copy()
result = run_test(test)
m = metrics(result)
print(f"\nFULL TEST ({len(result)} cycles): {m.get('monthly','?'):.1f}%/mo, {m.get('win','?'):.1%} win, DD={m.get('mdd','?'):.1f}%")

# ══ 2. YEAR BY YEAR ══
print("\nYEAR BY YEAR:")
for yr in sorted(test['date'].dt.year.unique()):
    yr_test = test[test['date'].dt.year==yr]
    r = run_test(yr_test)
    if not r.empty:
        m = metrics(r)
        print(f"  {yr}: {m.get('monthly','?'):.1f}%/mo, {m.get('win','?'):.1%} win, {m.get('cycles','?')} cycles")

# ══ 3. TRANSACTION COSTS ══
print("\nTRANSACTION COSTS:")
for cost in [0.001, 0.005, 0.01]:
    tc_results = []
    for date in sorted(test['date'].unique()):
        day = test[test['date']==date].copy()
        if len(day) < 30: continue
        dmat = xgb.DMatrix(day[list(expected)])
        preds = model.predict(dmat)
        r = eval_cycle(day, preds)
        r['ret'] -= cost*100
        r['cycle'] = str(date)[:10]; tc_results.append(r)
    tcd = pd.DataFrame(tc_results)
    m = metrics(tcd)
    print(f"  {cost*100:.1f}% cost: {m.get('monthly','?'):.1f}%/mo, {m.get('win','?'):.1%} win")

# ══ 4. MARKET REGIME ══
print("\nMARKET REGIMES:")
test2 = test.copy()
test2['regime'] = test2['m_SPY_RET_21D'].apply(lambda x: 'BULL' if x>0 else 'BEAR')
for regime in ['BULL', 'BEAR']:
    rd = test2[test2['regime']==regime]
    r = run_test(rd)
    if not r.empty:
        m = metrics(r)
        print(f"  {regime}: {m.get('monthly','?'):.1f}%/mo, {m.get('win','?'):.1%} win, {m.get('cycles','?')} cycles")

# ══ 5. MONTE CARLO (5 runs, ±5% noise) ══
print("\nMONTE CARLO (5 runs, ±5% noise):")
mc_results = []
for run in range(5):
    np.random.seed(42+run)
    mc_r = []
    for date in sorted(test['date'].unique()):
        day = test[test['date']==date].copy()
        if len(day) < 30: continue
        dmat = xgb.DMatrix(day[list(expected)])
        preds = model.predict(dmat)
        preds += np.random.normal(0, 0.05*preds.std(), len(preds))
        r = eval_cycle(day, preds)
        r['cycle'] = str(date)[:10]; mc_r.append(r)
    rdf = pd.DataFrame(mc_r)
    m = metrics(rdf)
    mc_results.append(m)
    print(f"  Run {run+1}: {m.get('monthly','?'):.1f}%/mo, {m.get('win','?'):.1%} win")
mc_df = pd.DataFrame(mc_results)
print(f"  AVG: {mc_df['monthly'].mean():.1f}% ± {mc_df['monthly'].std():.1f}%, win {mc_df['win'].mean():.1%}")

# ══ 6. WALK-FORWARD (expanding windows, 63d steps) ══
print(f"\nWALK-FORWARD ({len(dates[252*3:])} dates):")
wfw = []
for i in range(252*3, len(dates), 63):
    test_w = df[df['date'].between(dates[i], dates[min(i+62, len(dates)-1)])]
    if len(test_w) < 100: continue
    r = run_test(test_w)
    if not r.empty:
        m = metrics(r)
        wfw.append(m)

if wfw:
    wf = pd.DataFrame(wfw)
    print(f"  Avg: {wf['monthly'].mean():.1f}%/mo, win {wf['win'].mean():.1%}, {len(wfw)} windows")
    print(f"  Range: monthly {wf['monthly'].min():.1f}% to {wf['monthly'].max():.1f}%")

# ══ 7. ENSEMBLE (all available v2 models) ══
print("\nENSEMBLE:")
MODELS_DIR = Path(__file__).resolve().parent.parent / "models"
ensemble = []
for seed in [42, 99, 107, 203, 555]:
    for p in sorted(MODELS_DIR.glob(f"f_flag_v2_s{seed}_r*.json")):
        m = xgb.Booster(); m.load_model(str(p)); ensemble.append(m)
        break
if len(ensemble) >= 2:
    ens_r = []
    for date in sorted(test['date'].unique()):
        day = test[test['date']==date].copy()
        if len(day) < 30: continue
        dmat = xgb.DMatrix(day[list(expected)])
        preds = np.zeros(len(day))
        for m in ensemble: preds += m.predict(dmat)
        preds /= len(ensemble)
        r = eval_cycle(day, preds)
        r['cycle'] = str(date)[:10]; ens_r.append(r)
    edf = pd.DataFrame(ens_r)
    m = metrics(edf)
    print(f"  {len(ensemble)} models: {m.get('monthly','?'):.1f}%/mo, {m.get('win','?'):.1%} win")

# ══ SUMMARY ══
print(f"\n{'='*65}")
print("  BACKTEST COMPLETE")
print(f"{'='*65}")
print(f"\nModel: {MODEL_PATH.name}")
print(f"Period: {test['date'].min().strftime('%Y-%m-%d')} to {test['date'].max().strftime('%Y-%m-%d')}")
out = Path(sys.path[0]) / "data/backtest_summary.json"
s = {"model": MODEL_PATH.name, "n_test": len(test), "n_cycles": len(result) if not result.empty else 0}
if not result.empty:
    s['results'] = metrics(result)
with open(out, 'w') as f: json.dump(s, f, indent=2)
print(f"Summary: {out}")