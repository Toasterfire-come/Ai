#!/usr/bin/env python3
"""
Risk-Aware Walk-Forward Training — stockpredict2.

Trains 5 XGBoost models with a risk-aware target that penalizes volatile
stocks and rewards quality. Walk-forward validation on expanding windows.

Target: 4%+/month, <5% DD, 70%+ win rate
Architecture: Full-universe scoring → post-quality filter at pick time
"""
import sys, os, gc, json, time, warnings
from pathlib import Path
from datetime import datetime

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
warnings.filterwarnings('ignore')
os.environ["OMP_NUM_THREADS"] = "8"

import numpy as np
import pandas as pd
import pyarrow.parquet as pq
import xgboost as xgb
from scipy.stats import rankdata

from stockpredict2.config import FM_PATH, MODELS_DIR, CLASS_BOUNDARIES
from stockpredict2.collectors.ticker_list import get_ticker_symbols

# ── Configuration ──────────────────────────────────────────────────────
TRAIN_CONFIG = {
    "initial_years": 3,
    "step_days": 63,            # 3-month walk-forward step
    "trading_days_per_year": 252,
    "seeds": [42, 99, 107, 203, 555],
    "max_rounds": 2000,
    "early_stopping": 80,
    "xgb_params": {
        "objective": "reg:squarederror",
        "tree_method": "hist",
        "max_depth": 6,
        "learning_rate": 0.03,
        "subsample": 0.80,
        "colsample_bytree": 0.70,
        "min_child_weight": 10,
        "gamma": 0.1,
        "reg_alpha": 0.01,
        "reg_lambda": 0.1,
        "verbosity": 0,
    },
    "post_filter": {
        "min_price": 5.0,
        "min_equity": 300_000_000,
        "min_volume": 100_000,
        "max_vol_pctile": 0.80,
    },
    "target_weights": {
        "vol_penalty": 0.15,      # how much to penalize high volatility
        "dd_penalty": 0.10,       # drawdown penalty
        "beta_penalty": 0.08,     # beta penalty
        "quality_bonus": 0.05,    # quality bonus (ROE + gross_margin)
    },
    "pick_pct": 0.01,             # top 1% of stocks
    "n_models": 5,               # ensemble size
}

# Factor features to compute (14 factors from raw columns)
FACTORS = ["mom_6m", "mom_1m", "trend_str", "earn_yield", "fcf_yield",
           "book_yield", "quality", "beta", "ivol", "max_dd_90d",
           "rsi_mom", "vol_trend", "bb_compress", "log_mcap"]


def compute_factors(df):
    """Compute 14 factor features from raw FM columns. Mutates df in-place."""
    price = df.get("p_sma_10", pd.Series(1, index=df.index)).replace(0, 1)
    eps = df.get("f_eps", pd.Series(0)).fillna(0)
    equity = df.get("f_equity", pd.Series(0)).fillna(0)
    roe = df.get("f_roe", pd.Series(0)).fillna(0)
    gm = df.get("f_gross_margin", pd.Series(0)).fillna(0)
    fcf = df.get("f_free_cash_flow", pd.Series(0)).fillna(0)
    ticker_rsi = df.get("p_rsi_14", pd.Series(50)).fillna(50)
    ivol = df.get("p_volatility_21d", pd.Series(0)).fillna(0)
    mkt_vol = df.get("m_MARKET_VOL", pd.Series(1)).fillna(1).replace(0, 1)
    vol_ratio = df.get("p_vol_ratio", pd.Series(1)).fillna(1)
    bb = df.get("p_bb_width", pd.Series(0)).fillna(0)
    sma50 = df.get("p_sma_50", pd.Series(0))
    sma200 = df.get("p_sma_200", pd.Series(1)).replace(0, 1)

    df["mom_6m"] = df.get("p_pct_change_21d", 0).fillna(0)
    df["mom_1m"] = df.get("p_pct_change_5d", 0).fillna(0)
    df["trend_str"] = (sma50 / sma200 - 1) * 100
    df["earn_yield"] = eps / price * 100
    df["fcf_yield"] = fcf / price * 100
    df["book_yield"] = np.log1p(np.abs(equity) / price) * np.sign(equity)
    df["quality"] = (roe + gm) * 0.5
    df["beta"] = ticker_rsi - df.get("MARKET_RSI", df.get("m_MARKET_RSI", pd.Series(50))).fillna(50)
    df["ivol"] = (ivol - mkt_vol) / mkt_vol * 100
    df["max_dd_90d"] = -ivol * 3
    df["rsi_mom"] = ticker_rsi - 50
    df["vol_trend"] = (vol_ratio - 1) * 100
    df["bb_compress"] = -bb * 100
    df["log_mcap"] = np.log1p(np.abs(equity))


def zscore_features(df, feature_cols):
    """Z-score all features cross-sectionally within each date. Vectorized."""
    dg = df.groupby("date")
    for col in feature_cols:
        means = dg[col].transform("mean")
        stds = dg[col].transform("std").replace(0, 1e-8)
        df[f"z_{col}"] = ((df[col] - means) / stds).fillna(0).astype(np.float32)


def compute_risk_target(df, weights):
    """Risk-aware target: penalize volatility, reward quality."""
    for date in df["date"].unique():
        mask = df["date"] == date
        g = df[mask]
        ret = g["pct_change_target"].values
        ret_rank = rankdata(ret) / max(len(ret), 1)

        vol_z = g.get("z_p_volatility_21d", pd.Series(0, index=g.index)).fillna(0).values
        dd_z = g.get("z_max_dd_90d", pd.Series(0, index=g.index)).fillna(0).values
        beta_z = g.get("z_beta", pd.Series(0, index=g.index)).fillna(0).values
        qual = g.get("quality", pd.Series(0, index=g.index)).fillna(0).values

        target = (ret_rank
                  - vol_z * weights["vol_penalty"]
                  - dd_z * weights["dd_penalty"]
                  - beta_z * weights["beta_penalty"]
                  + qual * weights["quality_bonus"])

        # Re-rank back to 0-100
        df.loc[mask, "target_rank"] = rankdata(target) / max(len(target), 1) * 100


def walk_forward_windows(dates, initial_days, step_days):
    """Yield (train_mask, test_mask) for each walk-forward window."""
    dates = sorted(np.unique(dates))
    if len(dates) < initial_days + step_days:
        return

    for i in range(initial_days, len(dates) - step_days + 1, step_days):
        train_end = dates[i - 1]
        test_start = dates[i]
        test_end = dates[i + step_days - 1] if i + step_days < len(dates) else dates[-1]
        yield train_end, test_start, test_end


def apply_post_filter(df):
    """Apply quality filters to picks. Returns filtered df."""
    mask = pd.Series(True, index=df.index)
    pf = TRAIN_CONFIG["post_filter"]

    if "p_sma_10" in df.columns:
        mask &= df["p_sma_10"].fillna(0) >= pf["min_price"]
    if "f_equity" in df.columns:
        mask &= df["f_equity"].fillna(0) >= pf["min_equity"]
    if "p_vol_sma_20" in df.columns:
        mask &= df["p_vol_sma_20"].fillna(0) >= pf["min_volume"]
    if "p_volatility_21d" in df.columns:
        threshold = df["p_volatility_21d"].quantile(pf["max_vol_pctile"])
        mask &= df["p_volatility_21d"].fillna(0) <= threshold

    return df[mask]


def simulate_cycle(predictions, test_df, actual_returns, cycle_name):
    """Simulate one trading cycle: score → post-filter → top picks → calc metrics."""
    n_picks = max(5, int(len(test_df) * TRAIN_CONFIG["pick_pct"]))
    top_idx = np.argsort(-predictions)[:n_picks]
    picks = test_df.iloc[top_idx].copy()

    # Post-quality filter
    quality_picks = apply_post_filter(picks)
    if len(quality_picks) < 3:
        quality_picks = picks  # fallback: accept unfiltered if too few pass

    rets = actual_returns[quality_picks.index.values]
    avg_ret = float(np.mean(rets))
    win_rate = float((rets > 0).mean())
    all_avg = float(np.mean(actual_returns))
    excess = avg_ret - all_avg

    return {
        "cycle": cycle_name,
        "n_picks_raw": len(picks),
        "n_picks_quality": len(quality_picks),
        "avg_return": round(avg_ret, 2),
        "market_return": round(all_avg, 2),
        "excess": round(excess, 2),
        "win_rate": round(win_rate, 4),
    }


def train_and_evaluate():
    """Main training loop: walk-forward, train 5 seeds per window, evaluate."""
    os.makedirs(str(MODELS_DIR), exist_ok=True)
    config = TRAIN_CONFIG

    # ── Load data ──
    print(f"\n{'='*65}")
    print(f"  RISK-AWARE WALK-FORWARD TRAINING")
    print(f"  Seeds: {config['seeds']}, Step: {config['step_days']}d, "
          f"Initial: {config['initial_years']}yr")
    print(f"  Target weights: {config['target_weights']}")
    print(f"{'='*65}\n")

    print("Loading FM columns...", flush=True)
    t0 = time.time()
    
    # Only load columns we actually need (drop open/high/low/volume/adj_close)
    pf = pq.ParquetFile(str(FM_PATH))
    all_cols = [pf.schema_arrow.field(i).name for i in range(len(pf.schema_arrow))]
    need_cols = [c for c in all_cols if c not in (
        "open", "high", "low", "volume", "adj_close", "class_label", "c_trades_90d")]
    
    table = pf.read(columns=need_cols)
    X = table.to_pandas()
    del table
    gc.collect()
    
    X["date"] = pd.to_datetime(X["date"])
    y = X["pct_change_target"].values.astype(np.float32)
    y = np.clip(y, -500, 500)
    X["pct_change_target"] = y
    
    # Drop rows without target immediately (saves memory)
    before = len(X)
    X = X.dropna(subset=["pct_change_target"]).copy()
    print(f"Loaded: {len(X):,} rows (dropped {before-len(X):,} no-target), "
          f"{len(X.columns)} cols, {time.time()-t0:.0f}s", flush=True)

    # ── Compute factors ──
    print("\nComputing factors...", flush=True)
    compute_factors(X)

    # ── Feature selection ──
    all_features = [c for c in X.columns if c not in (
        "ticker", "date", "pct_change_target", "class_label",
        "target_rank", "open", "high", "low", "close", "volume", "adj_close")]
    factor_cols = FACTORS
    raw_cols = [c for c in all_features
                if c not in factor_cols and not c.startswith("z_")]

    # Remove old z-score columns if any
    for c in list(X.columns):
        if c.startswith("z_") and c.strip("z_") not in all_features:
            del X[c]

    print(f"  Factors: {len(factor_cols)}, Raw features: {len(raw_cols)}", flush=True)
    model_features = []  # will be determined after z-scoring

    # ── Walk-forward ──
    dates = sorted(X["date"].unique())
    initial_days = config["initial_years"] * config["trading_days_per_year"]
    windows = list(walk_forward_windows(dates, initial_days, config["step_days"]))
    print(f"\nWalk-forward windows: {len(windows)}")
    print(f"  Date range: {dates[0].strftime('%Y-%m-%d')} → {dates[-1].strftime('%Y-%m-%d')}")

    all_results = []
    all_models = []
    best_excess = -99

    for window_idx, (train_end, test_start, test_end) in enumerate(windows):
        print(f"\n{'─'*65}")
        print(f"  WINDOW {window_idx+1}/{len(windows)}")
        print(f"  Train: → {train_end.strftime('%Y-%m-%d')}")
        print(f"  Test:  {test_start.strftime('%Y-%m-%d')} → {test_end.strftime('%Y-%m-%d')}")
        print(f"{'─'*65}")
        win_t0 = time.time()

        X_train = X[X["date"] <= train_end].copy()
        X_test = X[(X["date"] >= test_start) & (X["date"] <= test_end)].copy()

        if len(X_test) < 100:
            print(f"  Skipping: only {len(X_test)} test rows")
            continue

        # Compute factors + z-scores on TRAINING data
        compute_factors(X_train)
        train_factor_cols = [c for c in FACTORS if c in X_train.columns]
        train_raw_cols = [c for c in raw_cols if c in X_train.columns]
        all_z_cols = train_factor_cols + train_raw_cols

        zscore_features(X_train, all_z_cols)
        compute_risk_target(X_train, config["target_weights"])

        # Define model features from training data
        model_feats = [c for c in X_train.columns
                       if (c.startswith("z_") or c in FACTORS)
                       and c not in ("ticker", "date", "target_rank",
                                     "pct_change_target", "class_label")]
        X_train_clean = X_train.dropna(subset=["target_rank"]).copy()
        y_train_target = X_train_clean["target_rank"].values.astype(np.float32)

        # Compute same factors + z-scores on TEST data (using train moments? No — use test's own cross-section)
        compute_factors(X_test)
        zscore_features(X_test, all_z_cols)
        compute_risk_target(X_test, config["target_weights"])

        # Ensure test has same feature alignment
        for feat in model_feats:
            if feat not in X_test.columns:
                X_test[feat] = 0.0

        # ── Train 5 models ──
        dtrain = xgb.DMatrix(X_train_clean[model_feats], y_train_target)
        dtest_full = xgb.DMatrix(X_test[model_feats])

        window_models = []
        for seed_idx, seed in enumerate(config["seeds"]):
            params = config["xgb_params"].copy()
            params["seed"] = seed
            params["random_state"] = seed

            m = xgb.train(
                params,
                dtrain,
                num_boost_round=config["max_rounds"],
                early_stopping_rounds=config["early_stopping"],
                evals=[(dtrain, "train")],
                verbose_eval=False,
            )

            window_models.append(m)

        # ── Evaluate on test set ──
        test_dates = sorted(X_test["date"].unique())
        for test_date in test_dates:
            date_mask = X_test["date"] == test_date
            test_day = X_test[date_mask].copy()
            if len(test_day) < 20:
                continue

            # Ensemble prediction (average of 5 models)
            dtest_day = xgb.DMatrix(test_day[model_feats])
            preds = np.zeros(len(test_day))
            for m in window_models:
                preds += m.predict(dtest_day, iteration_range=(0, m.best_iteration + 1)) \
                    if hasattr(m, 'best_iteration') else m.predict(dtest_day)
            preds /= len(window_models)

            # Simulate
            cycle_name = test_date.strftime("%Y-%m-%d")
            actual_rets = test_day["pct_change_target"].values.astype(np.float32)
            result = simulate_cycle(preds, test_day, actual_rets, cycle_name)
            all_results.append(result)

        # ── Aggregate window results ──
        window_results = [r for r in all_results
                          if r["cycle"] >= test_start.strftime("%Y-%m-%d")
                          and r["cycle"] <= test_end.strftime("%Y-%m-%d")]
        if window_results:
            df_w = pd.DataFrame(window_results)
            w_ret = df_w["avg_return"].mean()
            w_excess = df_w["excess"].mean()
            w_win = df_w["win_rate"].mean()
            w_picks = df_w["n_picks_quality"].mean()

            # Monthly conversion
            daily_ret = (1 + w_ret / 100) ** (1 / 63) - 1 if abs(w_ret) < 100 else 0
            monthly_ret = ((1 + daily_ret) ** 21 - 1) * 100 if daily_ret else 0

            print(f"  Window {window_idx+1}: ret={w_ret:+.2f}% excess={w_excess:+.2f}% "
                  f"win={w_win:.1%} picks={w_picks:.0f} monthly={monthly_ret:+.2f}%",
                  flush=True)

        # Keep best models
        window_excess = df_w["excess"].mean() if len(window_results) > 0 else 0
        if window_excess > best_excess:
            best_excess = window_excess
            all_models = window_models

        print(f"  Time: {(time.time()-win_t0)/60:.1f} min", flush=True)

    # ── Final Summary ──
    if not all_results:
        print("No results generated")
        return

    results_df = pd.DataFrame(all_results)

    # Compute portfolio equity curve
    results_df = results_df.sort_values("cycle")
    results_df["cum_return"] = (1 + results_df["avg_return"] / 100).cumprod()
    results_df["cum_peak"] = results_df["cum_return"].cummax()
    results_df["drawdown"] = (results_df["cum_return"] - results_df["cum_peak"]) / results_df["cum_peak"] * 100

    mean_ret = results_df["avg_return"].mean()
    mean_excess = results_df["excess"].mean()
    win_rate = results_df["win_rate"].mean()
    max_dd = results_df["drawdown"].min()
    sharpe = results_df["avg_return"].mean() / results_df["avg_return"].std() * np.sqrt(252 / 63) \
        if results_df["avg_return"].std() > 0 else 0

    # Monthly conversion
    mean_daily = (1 + mean_ret / 100) ** (1 / 63) - 1 if abs(mean_ret) < 100 else 0
    monthly_ret = ((1 + mean_daily) ** 21 - 1) * 100 if mean_daily else 0

    print(f"\n{'='*65}")
    print(f"  TRAINING COMPLETE — {len(all_results)} cycles × {len(windows)} windows")
    print(f"{'='*65}")
    print(f"  Avg cycle return:   {mean_ret:+.2f}%")
    print(f"  Monthly equiv:      {monthly_ret:+.2f}%")
    print(f"  Market avg:         {results_df['market_return'].mean():+.2f}%")
    print(f"  Avg excess:         {mean_excess:+.2f}%")
    print(f"  Avg win rate:       {win_rate:.1%}")
    print(f"  Max drawdown:       {max_dd:.2f}%")
    print(f"  Sharpe (annual):    {sharpe:.2f}")
    print(f"  Avg picks (quality): {results_df['n_picks_quality'].mean():.0f}")
    print(f"{'='*65}")

    # Target check
    print(f"\n  TARGET CHECK:")
    print(f"  4%+ monthly:  {'✓' if monthly_ret >= 4 else '✗'} ({monthly_ret:+.2f}%)")
    print(f"  <5% max DD:   {'✓' if abs(max_dd) < 5 else '✗'} ({max_dd:.2f}%)")
    print(f"  70%+ win rate:{'✓' if win_rate >= 0.70 else '✗'} ({win_rate:.1%})")

    # ── Save final models ──
    timestamp = int(time.time())
    for i, m in enumerate(all_models[-5:]):  # last window's models
        seed = config["seeds"][i % len(config["seeds"])]
        path = MODELS_DIR / f"f_flag_risk_s{seed}_r{monthly_ret:.1f}pct_v{timestamp}.json"
        m.save_model(str(path))
        print(f"  Saved: {path.name}")

    # Save results
    results_path = Path(sys.path[0]) / "stockpredict2/data/training_results.csv"
    results_df.to_csv(results_path, index=False)
    print(f"\n  Results: {results_path}")

    # Save config + summary
    summary = {
        "timestamp": timestamp,
        "config": config,
        "results": {
            "n_cycles": len(results_df),
            "n_windows": len(windows),
            "avg_return": round(mean_ret, 2),
            "monthly_return": round(monthly_ret, 2),
            "excess": round(mean_excess, 2),
            "win_rate": round(float(win_rate), 4),
            "max_drawdown": round(float(max_dd), 2),
            "sharpe": round(float(sharpe), 2),
            "n_models_saved": len(all_models[-5:]),
        },
    }
    summary_path = MODELS_DIR / f"training_summary_v{timestamp}.json"
    with open(summary_path, "w") as f:
        json.dump(summary, f, indent=2)
    print(f"  Summary: {summary_path}")

    return summary


if __name__ == "__main__":
    train_and_evaluate()