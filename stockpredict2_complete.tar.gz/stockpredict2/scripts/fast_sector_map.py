#!/usr/bin/env python3
"""Fast sector map builder using yfinance (handles Yahoo auth internally)."""
import sys, json, time, os
from concurrent.futures import ThreadPoolExecutor, as_completed
sys.path.insert(0, os.path.expanduser('~/Documents/AI Training'))

import yfinance as yf
from stockpredict2.collectors.ticker_list import get_ticker_symbols

OUT = os.path.expanduser('~/Documents/AI Training/stockpredict2/data/ticker_sector.json')
BATCH = int(sys.argv[sys.argv.index('--batch')+1]) if '--batch' in sys.argv else 500

# Load existing + seed S&P 500
sector_map = {}
if os.path.exists(OUT):
    with open(OUT) as f:
        sector_map = json.load(f)

# Always seed S&P 500
import requests
try:
    resp = requests.get(
        'https://raw.githubusercontent.com/datasets/s-and-p-500-companies/main/data/constituents.csv',
        timeout=10)
    if resp.status_code == 200:
        for line in resp.text.strip().split('\n')[1:]:
            parts = line.split(',')
            if len(parts) >= 3:
                sector_map[parts[0]] = parts[2]
except Exception:
    pass

tickers = get_ticker_symbols()
remaining = [t for t in tickers if t not in sector_map or sector_map.get(t) == "Unknown"]
print(f"Sector map: {len(sector_map)} mapped, {len(remaining)} remaining, batch={BATCH}")

to_process = remaining[:BATCH]
if not to_process:
    print("All done!")
    sys.exit(0)

def fetch_sector(ticker):
    """Get sector from yfinance .info (handles auth internally)."""
    try:
        t = yf.Ticker(ticker)
        info = t.info
        if isinstance(info, dict):
            sec = info.get('sector')
            if sec:
                return ticker, str(sec)
    except Exception:
        pass
    return ticker, "Unknown"

saved = sum(1 for v in sector_map.values() if v != "Unknown")
start = time.time()

with ThreadPoolExecutor(max_workers=5) as pool:
    futures = {pool.submit(fetch_sector, t): t for t in to_process}
    for i, future in enumerate(as_completed(futures)):
        t, sec = future.result()
        if sec != "Unknown":
            sector_map[t] = sec
            saved += 1
        else:
            sector_map.setdefault(t, "Unknown")
        
        if (i + 1) % 100 == 0:
            rate = (i + 1) / max((time.time() - start) / 60, 0.01)
            elapsed = (time.time() - start) / 60
            print(f"  [{i+1}/{len(to_process)}] {saved} found, {rate:.0f}/min, {elapsed:.1f}min", flush=True)

with open(OUT, 'w') as f:
    json.dump(sector_map, f)

found = sum(1 for v in sector_map.values() if v != "Unknown")
print(f"Done: {found}/{len(tickers)} mapped in {(time.time()-start)/60:.1f} min")