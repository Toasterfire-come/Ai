#!/usr/bin/env python3
"""Run analyst collection in batches (250 at a time, resumable)."""
import sys, time
import pandas as pd
sys.path.insert(0, '/Users/ckiefer/Documents/AI Training')

from stockpredict2.collectors.analyst_collector import fetch_analyst_consensus_http
from stockpredict2.collectors.ticker_list import get_ticker_symbols
from stockpredict2.storage import CheckpointTracker, ParquetStore

cp = CheckpointTracker()
tickers = get_ticker_symbols()
remaining = cp.get_remaining("analyst", tickers)
print(f"Analyst: {len(tickers)} total, {len(remaining)} remaining")

batch = remaining[:250]
if not batch:
    print("All analyst data collected!")
    sys.exit(0)

succeeded = 0
start = time.time()
for i, ticker in enumerate(batch):
    try:
        result = fetch_analyst_consensus_http(ticker)
        if result:
            df = pd.DataFrame([result])
            ParquetStore.save_analyst(ticker, df)
            cp.mark_completed("analyst", ticker, rows=1)
            succeeded += 1
        else:
            cp.mark_completed("analyst", ticker, rows=0)
    except Exception:
        cp.mark_completed("analyst", ticker, rows=0)

    if (i + 1) % 50 == 0:
        rate = (i + 1) / max((time.time() - start), 1) * 60
        print(f"  [{i+1}/{len(batch)}] {succeeded} ok, {rate:.0f}/min")

elapsed = (time.time() - start) / 60
print(f"Batch done: {succeeded}/{len(batch)} with data in {elapsed:.1f} min")