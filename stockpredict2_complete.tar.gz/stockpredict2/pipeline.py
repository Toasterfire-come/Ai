"""
Pipeline Orchestrator — runs data collection phases sequentially with resume support.
"""
import sys, time
from datetime import datetime
from typing import Dict, List, Optional

from .collectors.ticker_list import get_all_listed, get_ticker_symbols, get_exchange_counts
from .collectors.price_collector import run_price_collection, compute_all_technical_indicators, price_data_stats
from .collectors.fundamentals_collector import run_fundamentals_collection
from .collectors.news_collector import run_news_collection
from .collectors.analyst_collector import run_analyst_collection
from .collectors.macro_collector import run_macro_collection
from .collectors.form4_collector import run_form4_collection
from .storage import CheckpointTracker


def run_full_pipeline(tickers: List[str] = None,
                      run_prices: bool = True,
                      run_technicals: bool = True,
                      run_fundamentals: bool = True,
                      run_news: bool = True,
                      run_analyst: bool = True,
                      run_macro: bool = True,
                      run_form4: bool = True,
                      resume: bool = True,
                      quiet: bool = False) -> Dict:
    """Run all data collection phases in sequence. Each phase independently resumable."""
    results = {}

    if tickers is None:
        if not quiet:
            print("Getting ticker list...")
        all_tickers = get_ticker_symbols()
        tickers = all_tickers
    else:
        all_tickers = tickers

    print(f"\n╔══ DATA PIPELINE v2 ══════════════════════════════════╗")
    print(f"║  Tickers:    {len(tickers):>8,}                         ║")
    print(f"║  Date range: 2016 - {datetime.today().year}                    ║")
    print(f"╚═══════════════════════════════════════════════════════╝\n")

    phases = []
    if run_prices:
        phases.append("prices")
    if run_fundamentals:
        phases.append("fundamentals")
    if run_news:
        phases.append("news")
    if run_analyst:
        phases.append("analyst")
    if run_macro:
        phases.append("macro")
    if run_form4:
        phases.append("form4")
    if run_technicals and not run_prices:
        phases.append("technicals")

    for phase in phases:
        print(f"\n{'─'*58}")
        print(f"  PHASE: {phase.upper()}")
        print(f"{'─'*58}")
        t0 = time.time()

        if phase == "prices":
            result = run_price_collection(tickers, resume=resume, quiet=quiet)
            results["prices"] = result
        elif phase == "technicals":
            compute_all_technical_indicators(tickers)
        elif phase == "fundamentals":
            result = run_fundamentals_collection(tickers, resume=resume, quiet=quiet)
            results["fundamentals"] = result
        elif phase == "news":
            result = run_news_collection(tickers=tickers, resume=resume)
            results["news"] = result
        elif phase == "analyst":
            result = run_analyst_collection(tickers, resume=resume)
            results["analyst"] = result
        elif phase == "macro":
            result = run_macro_collection()
            results["macro"] = result
        elif phase == "form4":
            result = run_form4_collection(resume=resume)
            results["form4"] = result

        mins = (time.time() - t0) / 60
        print(f"  Duration: {mins:.1f} min")

    print(f"\n{'═'*58}")
    print("  PIPELINE COMPLETE")
    print(f"{'═'*58}")
    for k, v in results.items():
        succ = v.get("succeeded", v.get("total", "?"))
        print(f"  {k:12s}: {succ}")
    print()
    return results


def run_phase(phase: str, tickers: List[str] = None, **kwargs):
    """Run a single phase. Used for manual resumption."""
    if tickers is None:
        tickers = get_ticker_symbols()
    phases = {
        "prices": lambda: run_price_collection(tickers, **kwargs),
        "fundamentals": lambda: run_fundamentals_collection(tickers, **kwargs),
        "news": lambda: run_news_collection(tickers=tickers, **kwargs),
        "analyst": lambda: run_analyst_collection(tickers, **kwargs),
        "macro": lambda: run_macro_collection(**kwargs),
        "form4": lambda: run_form4_collection(**kwargs),
        "technicals": lambda: compute_all_technical_indicators(tickers),
    }
    if phase not in phases:
        raise ValueError(f"Unknown phase: {phase}. Choose: {', '.join(phases.keys())}")
    return phases[phase]()


def show_status():
    """Show current pipeline collection status."""
    cp = CheckpointTracker()
    summary = cp.get_summary()
    tickers = get_ticker_symbols()

    print(f"\n╔══ Pipeline Status ════════════════════════════════════╗")
    print(f"║  Total tickers in universe: {len(tickers):>5,}              ║")
    print(f"║  Data sources:                                            ║")

    if not summary:
        print(f"║    No data collected yet.                               ║")
        print(f"╚═════════════════════════════════════════════════════════╝")
        return

    for phase in ["prices", "fundamentals", "news", "analyst", "macro", "form4"]:
        if phase in summary:
            d = summary[phase]
            pct = d["done"] / max(d["total"], 1) * 100
            label = f"  {phase:12s}"
            bar_len = 20
            filled = int(pct / 100 * bar_len)
            bar = "█" * filled + "░" * (bar_len - filled)
            print(f"║{label} {bar} {pct:5.1f}%  {d['done']:>4}/{d['total']:<4}  {d['rows']:>8,} rows  ║")
    print(f"╚═════════════════════════════════════════════════════════╝")