"""
Free proxy pool — rotating proxies for Yahoo Finance scrapers.
Pulls proxies from free public lists and validates them.
"""
import random, time, threading
from typing import List, Optional, Dict
from urllib.parse import urlparse

import requests


class ProxyPool:
    """Thread-safe rotating proxy pool with health checking."""

    def __init__(self, min_workers: int = 5):
        self._lock = threading.Lock()
        self._proxies: List[Dict] = []  # [{"http": "...", "https": "..."}, ...]
        self._idx = 0
        self._min_workers = min_workers
        self._last_refresh = 0
        self._refresh()

    def _fetch_free_proxies(self) -> List[str]:
        """Fetch free proxies from public sources."""
        urls = [
            "https://api.proxyscrape.com/v3/free-proxy-list/get?"
            "request=displayproxies&protocol=http&timeout=5000&country=all&ssl=all&anonymity=all",
            "https://raw.githubusercontent.com/TheSpeedX/PROXY-List/master/http.txt",
            "https://raw.githubusercontent.com/zevtyardt/proxy-list/main/http.txt",
        ]
        all_proxies = set()
        for url in urls:
            try:
                resp = requests.get(url, timeout=15,
                    headers={"User-Agent": "Mozilla/5.0"})
                if resp.status_code == 200:
                    for line in resp.text.strip().split("\n"):
                        p = line.strip()
                        if p and ":" in p and not p.startswith("//"):
                            all_proxies.add(p.split("#")[0].strip())
            except Exception:
                continue
        return list(all_proxies)

    def _validate_proxy(self, proxy: str) -> Optional[Dict]:
        """Quick validation — can it reach Yahoo?"""
        proxies = {"http": f"http://{proxy}", "https": f"http://{proxy}"}
        try:
            resp = requests.get("https://finance.yahoo.com", proxies=proxies,
                                timeout=3, headers={"User-Agent": "Mozilla/5.0"})
            if resp.status_code == 200:
                return proxies
        except Exception:
            pass
        return None

    def _refresh(self):
        """Fetch fresh proxies and validate them."""
        raw = self._fetch_free_proxies()
        print(f"  Proxy pool: {len(raw)} raw, validating 50...", flush=True)
        valid = []
        sample = random.sample(raw, min(len(raw), 50))
        for p in sample:
            result = self._validate_proxy(p)
            if result:
                valid.append(result)
        with self._lock:
            self._proxies = valid
            self._idx = 0
            self._last_refresh = time.time()
        print(f"  Proxy pool: {len(valid)} valid Yahoo proxies", flush=True)

    def get(self) -> Optional[Dict]:
        """Get next proxy in round-robin. Refreshes pool if low."""
        with self._lock:
            if time.time() - self._last_refresh > 600:  # refresh every 10 min
                self._refresh()
            if len(self._proxies) < self._min_workers:
                self._refresh()
            if not self._proxies:
                return None
            proxy = self._proxies[self._idx % len(self._proxies)]
            self._idx += 1
            return proxy

    def report_bad(self, proxy: Dict):
        """Remove a bad proxy from the pool."""
        with self._lock:
            if proxy in self._proxies:
                self._proxies.remove(proxy)

    @property
    def count(self) -> int:
        with self._lock:
            return len(self._proxies)


# Global singleton
_pool = None

def get_proxy_pool() -> ProxyPool:
    global _pool
    if _pool is None:
        _pool = ProxyPool()
    return _pool


def fetch_with_proxies(url: str, pool: ProxyPool = None,
                        max_retries: int = 3, **kwargs) -> Optional[requests.Response]:
    """Fetch a URL with automatic proxy rotation on failure."""
    pool = pool or get_proxy_pool()
    headers = kwargs.pop("headers", {})
    headers.setdefault("User-Agent", "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7)")

    for attempt in range(max_retries):
        proxy = pool.get()
        try:
            resp = requests.get(url, proxies=proxy, headers=headers,
                                timeout=kwargs.pop("timeout", 15), **kwargs)
            if resp.status_code == 200:
                return resp
            if resp.status_code in (429, 403):
                pool.report_bad(proxy)
        except Exception:
            if proxy:
                pool.report_bad(proxy)
    return None