#!/usr/bin/env python3
"""
stockpredict2 CLI.
"""
import sys


def main():
    if len(sys.argv) < 2:
        print(__doc__)
        return

    cmd = sys.argv[1]
    args = sys.argv[2:]

    if cmd == "pipeline":
        from .pipeline import run_full_pipeline, show_status, run_phase
        from .collectors.ticker_list import get_all_listed, get_exchange_counts

        sub = args[0] if args else "help"
        if sub == "run":
            run_full_pipeline()
        elif sub == "status":
            show_status()
        elif sub == "tickers":
            print("Discovering exchange tickers...")
            get_all_listed()
            counts = get_exchange_counts()
            for exchange, count in sorted(counts.items()):
                print(f"  {exchange}: {count}")
        elif sub in ("prices", "fundamentals", "news", "analyst", "macro", "form4", "technicals"):
            run_phase(sub, resume=True)
        else:
            print(f"Unknown pipeline subcommand: {sub}")
            print("  pipeline run        — full pipeline")
            print("  pipeline status     — show progress")
            print("  pipeline tickers    — discover tickers")
            print("  pipeline prices     — prices only")
            print("  pipeline fundamentals — fundamentals only")
            print("  pipeline news        — news only")
            print("  pipeline analyst     — analyst consensus only")
            print("  pipeline macro       — macro data only")
            print("  pipeline form4       — insider trades only")

    elif cmd == "build-fm":
        from .scripts.build_feature_matrix import build_feature_matrix
        build_feature_matrix()

    else:
        print(f"Unknown command: {cmd}")
        print(__doc__)