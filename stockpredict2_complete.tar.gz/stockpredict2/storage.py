"""
Scalable Storage Layer — Parquet-backed per-ticker data store with SQLite checkpoints.
"""
import json, sqlite3
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, Tuple, Union

import numpy as np
import pandas as pd

from .config import (PRICES_DIR, FINANCIALS_DIR, NEWS_RAW_DIR, NEWS_AGG_DIR,
                     MACRO_DIR, FORM4_DIR, ANALYST_DIR, EVENTS_DIR, DATA_DIR)


class CheckpointTracker:
    """SQLite-based checkpoint tracker with resume support."""

    def __init__(self):
        self.db_path = str(DATA_DIR / "checkpoint.db")
        self._init_db()

    def _conn(self):
        conn = sqlite3.connect(self.db_path)
        conn.execute("PRAGMA journal_mode=WAL")
        return conn

    def _init_db(self):
        with self._conn() as conn:
            conn.executescript("""
                CREATE TABLE IF NOT EXISTS checkpoints (
                    phase TEXT NOT NULL,
                    ticker TEXT NOT NULL,
                    completed_at TEXT DEFAULT (datetime('now')),
                    rows_count INTEGER DEFAULT 0,
                    error TEXT,
                    PRIMARY KEY (phase, ticker)
                );
                CREATE TABLE IF NOT EXISTS pipeline_state (
                    phase TEXT PRIMARY KEY,
                    status TEXT NOT NULL,
                    started_at TEXT,
                    completed_at TEXT,
                    total INTEGER DEFAULT 0,
                    completed INTEGER DEFAULT 0,
                    errors INTEGER DEFAULT 0
                );
            """)

    def is_completed(self, phase: str, ticker: str) -> bool:
        with self._conn() as conn:
            row = conn.execute(
                "SELECT 1 FROM checkpoints WHERE phase=? AND ticker=? AND error IS NULL",
                (phase, ticker)
            ).fetchone()
            return row is not None

    def mark_completed(self, phase: str, ticker: str, rows: int = 0):
        with self._conn() as conn:
            conn.execute(
                "INSERT OR REPLACE INTO checkpoints (phase, ticker, rows_count) VALUES (?, ?, ?)",
                (phase, ticker, rows)
            )

    def mark_error(self, phase: str, ticker: str, error: str):
        with self._conn() as conn:
            conn.execute(
                "INSERT OR REPLACE INTO checkpoints (phase, ticker, error) VALUES (?, ?, ?)",
                (phase, ticker, error)
            )

    def get_remaining(self, phase: str, all_tickers: List[str]) -> List[str]:
        completed = set()
        with self._conn() as conn:
            rows = conn.execute(
                "SELECT ticker FROM checkpoints WHERE phase=? AND error IS NULL",
                (phase,)
            ).fetchall()
            completed = {r[0] for r in rows}
        return [t for t in all_tickers if t not in completed]

    def get_summary(self, phase: str = None) -> Dict:
        with self._conn() as conn:
            if phase:
                rows = conn.execute(
                    "SELECT phase, COUNT(*), SUM(rows_count), "
                    "SUM(CASE WHEN error IS NULL THEN 1 ELSE 0 END) as done, "
                    "SUM(CASE WHEN error IS NOT NULL THEN 1 ELSE 0 END) as errs "
                    "FROM checkpoints WHERE phase=? GROUP BY phase",
                    (phase,)
                ).fetchall()
            else:
                rows = conn.execute(
                    "SELECT phase, COUNT(*), SUM(rows_count), "
                    "SUM(CASE WHEN error IS NULL THEN 1 ELSE 0 END) as done, "
                    "SUM(CASE WHEN error IS NOT NULL THEN 1 ELSE 0 END) as errs "
                    "FROM checkpoints GROUP BY phase"
                ).fetchall()
        return {r[0]: {"total": r[1], "rows": r[2] or 0, "done": r[3], "errors": r[4]}
                for r in rows}

    def start_phase(self, phase: str, total: int):
        with self._conn() as conn:
            conn.execute(
                "INSERT OR REPLACE INTO pipeline_state "
                "(phase, status, started_at, total, completed, errors) "
                "VALUES (?, 'running', datetime('now'), ?, 0, 0)",
                (phase, total)
            )

    def finish_phase(self, phase: str, status: str = "completed"):
        with self._conn() as conn:
            conn.execute(
                "UPDATE pipeline_state SET status=?, completed_at=datetime('now') "
                "WHERE phase=?", (status, phase)
            )


class ParquetStore:
    """Per-ticker parquet storage — one file per ticker per data type."""

    @staticmethod
    def save_price(ticker: str, df: pd.DataFrame):
        path = PRICES_DIR / f"{ticker}.parquet"
        if df.empty:
            return
        expected = ["date", "open", "high", "low", "close", "volume",
                     "adj_close", "dividend", "stock_split"]
        for c in expected:
            if c not in df.columns:
                df[c] = 0.0 if c != "date" else ""
        df = df[expected]
        df.to_parquet(path, index=False)

    @staticmethod
    def load_price(ticker: str) -> pd.DataFrame:
        path = PRICES_DIR / f"{ticker}.parquet"
        if not path.exists():
            return pd.DataFrame()
        df = pd.read_parquet(path)
        if "date" in df.columns:
            df["date"] = pd.to_datetime(df["date"])
        return df

    @staticmethod
    def price_exists(ticker: str) -> bool:
        return (PRICES_DIR / f"{ticker}.parquet").exists()

    @staticmethod
    def list_prices() -> List[str]:
        return [p.stem for p in PRICES_DIR.glob("*.parquet")]

    @staticmethod
    def save_financial(ticker: str, df: pd.DataFrame):
        path = FINANCIALS_DIR / f"{ticker}.parquet"
        if not df.empty:
            df.to_parquet(path, index=False)

    @staticmethod
    def load_financial(ticker: str) -> pd.DataFrame:
        path = FINANCIALS_DIR / f"{ticker}.parquet"
        if not path.exists():
            return pd.DataFrame()
        return pd.read_parquet(path)

    @staticmethod
    def financial_exists(ticker: str) -> bool:
        return (FINANCIALS_DIR / f"{ticker}.parquet").exists()

    @staticmethod
    def save_news_weekly(year_week: str, articles: pd.DataFrame):
        path = NEWS_RAW_DIR / f"{year_week}.parquet"
        if path.exists():
            existing = pd.read_parquet(path)
            articles = pd.concat([existing, articles], ignore_index=True)
            articles = articles.drop_duplicates(subset=["ticker", "date", "title"])
        if not articles.empty:
            articles.to_parquet(path, index=False)

    @staticmethod
    def load_news_aggregated(ticker: str) -> pd.DataFrame:
        path = NEWS_AGG_DIR / f"{ticker}.parquet"
        if not path.exists():
            return pd.DataFrame()
        return pd.read_parquet(path)

    @staticmethod
    def save_news_aggregated(ticker: str, df: pd.DataFrame):
        path = NEWS_AGG_DIR / f"{ticker}.parquet"
        if not df.empty:
            df.to_parquet(path, index=False)

    @staticmethod
    def save_form4(ticker: str, df: pd.DataFrame):
        path = FORM4_DIR / f"{ticker}.parquet"
        if not df.empty:
            df.to_parquet(path, index=False)

    @staticmethod
    def load_form4(ticker: str) -> pd.DataFrame:
        path = FORM4_DIR / f"{ticker}.parquet"
        if not path.exists():
            return pd.DataFrame()
        return pd.read_parquet(path)

    @staticmethod
    def save_macro(sid: str, df: pd.DataFrame):
        path = MACRO_DIR / f"{sid}.parquet"
        if not df.empty:
            df.to_parquet(path, index=False)

    @staticmethod
    def load_macro() -> pd.DataFrame:
        """Load and merge all saved macro series."""
        merged = None
        for f in sorted(MACRO_DIR.glob("*.parquet")):
            df = pd.read_parquet(f)
            if merged is None:
                merged = df
            else:
                merged = pd.merge(merged, df, on="date", how="outer")
        if merged is not None:
            merged = merged.sort_values("date").ffill().bfill().fillna(0)
        return merged

    @staticmethod
    def save_analyst(ticker: str, df: pd.DataFrame):
        path = ANALYST_DIR / f"{ticker}.parquet"
        if not df.empty:
            df.to_parquet(path, index=False)

    @staticmethod
    def load_analyst(ticker: str) -> pd.DataFrame:
        path = ANALYST_DIR / f"{ticker}.parquet"
        if not path.exists():
            return pd.DataFrame()
        return pd.read_parquet(path)

    @staticmethod
    def save_events(ticker: str, df: pd.DataFrame):
        path = EVENTS_DIR / f"{ticker}.parquet"
        if not df.empty:
            df.to_parquet(path, index=False)

    @staticmethod
    def load_events(ticker: str) -> pd.DataFrame:
        path = EVENTS_DIR / f"{ticker}.parquet"
        if not path.exists():
            return pd.DataFrame()
        return pd.read_parquet(path)

    @staticmethod
    def total_storage_gb() -> float:
        total = 0
        for d in [PRICES_DIR, FINANCIALS_DIR, NEWS_RAW_DIR, NEWS_AGG_DIR,
                  MACRO_DIR, FORM4_DIR, ANALYST_DIR, EVENTS_DIR]:
            if d.exists():
                total += sum(f.stat().st_size for f in d.glob("*.parquet"))
        return total / (1024 ** 3)