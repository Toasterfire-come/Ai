# Training Plan: Low-Risk 4%+/Month Stock Selection System

Based on all prior research across ~22 backtest scripts and 3 years of modeling.

## Core Insight — What Actually Works

Everything learned from the old system:

| Approach | Result | Verdict |
|----------|--------|---------|
| Full-universe f_flag models (sector-enhanced) | +55-63%/cycle, 95% win | **Proven best — use this** |
| Quality-trained q_c* models (old 62-feature) | +6.51%/cycle, 87% stopped | Works but trail-stop kills returns |
| q_flag models (sector-enhanced, quality data) | 0 non-zero cycles | **Broken — never use** |
| VIX / fear/greed gates | Missed Jan 2025 crash | **Unreliable — skip** |
| Pre-filter then train | Kills signal entirely | **Post-filter only** |

The key: **train on full universe f_flag, then quality-filter the picks, not the data.**

---

## Architecture: 3-Tier Ensemble

### Tier 1: Market Regime Filter (Go With The Market)

Not a model — a simple rule:

```
SPY > 200-day SMA  → risk-on   (100% capital deployed)
SPY < 200-day SMA  → risk-off  (50% capital deployed)
SPY crash >5% in 5d → halt     (0 new buys, hold cash)
```

This is the "go with the market" requirement. Don't overthink it — VIX and fear/greed failed historically. Simple trend filter is the most reliable.

### Tier 2: Stock Selection Model (f_flag)

**Input**: All data from stockpredict2 pipeline
- 19 price/technical features
- 14 factor features (momentum, quality, value, risk, technical, size)
- 9+ fundamentals from SEC XBRL (market cap, ROE, margins, FCF, P/E, etc.)
- 6 market context (breadth, dispersion)
- 13 macro/FRED (yields, production, housing, employment)
- 18 sector ETF returns (11 sectors × 5d/21d/63d)
- 5 news sentiment (pos/neg/neu, article count, rolling)
- 3 analyst consensus (target upside, recommendation, count)
- 2 insider trades (90d buys, 90d sells)
= ~90 raw features → z-scored cross-sectionally → ~170 z-score features
+ 8 interaction features (multiply z-scores)
+ 6 sector z-scores (sz_mom_6m, sz_quality, sz_earn_yield, sz_trend_str, sz_fcf_yield, sz_mom_1m)
+ 6 mean-difference features (md_* for same 6 factors)
= **~190 total features**

**Target**: Risk-aware rank (NOT raw return, NOT pure percentile)

```python
ret_rank = percentile rank of forward 63d return
vol_z = z-score of volatility_21d  (high = bad)
dd_z = z-score of max_dd_90d     (high = bad)
beta_z = z-score of beta          (high = bad)
quality = (ROE + gross_margin) / 2 (high = good)

target = ret_rank - vol_z*15 - dd_z*10 - beta_z*8 + quality*5
# Re-rank back to 0-100 within each date
```

This teaches the model to find stocks with high upside AND low volatility/drawdown — stocks that will pass the post-quality filter naturally.

**Model**: XGBoost regressor on rank target
- 5 seeds: [42, 99, 107, 203, 555]
- 2000 max rounds, early stopping 80
- objective: reg:squarederror
- max_depth: 6 (shallower = less overfit for risk)
- learning_rate: 0.03, subsample: 0.8, colsample_bytree: 0.7
- min_child_weight: 10 (higher = more conservative)

**Walk-forward**: Train on expanding windows, test on next 63 trading days.
- First window: 3 years initial training
- Step: 63 trading days forward
- This simulates real deployment more accurately than a single split

### Tier 3: Post-Filter + Position Sizing (Avoid Risk)

After scoring, apply in order:

```
1. Risk filters: price >= $5, equity >= $300M, vol_sma_20 >= 100K
2. Remove bottom 20% volatility (top 80% only)
3. Remove stocks with no positive EPS or no positive FCF (quality screen)
4. Keep top 1% of remaining stocks (= ~15-25 picks depending on universe size)
5. Equal-weight all picks (max 10% per position)
6. Sector cap: max 20% per sector
7. Apply market regime sizing from Tier 1
```

**This is the "avoid risk" requirement.** The post-quality filter means all picks are real companies with real equity and earnings.

---

## Training Pipeline

### Step 1: Collect and merge all data

```bash
cd /Users/ckiefer/Documents/AI\ Training/stockpredict2
PYTHONPATH=$PWD

# Full data collection (resumable, ~20 hrs on first run)
python3 -m stockpredict2 pipeline run

# Build feature matrix
python3 -m stockpredict2 build-fm
```

### Step 2: Train 5 f_flag risk-aware models

```python
# Pseudocode for training script
fm = load_feature_matrix()

# Compute factors
for ticker, group in fm.groupby("ticker"):
    compute_factors(group)
    compute_technicals(group)

# Z-score cross-sectionally (vectorized, per date)
for col in feature_cols:
    means = fm.groupby("date")[col].transform("mean")
    stds = fm.groupby("date")[col].transform("std").replace(0, 1e-8)
    fm[f"z_{col}"] = ((fm[col] - means) / stds).fillna(0).astype(np.float32)

# Compute risk-aware target
for date in fm["date"].unique():
    mask = fm["date"] == date
    g = fm[mask]
    ret_rank = g["pct_change_target"].rank(pct=True)
    vol_z = g["z_p_volatility_21d"].fillna(0)
    dd_z = g["z_max_dd_90d"].fillna(0)
    beta_z = (g.get("z_beta", pd.Series(0)).fillna(0))
    qual = g.get("quality", pd.Series(0)).fillna(0)
    target = ret_rank - vol_z*0.15 - dd_z*0.10 - beta_z*0.08 + qual*0.05
    fm.loc[mask, "target_rank"] = target.rank(pct=True).values * 100

# Walk-forward training
windows = create_windows(dates, initial=3*252, step=63)
for train_dates, test_dates in windows:
    train = fm[fm["date"].isin(train_dates)]
    test = fm[fm["date"].isin(test_dates)]

    for seed in [42, 99, 107, 203, 555]:
        model = xgb.train(params, 
                          xgb.DMatrix(train[features], train["target_rank"]),
                          evals=[(test_matrix, "test")],
                          early_stopping_rounds=80)
        
        # Score and simulate portfolio
        test["pred"] = model.predict(test_matrix)
        for date in test["date"].unique():
            picks = test[test["date"] == date].nlargest(int(len(test)*0.01), "pred")
            picks = picks[picks["p_sma_10"] >= 5.0]  # post-filter
            # Track returns
            record_cycle(date, picks.mean("pct_change_target"))
        
        save_model(model, f"f_flag_risk_s{seed}_v{timestamp}.json")
```

### Step 3: Validate

Metrics to validate each walk-forward window:

```
Win rate:     % of positive cycles
Avg return:   mean cycle return (convert to monthly: (1+ret)^(21/63)-1)
Max DD:       peak-to-trough of portfolio equity curve
Sharpe:       mean / std of returns × sqrt(252/63)
Stop rate:    % of cycles that hit trailing stop
```

Target thresholds:
- Win rate: ≥ 70%
- Monthly return: ≥ 4% (≈ 12.6% per 63d cycle)
- Max DD: ≤ 5%
- Sharpe: ≥ 1.0

---

## Risk Controls (Implementation)

### Hard Protection (always on)

```
1. Post-quality filter at pick time: $5+, $300M+, 100K vol, positive EPS, positive FCF
2. Equal-weight across all picks (no concentration)
3. Max 20% per sector
4. 30-day minimum hold (reduces churn, +5pp win rate improvement proven)
5. 10% trailing stop per position (insurance only — rarely fires, catches outliers)
6. Circuit breaker: VIX>40 or SPY crash → halt new buys
```

### Soft Protection (market-dependent)

```
1. SPY < 200-SMA → 50% capital (go with the market when it's down)
2. Reduce position count in high-VIX environments (vol is a risk factor already in model)
```

### Diversification Target

| Universe Size | Picks | Per-position Max | Sectors Covered |
|:------------:|:-----:|:----------------:|:---------------:|
| 6,500 tickers | 15-25 | 5-6.7% | 5+ different sectors |

---

## Expected Performance (Conservative Estimate)

Based on what the f_flag models achieved historically, adjusted for risk-aware target and post-quality filter:

| Metric | Pure Profit (historical) | Risk-Aware + Post-Quality | Target | 
|--------|:-----------------------:|:-------------------------:|:------:|
| Monthly return | ~+8% | **~+4-6%** | ≥ +4% |
| Win rate | 82-95% | **~75-85%** | ≥ 70% |
| Max DD | 0-3% | **~3-5%** | ≤ 5% |
| Sharpe | 1.0+ | **~1.2-1.5** | ≥ 1.0 |
| Avg picks | 22 | **15-25** | Diversified |

The risk-aware target will reduce returns vs pure profit (expected: from ~+8%/mo to ~+5%/mo) but dramatically improve stability. The post-quality filter eliminates the penny stock outliers.

---

## Execution Order

```python
# 1. Run full pipeline (one-time data collection)
pipeline run

# 2. Build feature matrix with risk-aware targets
build-fm

# 3. Train 5 f_flag_risk models with walk-forward
python3 train_risk_aware.py

# 4. Validate: check win rate, DD, monthly return across windows
#    Retrain if any window misses targets

# 5. Daily: score → post-filter → equal-weight → compare to SPY 200-SMA → trade

# 6. Auto-retrain: 1st of every month (keeps models fresh)
```

The key files needed in stockpredict2:
- `scripts/train_risk_model.py` — full walk-forward training with risk-aware target
- `scripts/daily_trader.py` — production scoring + portfolio management
- `scripts/risk_analysis.py` — post-trade validation

These are the next build targets after we verify the data pipeline produces clean output.