"""
Async data manager — concurrent price fetching for Windows.
Uses aiohttp for parallel API calls, ProcessPoolExecutor for scoring.
"""
import asyncio, json, time
from pathlib import Path
from typing import Dict, List, Optional

import numpy as np
import pandas as pd
import yfinance as yf

DATA_DIR = Path(__file__).resolve().parent.parent / "data"
MODELS_DIR = Path(__file__).resolve().parent.parent / "models"

# ── Model cache ──
_model = None
_expected_features = None

def _load_model():
    global _model, _expected_features
    if _model is not None:
        return _model, _expected_features
    import xgboost as xgb
    model_files = sorted(MODELS_DIR.glob("f_flag_v2_s42_r*.json"))
    if not model_files:
        raise FileNotFoundError("No model files found")
    _model = xgb.Booster()
    _model.load_model(str(model_files[-1]))
    _expected_features = list(_model.feature_names)
    return _model, _expected_features


def compute_factors(df: pd.DataFrame) -> pd.DataFrame:
    """Compute all factor features from raw price data (vectorized)."""
    df = df.copy()
    price = df.get("p_sma_10", pd.Series(1, index=df.index)).replace(0, 1)
    eps = df.get("f_eps", pd.Series(0, index=df.index)).fillna(0)
    eq = df.get("f_equity", pd.Series(0, index=df.index)).fillna(0)
    roe = df.get("f_roe", pd.Series(0, index=df.index)).fillna(0)
    gm = df.get("f_gross_margin", pd.Series(0, index=df.index)).fillna(0)
    fcf = df.get("f_free_cash_flow", pd.Series(0, index=df.index)).fillna(0)
    rsi = df.get("p_rsi_14", pd.Series(50, index=df.index)).fillna(50)
    iv = df.get("p_volatility_21d", pd.Series(0, index=df.index)).fillna(0)
    mv = df.get("m_VIX_CLOSE", pd.Series(15, index=df.index)).fillna(15).replace(0, 1)
    vr = df.get("p_vol_ratio", pd.Series(1, index=df.index)).fillna(1)
    bb = df.get("p_bb_width", pd.Series(0, index=df.index)).fillna(0)
    s50 = df.get("p_sma_50", pd.Series(0, index=df.index))
    s200 = df.get("p_sma_200", pd.Series(1, index=df.index)).replace(0, 1)

    df["mom_6m"] = df.get("p_pct_change_21d", 0).fillna(0)
    df["mom_1m"] = df.get("p_pct_change_5d", 0).fillna(0)
    df["trend_str"] = (s50 / s200 - 1) * 100
    df["earn_yield"] = eps / price * 100
    df["fcf_yield"] = fcf / price * 100
    df["book_yield"] = np.log1p(np.abs(eq) / price) * np.sign(eq)
    df["quality"] = (roe + gm) * 0.5
    df["beta"] = rsi - df.get("m_SPY_RET_21D", pd.Series(0, index=df.index)).fillna(0)
    df["ivol"] = (iv - mv) / mv * 100
    df["max_dd_90d"] = -iv * 3
    df["rsi_mom"] = rsi - 50
    df["vol_trend"] = (vr - 1) * 100
    df["bb_compress"] = -bb * 100
    df["log_mcap"] = np.log1p(np.abs(eq))
    return df


def zscore_features(df: pd.DataFrame) -> pd.DataFrame:
    """Z-score per-ticker-varying features (vectorized within date)."""
    df = df.copy()
    z_cols = [c for c in df.columns if c not in (
        "date", "ticker", "pct_change_target", "sector", "p_open", "p_high",
        "p_low", "p_close", "p_volume", "p_adj_close", "class_label")]
    z_cols = [c for c in z_cols if not c.startswith("m_") and not c.startswith("z_")
              and not c.startswith("x_")]
    
    if "date" in df.columns and len(df) > 1:
        dg = df.groupby("date")
        for c in z_cols:
            m = dg[c].transform("mean")
            s = dg[c].transform("std").replace(0, 1e-8)
            df[f"z_{c}"] = ((df[c] - m) / s).fillna(0).astype(np.float32)
    return df


def add_interactions(df: pd.DataFrame) -> pd.DataFrame:
    """Add interaction features."""
    pairs = [("quality", "book_yield"), ("mom_6m", "trend_str"),
             ("earn_yield", "fcf_yield"), ("rsi_mom", "ivol"),
             ("quality", "earn_yield"), ("beta", "ivol"),
             ("trend_str", "bb_compress"), ("mom_1m", "vol_trend")]
    for a, b in pairs:
        za, zb = f"z_{a}", f"z_{b}"
        if za in df.columns and zb in df.columns:
            df[f"x_{a}_{b}"] = (df[za] * df[zb]).astype(np.float32)
    return df


def score_tickers(tickers: List[str]) -> pd.DataFrame:
    """
    Score a list of tickers using the model.
    Fetches TODAY's price data, computes factors, z-scores, returns scores.
    """
    model, expected = _load_model()
    batch_size = 200
    all_scores = []

    for i in range(0, len(tickers), batch_size):
        batch = tickers[i:i + batch_size]
        try:
            df = yf.download(" ".join(batch), period="5d",
                           group_by="ticker", threads=True, progress=False, auto_adjust=True)
        except Exception:
            continue

        if df.empty:
            continue

        # Process each ticker's data
        for ticker in batch:
            try:
                if isinstance(df.columns, pd.MultiIndex):
                    ticker_data = df.xs(ticker, axis=1, level=0) if ticker in df.columns.get_level_values(0) else None
                else:
                    ticker_data = None if ticker not in df.columns else df

                if ticker_data is None or ticker_data.empty:
                    continue

                latest = ticker_data.iloc[-1].to_dict()
                row = {
                    "ticker": ticker,
                    "p_sma_10": latest.get("Close", 0),
                    "p_sma_20": latest.get("Close", 0),
                    "p_vol_sma_20": latest.get("Volume", 0),
                    "p_vol_ratio": 1.0,
                    "p_pct_change_5d": 0,
                    "p_pct_change_21d": 0,
                    "f_eps": 0, "f_equity": 0, "f_roe": 0, "f_gross_margin": 0,
                    "f_free_cash_flow": 0,
                    "p_rsi_14": 50, "p_volatility_21d": 0,
                    "m_VIX_CLOSE": 15, "m_SPY_RET_21D": 0,
                }
                all_scores.append(row)
            except Exception:
                continue

    if not all_scores:
        return pd.DataFrame()

    df = pd.DataFrame(all_scores)
    df = compute_factors(df)

    # Z-score within the whole batch (treat as one date)
    z_cols = [c for c in df.columns if c not in (
        "ticker", "p_open", "p_high", "p_low", "p_close", "p_volume", "p_adj_close")]
    z_cols = [c for c in z_cols if not c.startswith("m_") and not c.startswith("z_")
              and not c.startswith("x_")]
    for c in z_cols:
        if c in df.columns:
            m = df[c].mean()
            s = df[c].std()
            df[f"z_{c}"] = ((df[c] - m) / max(s, 1e-8)).fillna(0).astype(np.float32)

    df = add_interactions(df)

    # Build feature matrix matching model's expected features
    for f in expected:
        if f not in df.columns:
            df[f] = 0.0

    # Score
    dmat = xgb.DMatrix(df[list(expected)])  # noqa: F821
    df["score"] = model.predict(dmat)
    return df.sort_values("score", ascending=False)


async def fetch_prices_concurrent(tickers: List[str]) -> Dict[str, Dict]:
    """Async concurrent price fetch using loop.run_in_executor + yfinance."""
    loop = asyncio.get_event_loop()
    results = {}
    batch_size = 100

    for i in range(0, len(tickers), batch_size):
        batch = tickers[i:i + batch_size]
        try:
            df = await loop.run_in_executor(
                None, lambda b=batch: yf.download(
                    " ".join(b), period="5d", group_by="ticker",
                    threads=True, progress=False, auto_adjust=True))
        except Exception:
            continue

        if df.empty or isinstance(df.columns, pd.MultiIndex):
            for ticker in batch:
                try:
                    if isinstance(df.columns, pd.MultiIndex) and ticker in df.columns.get_level_values(0):
                        td = df.xs(ticker, axis=1, level=0)
                    else:
                        continue
                    latest = td.iloc[-1] if not td.empty else None
                    if latest is not None:
                        results[ticker] = {
                            "price": float(latest.get("Close", 0)),
                            "volume": float(latest.get("Volume", 0)),
                        }
                except Exception:
                    continue
        await asyncio.sleep(0)  # yield

    return results


# ── Quality filter ──
def quality_filter(df: pd.DataFrame, capital: float) -> pd.DataFrame:
    """Apply risk screens and return investment candidates."""
    if df.empty:
        return df
    q = pd.Series(True, index=df.index)
    if "p_sma_10" in df.columns:
        q &= df["p_sma_10"].fillna(0) >= 2.0
    if "f_equity" in df.columns:
        q &= df["f_equity"].fillna(0) >= 1e8
    return df[q].copy()