"""
Paper trader — daily cycle: fetch → score → size → trade → track.
Risk-averse, concurrent on Windows.
"""
import asyncio
import json
import sys
import time
from datetime import datetime
from pathlib import Path
from typing import List, Optional

import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from trader.data_manager import score_tickers, quality_filter
from trader.portfolio import (
    Portfolio, load_portfolio, save_portfolio, compute_market_data
)

# ── Constants ──
TRADING_DAYS = 63  # hold period
REBALANCE_INTERVAL = 5  # check every 5 trading days
MAX_POSITIONS = 15
MIN_POSITIONS = 5
CAPITAL = 10000.0
DATA_DIR = Path(__file__).resolve().parent.parent / "data"


class PaperTrader:
    """Daily paper trading system: scores, sizes, trades, tracks."""

    def __init__(self, capital: float = CAPITAL, model: str = "best"):
        self.portfolio = load_portfolio(DATA_DIR / "portfolio.json")
        self.capital = capital
        self.running = False
        self.day_count = 0

    def _get_volatility(self, ticker: str) -> float:
        """Get recent volatility for a ticker (0-1 scale)."""
        try:
            import yfinance as yf
            df = yf.download(ticker, period="1mo", progress=False, auto_adjust=True)
            if not df.empty and len(df) > 5:
                rets = df["Close"].pct_change().dropna()
                return float(min(0.5, max(0.01, rets.std() * np.sqrt(21))))
        except Exception:
            pass
        return 0.05  # default moderate volatility

    def run_once(self) -> dict:
        """
        One full trading cycle:
        1. Load all tickers
        2. Score with model
        3. Quality filter
        4. Check existing positions (sell if 63d hold reached)
        5. Buy new positions up to MAX_POSITIONS
        6. Record snapshot
        """
        print(f"\n{'='*60}", flush=True)
        print(f"  PAPER TRADER CYCLE — {datetime.now().strftime('%Y-%m-%d %H:%M')}", flush=True)
        print(f"  Capital: ${self.portfolio.cash:.2f} | "
              f"Equity: ${self.portfolio.total_equity:.2f} | "
              f"Positions: {self.portfolio.num_positions} | "
              f"DD: {self.portfolio.drawdown:.1f}%", flush=True)
        print(f"{'='*60}", flush=True)

        today = datetime.now().strftime("%Y-%m-%d")

        # ── 1. Load tickers ──
        from stockpredict2.collectors.ticker_list import get_ticker_symbols
        all_tickers = get_ticker_symbols()
        print(f"  Universe: {len(all_tickers)} tickers", flush=True)

        # ── 2. Score ──
        print("  Scoring...", flush=True)
        t0 = time.time()
        scored = score_tickers(all_tickers)
        if scored.empty:
            print("  ⚠ No scores generated", flush=True)
            return {"status": "error", "reason": "no_scores"}

        print(f"  Scored {len(scored)} tickers in {time.time()-t0:.0f}s", flush=True)

        # ── 3. Quality filter ──
        qualified = quality_filter(scored, self.portfolio.cash)
        print(f"  Quality pass: {len(qualified)}/{len(scored)}", flush=True)

        if qualified.empty:
            print("  ⚠ No qualified picks", flush=True)
            return {"status": "skip", "reason": "no_qualified"}

        top_picks = qualified.head(MAX_POSITIONS + 5).copy()

        # ── 4. Check existing positions ──
        for ticker in list(self.portfolio.positions.keys()):
            pos = self.portfolio.positions[ticker]
            holding_days = (datetime.now() - datetime.strptime(pos["entry_date"], "%Y-%m-%d")).days
            if holding_days >= TRADING_DAYS:
                # Check current price
                price = self._get_current_price(ticker)
                if price > 0:
                    self.portfolio.sell(ticker, price, today, "SELL (hold reached)")
                    print(f"  SELL {ticker}: ${price:.2f} (held {holding_days}d)", flush=True)

        # ── 5. Buy new positions ──
        self.day_count += 1
        if self.day_count % REBALANCE_INTERVAL == 0 or self.portfolio.num_positions < MIN_POSITIONS:
            buys = 0
            for _, row in top_picks.iterrows():
                ticker = row["ticker"]
                if self.portfolio.has_position(ticker):
                    continue
                if self.portfolio.num_positions >= MAX_POSITIONS:
                    break

                price = self._get_current_price(ticker)
                if price <= 0:
                    continue

                # Score rank (normalized)
                score = row.get("score", 0)
                score_rank = min(1.0, max(0, score / 100))  # rough rank

                vol = self._get_volatility(ticker)
                shares, cost = self.portfolio._compute_position_size(
                    ticker, price, score, vol, score_rank)

                if shares > 0 and cost <= self.portfolio.cash:
                    self.portfolio.buy(ticker, price, shares, today, score, vol)
                    print(f"  BUY {ticker}: {shares}sh @ ${price:.2f} = ${cost:.2f}", flush=True)
                    buys += 1

            if buys == 0:
                print("  No new buys (capital or limit constraints)", flush=True)

        # ── 6. Update prices for existing positions ──
        if self.portfolio.positions:
            active = list(self.portfolio.positions.keys())
            prices = compute_market_data(active)
            self.portfolio.update_prices(prices)

        # ── 7. Record snapshot ──
        self.portfolio.record_snapshot(today)
        save_portfolio(self.portfolio)

        # ── 8. Summary ──
        summary = self.portfolio.get_summary()
        print(f"\n  SUMMARY:", flush=True)
        print(f"  Cash:      ${summary['cash']:.2f}", flush=True)
        print(f"  Positions: ${summary['position_value']:.2f} ({summary['open_positions']} open)", flush=True)
        print(f"  Equity:    ${summary['total_equity']:.2f}", flush=True)
        print(f"  P&L:       ${summary['total_pnl']:.2f} ({summary['total_pnl_pct']:+.2f}%)", flush=True)
        print(f"  Drawdown:  {summary['drawdown']:.1f}%", flush=True)
        print(f"{'='*60}\n", flush=True)

        return {"status": "ok", "summary": summary}

    def _get_current_price(self, ticker: str) -> float:
        """Get current price for a ticker."""
        try:
            import yfinance as yf
            df = yf.download(ticker, period="2d", progress=False, auto_adjust=True)
            if not df.empty:
                return float(df["Close"].iloc[-1])
        except Exception:
            pass
        return 0.0

    def run_loop(self, interval_minutes: int = 60, max_cycles: int = 0):
        """Run trading loop. Default: runs until stopped (Ctrl+C)."""
        self.running = True
        cycle = 0
        print(f"\n  Starting paper trader loop (interval={interval_minutes}min)", flush=True)
        print(f"  Initial capital: ${self.capital:.2f}", flush=True)
        print(f"  Hold period: {TRADING_DAYS} trading days", flush=True)
        print(f"  Max positions: {MAX_POSITIONS}", flush=True)

        try:
            while self.running:
                cycle += 1
                if max_cycles and cycle > max_cycles:
                    print(f"\n  Reached max cycles ({max_cycles}). Stopping.", flush=True)
                    break

                result = self.run_once()

                if self.running and (not max_cycles or cycle < max_cycles):
                    print(f"  Next cycle in {interval_minutes} min...", flush=True)
                    for remaining in range(interval_minutes * 60, 0, -60):
                        if not self.running:
                            break
                        time.sleep(min(60, remaining))

        except KeyboardInterrupt:
            print("\n  Stopped by user.", flush=True)
        finally:
            self.running = False
            save_portfolio(self.portfolio)
            print(f"\n  Final portfolio state saved.", flush=True)
            summary = self.portfolio.get_summary()
            print(f"  Final equity: ${summary['total_equity']:.2f} "
                  f"({summary['total_pnl_pct']:+.2f}%)", flush=True)


def main():
    """CLI entry point."""
    import argparse
    parser = argparse.ArgumentParser(description="Paper Trader")
    parser.add_argument("--capital", type=float, default=CAPITAL, help="Starting capital")
    parser.add_argument("--interval", type=int, default=60, help="Minutes between cycles")
    parser.add_argument("--cycles", type=int, default=0, help="Max cycles (0=infinite)")
    parser.add_argument("--once", action="store_true", help="Run once and exit")
    args = parser.parse_args()

    trader = PaperTrader(capital=args.capital)
    if args.once:
        trader.run_once()
    else:
        trader.run_loop(interval_minutes=args.interval, max_cycles=args.cycles)


if __name__ == "__main__":
    main()