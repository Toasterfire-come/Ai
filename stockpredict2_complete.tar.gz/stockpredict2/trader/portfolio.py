"""
Portfolio manager — position sizing, capital tracking, risk management.
Handles $10,000 starting capital, volatility-adjusted sizing, stop-loss tracking.
"""
import json
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import numpy as np
import pandas as pd

DATA_DIR = Path(__file__).resolve().parent.parent / "data"


class Portfolio:
    """Tracks cash, positions, P&L. Risk-averse position sizing."""

    def __init__(self, initial_capital: float = 10000.0):
        self.initial_capital = initial_capital
        self.cash = initial_capital
        self.positions: Dict[str, dict] = {}  # ticker -> {"shares": N, "entry_price": P, "entry_date": str}
        self.trade_log: List[dict] = []
        self.equity_curve: List[dict] = []
        self.peak_equity = initial_capital

    @property
    def total_equity(self) -> float:
        return self.cash + self.position_value

    @property
    def position_value(self) -> float:
        return sum(p["shares"] * p.get("current_price", p["entry_price"]) for p in self.positions.values())

    @property
    def drawdown(self) -> float:
        eq = self.total_equity
        self.peak_equity = max(self.peak_equity, eq)
        return (eq - self.peak_equity) / self.peak_equity * 100 if self.peak_equity > 0 else 0

    @property
    def num_positions(self) -> int:
        return len(self.positions)

    def _compute_position_size(self, ticker: str, price: float, score: float,
                                 volatility: float, score_rank: float) -> Tuple[float, float]:
        """
        Risk-averse position sizing:
        1. Base allocation: equal-weight across target positions (10-15)
        2. Reduce if volatility > median
        3. Increase if score is in top quartile
        4. Never exceed 15% of capital in one position
        """
        base_positions = max(10, min(15, self.num_positions + 5))
        base_pct = 1.0 / base_positions

        # Score bonus: top 25% → +50% allocation
        score_mult = 1.0 + max(0, (score_rank - 0.75) * 2)

        # Volatility penalty: higher vol → smaller position
        vol_mult = max(0.3, min(1.0, 1.0 - volatility))

        # Combined allocation
        alloc_pct = base_pct * score_mult * vol_mult

        # Hard cap at 15% of capital
        alloc_pct = min(alloc_pct, 0.15)

        # Floor at 2%
        alloc_pct = max(alloc_pct, 0.02)

        allocated_capital = self.cash * alloc_pct
        shares = max(1, int(allocated_capital / price)) if price > 0 else 0
        actual_cost = shares * price

        # Don't exceed available cash
        if actual_cost > self.cash:
            shares = int(self.cash / price)
            actual_cost = shares * price

        return shares, actual_cost

    def buy(self, ticker: str, price: float, shares: int, date: str, score: float = 0,
            volatility: float = 0.05):
        """Execute a buy order."""
        cost = shares * price
        if cost > self.cash:
            shares = int(self.cash / price)
            cost = shares * price
        if shares <= 0:
            return False

        self.cash -= cost
        self.positions[ticker] = {
            "shares": shares,
            "entry_price": price,
            "entry_date": date,
            "cost_basis": cost,
            "score": score,
        }
        self.trade_log.append({
            "date": date, "ticker": ticker, "action": "BUY",
            "price": price, "shares": shares, "cost": cost,
            "cash_after": self.cash,
        })
        return True

    def sell(self, ticker: str, price: float, date: str, reason: str = "SELL"):
        """Execute a sell order. Returns proceeds."""
        pos = self.positions.get(ticker)
        if not pos:
            return 0.0
        proceeds = pos["shares"] * price
        self.cash += proceeds
        pnl = proceeds - pos["cost_basis"]
        self.trade_log.append({
            "date": date, "ticker": ticker, "action": reason,
            "price": price, "shares": pos["shares"],
            "proceeds": proceeds, "pnl": pnl,
            "pnl_pct": (pnl / pos["cost_basis"]) * 100 if pos["cost_basis"] > 0 else 0,
            "cash_after": self.cash,
        })
        del self.positions[ticker]
        return proceeds

    def update_prices(self, prices: Dict[str, float]):
        """Update current prices for all positions."""
        for ticker, price in prices.items():
            if ticker in self.positions:
                self.positions[ticker]["current_price"] = price

    def record_snapshot(self, date: str):
        """Record equity snapshot for tracking."""
        self.equity_curve.append({
            "date": date,
            "cash": round(self.cash, 2),
            "positions": round(self.position_value, 2),
            "equity": round(self.total_equity, 2),
            "dd": round(self.drawdown, 2),
            "num_positions": self.num_positions,
        })

    def has_position(self, ticker: str) -> bool:
        return ticker in self.positions

    def get_summary(self) -> dict:
        """Return P&L summary."""
        total_pl = self.total_equity - self.initial_capital
        total_pl_pct = (total_pl / self.initial_capital) * 100
        return {
            "initial_capital": self.initial_capital,
            "cash": round(self.cash, 2),
            "position_value": round(self.position_value, 2),
            "total_equity": round(self.total_equity, 2),
            "total_pnl": round(total_pl, 2),
            "total_pnl_pct": round(total_pl_pct, 2),
            "drawdown": round(self.drawdown, 2),
            "open_positions": self.num_positions,
            "total_trades": len(self.trade_log),
        }


def compute_market_data(tickers: List[str]) -> Dict[str, float]:
    """Get current prices for all tickers (used for position tracking)."""
    import yfinance as yf
    results = {}
    for i in range(0, len(tickers), 100):
        batch = tickers[i:i + 100]
        try:
            df = yf.download(" ".join(batch), period="2d",
                           group_by="ticker", threads=True, progress=False)
            if not df.empty:
                for t in batch:
                    try:
                        if isinstance(df.columns, pd.MultiIndex) and t in df.columns.get_level_values(0):
                            td = df.xs(t, axis=1, level=0)
                            if not td.empty:
                                results[t] = float(td["Close"].iloc[-1])
                    except Exception:
                        continue
        except Exception:
            continue
    return results


def save_portfolio(portfolio: Portfolio, path: Optional[Path] = None):
    """Save portfolio state to JSON."""
    path = path or (DATA_DIR / "portfolio.json")
    data = {
        "initial_capital": portfolio.initial_capital,
        "cash": portfolio.cash,
        "peak_equity": portfolio.peak_equity,
        "positions": {t: {k: float(v) if isinstance(v, (int, float, np.integer, np.floating)) else v
                          for k, v in p.items()}
                      for t, p in portfolio.positions.items()},
        "trade_log": portfolio.trade_log[-200:],  # last 200 trades
        "equity_curve": portfolio.equity_curve,
    }
    with open(path, "w") as f:
        json.dump(data, f, indent=2)


def load_portfolio(path: Optional[Path] = None) -> Portfolio:
    """Load portfolio state from JSON."""
    path = path or (DATA_DIR / "portfolio.json")
    if not path.exists():
        return Portfolio()
    with open(path) as f:
        data = json.load(f)
    p = Portfolio(data.get("initial_capital", 10000.0))
    p.cash = data.get("cash", p.initial_capital)
    p.peak_equity = data.get("peak_equity", p.initial_capital)
    p.positions = {t: {"shares": int(d.get("shares", 0)),
                        "entry_price": float(d.get("entry_price", 0)),
                        "entry_date": str(d.get("entry_date", "")),
                        "cost_basis": float(d.get("cost_basis", 0)),
                        "score": float(d.get("score", 0))}
                   for t, d in data.get("positions", {}).items()}
    p.trade_log = data.get("trade_log", [])
    p.equity_curve = data.get("equity_curve", [])
    return p