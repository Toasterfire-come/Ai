"""
Sentiment Engine — FinBERT-based financial news sentiment analysis.
Falls back to a simple lexicon-based scorer if FinBERT unavailable.
"""
from typing import List
import numpy as np
import pandas as pd


class SentimentAnalyzer:
    """Wraps FinBERT (ProsusAI/finbert) for financial news sentiment."""

    def __init__(self, model_name: str = "ProsusAI/finbert"):
        self._model = None
        self._tokenizer = None
        self._model_name = model_name
        self._loaded = False

    def _load(self):
        if self._loaded:
            return
        try:
            from transformers import AutoModelForSequenceClassification, AutoTokenizer
            self._tokenizer = AutoTokenizer.from_pretrained(self._model_name)
            self._model = AutoModelForSequenceClassification.from_pretrained(self._model_name)
            self._model.eval()
            self._loaded = True
            print(f"  Sentiment: FinBERT loaded ({self._model_name})")
        except Exception as e:
            print(f"  Sentiment: FinBERT unavailable ({e}), using lexicon fallback")
            self._loaded = False

    def score(self, texts: List[str]) -> List[dict]:
        """
        Score a list of text strings.
        Returns [{"pos": 0.12, "neg": 0.03, "neu": 0.85}, ...]
        """
        if not texts:
            return []
        self._load()
        if self._loaded and self._model is not None:
            return self._score_transformers(texts)
        return self._score_lexicon(texts)

    def _score_transformers(self, texts: List[str]) -> List[dict]:
        import torch
        inputs = self._tokenizer(texts, padding=True, truncation=True,
                                 max_length=512, return_tensors="pt")
        with torch.no_grad():
            outputs = self._model(**inputs)
            probs = torch.softmax(outputs.logits, dim=1).numpy()
        results = []
        for p in probs:
            results.append({"pos": float(p[0]), "neg": float(p[1]), "neu": float(p[2])})
        return results

    def _score_lexicon(self, texts: List[str]) -> List[dict]:
        """Simple lexicon fallback — counts positive/negative words."""
        positive_words = {"up", "gain", "rise", "surge", "growth", "profit", "positive",
                          "upgrade", "beat", "outperform", "strong", "bullish", "rally",
                          "breakthrough", "record", "dividend", "buyback", "upward"}
        negative_words = {"down", "loss", "drop", "fall", "decline", "cut", "negative",
                          "downgrade", "miss", "underperform", "weak", "bearish", "selloff",
                          "crash", "bankrupt", "layoff", "lawsuit", "fine", "penalty"}

        results = []
        for text in texts:
            words = set(text.lower().split())
            pos = len(words & positive_words)
            neg = len(words & negative_words)
            total = pos + neg
            if total == 0:
                results.append({"pos": 0.05, "neg": 0.05, "neu": 0.90})
            else:
                results.append({
                    "pos": round(pos / total * 0.8, 4),
                    "neg": round(neg / total * 0.8, 4),
                    "neu": 0.20,
                })
        return results