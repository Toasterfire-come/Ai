"""
stockpredict2 — Configuration for data pipeline.
Paths, API keys, and data source settings.
"""
import os
from pathlib import Path

PROJECT_ROOT = Path(__file__).parent
DATA_DIR = PROJECT_ROOT / "data"
MODELS_DIR = PROJECT_ROOT / "models"

# Sub-directories for each data source
PRICES_DIR = DATA_DIR / "prices"
FINANCIALS_DIR = DATA_DIR / "financials"
NEWS_DIR = DATA_DIR / "news"
NEWS_RAW_DIR = NEWS_DIR / "raw"
NEWS_AGG_DIR = NEWS_DIR / "aggregated"
MACRO_DIR = DATA_DIR / "macro"
TICKERS_DIR = DATA_DIR / "tickers"
FORM4_DIR = DATA_DIR / "form4_trades"
ANALYST_DIR = DATA_DIR / "analyst"
EVENTS_DIR = DATA_DIR / "events"
FM_PATH = DATA_DIR / "feature_matrix.parquet"

# Ensure all data dirs exist
for d in [PRICES_DIR, FINANCIALS_DIR, NEWS_RAW_DIR, NEWS_AGG_DIR,
          MACRO_DIR, TICKERS_DIR, FORM4_DIR, ANALYST_DIR, EVENTS_DIR,
          DATA_DIR, MODELS_DIR]:
    d.mkdir(parents=True, exist_ok=True)

# Ticker universe
DATA_START_DATE = "2016-01-01"
DATA_START_YEAR = 2016

# Prediction horizon (trading days)
PREDICTION_HORIZON_DAYS = 63  # ~3 calendar months

# Class boundaries for labeling
CLASS_BOUNDARIES = [-15.0, -3.0, 3.0, 15.0]
CLASS_NAMES = ["super_negative", "negative", "neutral", "positive", "super_positive"]

# Collection rate limits
YFINANCE_DELAY = 3.0           # seconds between yfinance requests
YFINANCE_BATCH_SIZE = 10       # tickers per batch
YFINANCE_BATCH_WAIT = 65       # seconds between batches
SEC_RATE_DELAY = 0.15          # seconds between SEC EDGAR requests (10/sec max)

# Yahoo Finance news scraper uses Selenium (no rate limits)
# SEC EDGAR is free and unlimited (be polite: 10 req/sec)

# Feature flags — which data sources to include
FEATURES = {
    "price_technicals": True,
    "fundamentals": True,
    "news_sentiment": True,
    "analyst_consensus": True,
    "macro_indicators": True,
    "sector_returns": True,
    "insider_trades": True,
    "corporate_events": True,
}

# Sector ETFs for stock-vs-sector alpha
SECTOR_ETFS = ["XLF", "XLK", "XLV", "XLI", "XLP", "XLE", "XLU", "XLB",
               "XLRE", "XLC", "XLY"]

# Market benchmark ETFs
MARKET_ETFS = {
    "^VIX": "VIX_CLOSE",
    "^TNX": "TNX_CLOSE",   # 10Y Treasury yield
    "^IRX": "IRX_CLOSE",   # 13wk T-Bill
    "^FVX": "FVX_CLOSE",   # 5Y Treasury
    "SPY": "SPY_CLOSE",
    "QQQ": "QQQ_CLOSE",
    "IWM": "IWM_CLOSE",
}

# FRED macro-economic series
FRED_SERIES = {
    "INDPRO": "Industrial Production Index",
    "TCU": "Capacity Utilization",
    "EXPGS": "Exports of Goods & Services",
    "IMPGS": "Imports of Goods & Services",
    "RSAFS": "Retail Sales & Food Services",
    "HOUST": "Housing Starts",
    "PERMIT": "Building Permits",
    "DGORDER": "Durable Goods Orders",
    "UMCSENT": "Consumer Sentiment (UMich)",
    "PAYEMS": "Nonfarm Payrolls",
    "CES0500000003": "Avg Hourly Earnings",
    "T10Y2Y": "10Y-2Y Treasury Spread",
    "DGS10": "10-Year Treasury Yield",
    "DTWEXBGS": "US Dollar Index (Broad)",
}

# Common words that look like tickers but aren't
COMMON_WORD_TICKERS = {
    "A", "I", "THE", "AND", "FOR", "NEW", "ALL", "ARE", "BUT",
    "NOT", "HAS", "HAD", "ITS", "CAN", "WAS", "WERE", "WHO",
    "WHY", "HOW", "NOW", "VERY", "JUST", "THAN", "THEN", "THAT",
    "THIS", "WITH", "FROM", "MORE", "SOME", "WHAT", "WHEN",
    "HIGH", "LOW", "BIG", "GET", "SET", "TOP", "BEST", "FIRST",
    "LAST", "NEXT", "OVER", "UNDER", "PART", "CASH", "DEBT",
    "RISK", "LOSS", "GAIN", "SALE", "PAID", "FREE", "OPEN",
    "CLOSE", "WEEK", "MONTH", "YEAR", "HALF", "FULL", "LONG",
    "SHORT", "BANK", "FUND", "STAR", "GOLD", "SILVER", "OIL",
    "GAS", "FOOD", "HEALTH", "LIFE", "WORK", "HOME", "TIME",
    "CALL", "PUT", "BUY", "SELL", "TAX", "DEAL", "MOVE",
    "PLAN", "GROWTH", "VALUE", "INCOME", "CAPITAL",
}

# Risk filter defaults
RISK_DEFAULTS = {
    "min_price": 5.0,
    "min_equity": 300_000_000,
    "min_volume": 100_000,
    "max_vol_percentile": 0.80,
    "risk_penalty_weight": 0.30,
}

# Internal check
assert len(COMMON_WORD_TICKERS) < 500, "COMMON_WORD_TICKERS too large"