#!/usr/bin/env python3
"""StockPredict2 — Autonomous Paper Trader. Fixes: sector cap, stop-loss, retrain, market checks."""
import sys, os, json, time, warnings, argparse, subprocess
from datetime import datetime, timedelta
from pathlib import Path
warnings.filterwarnings("ignore")
os.environ["OMP_NUM_THREADS"] = "8"; os.environ["YFINANCE_USE_NETRC"] = "0"

import numpy as np; import pandas as pd; import yfinance as yf

BASE = Path(__file__).resolve().parent; DATA = BASE / "data"; MODELS = BASE / "models"
DATA.mkdir(exist_ok=True)
PFILE = DATA / "portfolio.json"; SECTOR_FILE = DATA / "ticker_sector.json"
TICKER_FILE = DATA / "tickers" / "nyse.parquet"
HOLD = 63; REBAL = 5; MAX_POS = 15; MIN_POS = 5; STOP_LOSS = 7.0; MAX_SECTOR = 25.0
RETRAIN_DAYS = 30

# ── Keep awake ──
_awake = False
def _sleep_lock(on=True):
    global _awake
    if on and not _awake:
        for cmd in [["caffeinate","-dim"], ["systemd-inhibit","--what=sleep","--mode=block","sleep","infinity"],
                    ["powershell","-Command","& {while(1){Start-Sleep -Seconds 60; [System.Console]::Beep()}}"]]:
            try: subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL); _awake=True; break
            except: continue
    elif not on and _awake:
        try: subprocess.run(["pkill","-f","caffeinate"], capture_output=True)
        except: pass
        _awake=False

# ── Model ──
_model=None; _feats=None; _xgb=None
def load_model():
    global _model, _feats, _xgb
    if _model: return _model, _feats, _xgb
    import xgboost as xgb
    _xgb = xgb
    files = sorted(MODELS.glob("f_flag_v2_s42_r*.json"))
    if not files: print("No model. Train first."); sys.exit(1)
    _model = xgb.Booster(); _model.load_model(str(files[-1]))
    _feats = list(_model.feature_names) if _model.feature_names else []
    print(f"  Model: {files[-1].name} ({len(_feats)} feats)")
    return _model, _feats, _xgb

# ── Features ──
def compute_features(df):
    df = df.copy()
    for c in ["p_sma_10","p_sma_20","p_sma_50","p_sma_200","p_ema_12","p_ema_26",
              "p_macd","p_macd_signal","p_rsi_14","p_bb_width","p_atr_14","p_vol_sma_20","p_vol_ratio",
              "p_pct_change_1d","p_pct_change_5d","p_pct_change_21d","p_volatility_21d","p_volatility_63d",
              "f_gross_margin","f_op_margin","f_net_margin","f_roe","f_roa",
              "f_revenue","f_net_income","f_eps","f_equity","f_total_assets","f_free_cash_flow",
              "n_sentiment_pos","n_sentiment_neg","n_sentiment_neu","n_article_count",
              "i_buys_90d","i_sells_90d"]:
        if c not in df.columns: df[c] = 0.0
    p=df["p_sma_10"].replace(0,1); e=df["f_eps"].fillna(0); eq=df["f_equity"].fillna(0)
    r=df["f_roe"].fillna(0); g=df["f_gross_margin"].fillna(0); f=df["f_free_cash_flow"].fillna(0)
    rs=df["p_rsi_14"].fillna(50); iv=df["p_volatility_21d"].fillna(0)
    mv=df.get("m_VIX_CLOSE",pd.Series(15,index=df.index)).fillna(15).replace(0,1)
    vr=df["p_vol_ratio"].fillna(1); bb=df["p_bb_width"].fillna(0)
    s50=df["p_sma_50"]; s200=df["p_sma_200"].replace(0,1)
    df["mom_6m"]=df["p_pct_change_21d"].fillna(0); df["mom_1m"]=df["p_pct_change_5d"].fillna(0)
    df["trend_str"]=(s50/s200-1)*100; df["earn_yield"]=e/p*100; df["fcf_yield"]=f/p*100
    df["book_yield"]=np.log1p(np.abs(eq)/p)*np.sign(eq); df["quality"]=(r+g)*0.5
    df["beta"]=rs-df.get("m_SPY_RET_21D",pd.Series(0,index=df.index)).fillna(0)
    df["ivol"]=(iv-mv)/mv*100; df["max_dd_90d"]=-iv*3; df["rsi_mom"]=rs-50
    df["vol_trend"]=(vr-1)*100; df["bb_compress"]=-bb*100; df["log_mcap"]=np.log1p(np.abs(eq))
    zcols=[c for c in df.columns if c not in ("ticker","date","pct_change_target","sector")
           and not any(c.startswith(p) for p in ("m_","z_","x_","p_open","p_high","p_low","p_close","p_volume","p_adj_close","class_label","c_"))]
    for c in zcols:
        m=df[c].mean(); s=df[c].std(); df[f"z_{c}"]=((df[c]-m)/max(s,1e-8)).fillna(0).astype(np.float32)
    for a,b in [("quality","book_yield"),("mom_6m","trend_str"),("earn_yield","fcf_yield"),
                 ("rsi_mom","ivol"),("quality","earn_yield"),("beta","ivol"),("trend_str","bb_compress"),("mom_1m","vol_trend")]:
        za,zb=f"z_{a}",f"z_{b}"
        if za in df.columns and zb in df.columns: df[f"x_{a}_{b}"]=(df[za]*df[zb]).astype(np.float32)
    return df

# ── Sector map ──
_sectors = {}
def get_sector(ticker):
    global _sectors
    if not _sectors and SECTOR_FILE.exists():
        with open(SECTOR_FILE) as f:
            _sectors = json.load(f)
    return _sectors.get(ticker, "Unknown")

# ── Market hours check ──
def market_open():
    now = datetime.now()
    if now.weekday() >= 5: return False  # weekend
    # Rough check: 9:30-16:00 ET (approximate as UTC-4/5)
    est = now.hour - 5 if now.month >= 3 and now.month <= 10 else now.hour - 4
    if est < 6 or est > 16: return False  # before 6am or after 4pm ET
    if est == 6 and now.minute < 30: return False  # before 9:30am
    return True

# ── SPY crash filter ──
def spy_crash():
    try:
        df = yf.download("SPY", period="5d", progress=False, auto_adjust=True)
        if not df.empty and len(df) >= 2:
            ret = (df["Close"].iloc[-1] / df["Close"].iloc[-2] - 1) * 100
            if ret < -5: return True, ret  # crash
            return False, ret
    except: pass
    return False, 0

# ── Auto-retrain ──
def check_retrain():
    model_files = sorted(MODELS.glob("f_flag_v2_s42_r*.json"))
    if not model_files: return
    age_days = (time.time() - model_files[-1].stat().st_mtime) / 86400
    if age_days >= RETRAIN_DAYS:
        print(f"  Model is {age_days:.0f}d old — retraining...", flush=True)
        train_script = BASE / "scripts" / "train_v2.py"
        if train_script.exists():
            try:
                subprocess.run([sys.executable, "-u", str(train_script)],
                             cwd=BASE.parent, capture_output=True, timeout=3600)
                print(f"  Retrain complete", flush=True)
                # Reload model
                global _model, _feats
                _model=None; _feats=None; load_model()
            except subprocess.TimeoutExpired:
                print(f"  Retrain timed out", flush=True)

# ── Scoring ──
_vol_cache = {}
def get_vol(t):
    if t in _vol_cache: return _vol_cache[t]
    try:
        df = yf.download(t, period="1mo", progress=False, auto_adjust=True)
        if not df.empty and len(df) > 5:
            v = float(min(0.5, max(0.01, df["Close"].pct_change().dropna().std() * np.sqrt(21))))
            _vol_cache[t] = v; return v
    except: pass
    return 0.05

def score_all(tickers):
    model, feats, xgb = load_model()
    # Only score tickers where we can quickly check price
    # First get SPY batch to check market context
    try:
        spy = yf.download("SPY", period="1mo", progress=False, auto_adjust=True)
        spy_ret = float((spy["Close"].iloc[-1] / spy["Close"].iloc[-2] - 1) * 100) if not spy.empty else 0
    except:
        spy_ret = 0

    rows = []
    for i in range(0, len(tickers), 100):
        batch = tickers[i:i+100]
        try:
            df = yf.download(" ".join(batch), period="5d", group_by="ticker",
                            threads=True, progress=False, auto_adjust=True)
        except: continue
        if df.empty: continue
        for t in batch:
            try:
                if isinstance(df.columns, pd.MultiIndex):
                    if t in df.columns.get_level_values(0): td = df.xs(t, axis=1, level=0)
                    else: continue
                else: td = df
                if td.empty: continue
                latest = td.iloc[-1]; close = float(latest["Close"]); vol = float(latest["Volume"])
                if close < 2 or vol < 1000: continue  # skip penny / dead stocks
                rows.append({"ticker":t,"p_sma_10":close,"p_vol_sma_20":vol,
                    "f_equity":0,"f_eps":0,"f_roe":0,"f_gross_margin":0,"f_free_cash_flow":0,
                    "p_rsi_14":50,"p_volatility_21d":0,"m_VIX_CLOSE":15,"m_SPY_RET_21D":spy_ret})
            except: continue
    if not rows: return pd.DataFrame()
    df = pd.DataFrame(rows)
    df = compute_features(df)
    for f in feats:
        if f not in df.columns: df[f] = 0.0
    dmat = xgb.DMatrix(df[list(feats)])
    df["score"] = model.predict(dmat)
    return df.sort_values("score", ascending=False)

# ── Portfolio ──
class Portfolio:
    def __init__(self, capital=10000.0):
        self.capital=capital; self.cash=capital; self.peak=capital
        self.pos={}; self.trades=[]; self.log=[]
        self._load()

    @property
    def equity(self): return self.cash+sum(p["s"]*p.get("lp",p["e"]) for p in self.pos.values())

    @property
    def dd(self): self.peak=max(self.peak,self.equity); return (self.equity-self.peak)/self.peak*100

    def _load(self):
        if PFILE.exists():
            try:
                d=json.load(open(PFILE))
                self.cash=d.get("cash",self.capital); self.peak=d.get("peak",self.capital)
                self.trades=d.get("trades",[]); self.log=d.get("log",[])
                for t,p in d.get("pos",{}).items(): self.pos[t]=p
                if self.pos: print(f"  Resume: ${self.cash:.0f} cash, {len(self.pos)} pos",flush=True)
            except: pass

    def save(self):
        json.dump({"cash":self.cash,"peak":self.peak,"pos":self.pos,"trades":self.trades[-500:],"log":self.log},
                  open(PFILE,"w"), indent=2, default=str)

    def size(self, price, vol, pctile):
        n=max(MIN_POS,min(MAX_POS,len(self.pos)+5)); base=1.0/n
        sm=1.0+max(0,(pctile-0.75)*3); vm=max(0.3,min(1.0,1.0-vol*5))
        a=min(base*sm*vm,0.15); a=max(a,0.02)
        s=max(1,int(self.cash*a/price)); c=s*price
        if c>self.cash: s=int(self.cash/price); c=s*price
        return s,c

    def buy(self,t,p,s,c,v,score,date):
        self.cash-=c; sec=get_sector(t)
        self.pos[t]={"s":s,"e":p,"d":date,"c":c,"lp":p,"v":v,"sc":float(score),"sec":sec}
        self.trades.append([date,"B",t,p,s,c,round(self.cash)])
        actives={s for _,d in self.pos.items() for s in [d.get("sec","")] if s}
        sec_list=" ".join(f"{s}:{actives.count(s)}" for s in sorted(actives))

    def sell(self,t,p,date,reason=""):
        po=self.pos.pop(t,None)
        if not po: return
        pro=po["s"]*p; pnl=pro-po["c"]
        self.cash+=pro
        self.trades.append([date,f"S{reason}",t,p,po["s"],round(pro),round(pnl),round(self.cash)])

    def upd(self,prices):
        for t,p in prices.items():
            if t in self.pos: self.pos[t]["lp"]=p

    def snap(self,date):
        self.log.append([date,round(self.equity),round(self.dd,1),len(self.pos),round(self.cash)])

    def sum(self):
        pl=self.equity-self.capital
        return {"eq":round(self.equity),"pl":round(pl),"pl%":round(pl/self.capital*100,1),
                "dd":round(self.dd,1),"n":len(self.pos),"t":len(self.trades)}

# ── Tickers ──
_tickers=None
def get_tickers():
    global _tickers
    if _tickers is not None: return _tickers
    if TICKER_FILE.exists():
        _tickers = pd.read_parquet(TICKER_FILE)["symbol"].tolist()
    else:
        print("  Downloading ticker list from NASDAQ...", flush=True)
        import requests
        DATA.mkdir(exist_ok=True)
        (DATA / "tickers").mkdir(exist_ok=True)
        _tickers = []
        for ex in ["nasdaq","nyse"]:
            try:
                r = requests.get(f"https://www.nasdaqtrader.com/dynamic/SymDir/{ex}listed.txt", timeout=30)
                if r.status_code == 200:
                    for line in r.text.strip().split("\n")[1:]:
                        parts = line.split("|")
                        if len(parts) >= 2 and parts[0].isalpha(): _tickers.append(parts[0])
            except Exception as e:
                print(f"  ⚠ {ex} download failed: {e}", flush=True)
        # Save tickers for next time
        if _tickers:
            ticker_dir = DATA / "tickers"
            ticker_dir.mkdir(exist_ok=True)
            pd.DataFrame({"symbol": list(set(_tickers))}).to_parquet(ticker_dir / "nyse.parquet", index=False)
            print(f"  Saved {len(set(_tickers))} tickers", flush=True)
    # Filter to common stocks
    _tickers = [t for t in _tickers if t.isalpha() and len(t) <= 5 and not any(x in t.upper() for x in ["W","R","^","/"])]
    return _tickers[:5000] if len(_tickers) > 5000 else _tickers

# ── Main cycle ──
def cycle(pf, date):
    print(f"\n{'='*60}",flush=True)
    print(f"  {date} | Cash:${pf.cash:.0f} Eq:${pf.equity:.0f} N:{len(pf.pos)} DD:{pf.dd:.1f}%",flush=True)
    print(f"{'='*60}",flush=True)

    # Market check
    is_open = market_open()
    crash, spy_ret = spy_crash()
    print(f"  Market:{'OPEN' if is_open else 'CLOSED'} SPY:{spy_ret:+.1f}%",flush=True)

    # Stop-loss check — sell anything down >7%
    for t in list(pf.pos.keys()):
        po=pf.pos[t]
        try:
            df=yf.download(t,period="2d",progress=False,auto_adjust=True)
            price=float(df["Close"].iloc[-1]) if not df.empty else 0
            po["lp"]=price
            if price>0 and (price/po["e"]-1)*100 < -STOP_LOSS:
                pf.sell(t,price,date,"SL")
                print(f"  STOP {t}: ${price:.2f} ({(price/po['e']-1)*100:.1f}%)",flush=True)
        except: pass

    # Hold period sells
    for t in list(pf.pos.keys()):
        po=pf.pos[t]
        days=(datetime.now()-datetime.strptime(po["d"],"%Y-%m-%d")).days
        if days>=HOLD:
            try:
                df=yf.download(t,period="2d",progress=False,auto_adjust=True)
                price=float(df["Close"].iloc[-1]) if not df.empty else 0
            except: price=0
            if price>0:
                pnl=(price/po["e"]-1)*100
                pf.sell(t,price,date,f"({days}d {pnl:+.1f}%)")
                print(f"  SELL {t}: ${price:.2f} ({pnl:+.1f}%)",flush=True)

    # Score and buy (only if market is open and not in a crash)
    if len(pf.pos)>=MAX_POS:
        print(f"  Full: {len(pf.pos)} positions")
    elif crash:
        print(f"  SKIP buys: SPY crash {spy_ret:.1f}%")
    elif not is_open:
        print(f"  SKIP buys: market closed")
    else:
        # Check retraining
        check_retrain()

        tickers=get_tickers()
        print(f"  Universe: {len(tickers)}",flush=True)
        t0=time.time()
        scored=score_all(tickers)
        if scored.empty: print(f"  No scores"); pf.snap(date); pf.save(); return
        print(f"  Scored {len(scored)} in {time.time()-t0:.0f}s",flush=True)

        scored=scored[scored["p_sma_10"].fillna(0)>=2.0].copy()
        print(f"  Qualified: {len(scored)}",flush=True)
        if scored.empty: pf.snap(date); pf.save(); return

        top=scored.head(MAX_POS*2).copy()

        # Sector check: count current sector exposure
        sector_counts={}
        for po in pf.pos.values():
            sec=po.get("sec","Unknown")
            sector_counts[sec]=sector_counts.get(sec,0)+1
        total_slots=MAX_POS
        current_invested=sum(p["c"] for p in pf.pos.values()) + pf.equity - pf.cash  # approximate

        buys=0
        for _,row in top.iterrows():
            t=row["ticker"]
            if t in pf.pos or len(pf.pos)>=MAX_POS: continue
            sec=get_sector(t)
            # Sector cap: skip if would exceed 25% of portfolio in that sector
            current_sec_pct = (sector_counts.get(sec,0)+1) / MAX_POS * 100
            if current_sec_pct > MAX_SECTOR:
                continue

            price=float(row.get("p_sma_10",0))
            if price<=0: continue
            score=float(row["score"])
            sc_min=scored["score"].min(); sc_max=scored["score"].max()
            pctile=min(1.0,max(0,(score-sc_min)/max(sc_max-sc_min,1e-8)))
            vol=get_vol(t)
            shares,cost=pf.size(price,vol,pctile)
            if shares>0 and cost>0:
                pf.buy(t,price,shares,cost,vol,score,date)
                sector_counts[sec]=sector_counts.get(sec,0)+1
                print(f"  BUY {t}: {shares}sh ${price:.2f}=${cost:.0f} (r{pctile:.0%} v{vol:.1%} s{sec[:10]})",flush=True)
                buys+=1
        if buys==0: print(f"  No buys",flush=True)

    pf.snap(date); pf.save()
    s=pf.sum()
    print(f"\n  EQUITY:${s['eq']:,} P&L:{s['pl']:+,}({s['pl%']:+.1f}%) DD:{s['dd']:.1f}% N:{s['n']} T:{s['t']}",flush=True)
    print(f"{'='*60}\n",flush=True)

# ── Main ──
def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--once",action="store_true"); ap.add_argument("--capital",type=float,default=10000)
    ap.add_argument("--interval",type=int,default=60); ap.add_argument("--cycles",type=int,default=0)
    args=ap.parse_args()
    _sleep_lock(True)

    try: import xgboost
    except:
        print("Need xgboost. pip install xgboost"); sys.exit(1)

    # ── Startup checks ──
    print(f"  Startup validation...", flush=True)
    
    # Check model
    if not list(MODELS.glob("f_flag_v2_*.json")):
        print(f"  ⚠ No models found. Run pipeline first.")
        print(f"     python stockpredict2/scripts/train_v2.py")
        sys.exit(1)
    print(f"  ✓ Model: {sorted(MODELS.glob('f_flag_v2_s42_r*.json'))[-1].name}", flush=True)
    
    # Check sector map
    if not SECTOR_FILE.exists():
        print(f"  ⚠ No sector map. Run: python stockpredict2/scripts/fast_sector_map.py --batch=6000")
    else:
        with open(SECTOR_FILE) as f:
            sm = json.load(f)
        mapped = sum(1 for v in sm.values() if v != "Unknown")
        print(f"  ✓ Sector map: {mapped}/{len(sm)} tickers ({mapped/max(len(sm),1)*100:.0f}%)", flush=True)
    
    # Check tickers — auto-download if missing
    if not TICKER_FILE.exists():
        print(f"  ⚠ No ticker file — will download from NASDAQ on first cycle", flush=True)
    else:
        tlist = pd.read_parquet(TICKER_FILE)["symbol"].tolist()
        print(f"  ✓ Tickers: {len(tlist)}", flush=True)
    
    # Check data directories exist
    (DATA / "prices").mkdir(exist_ok=True)
    (DATA / "financials").mkdir(exist_ok=True)
    print(f"  ✓ Data dirs ready", flush=True)
    
    # Preload the model
    load_model()
    print(f"  ✓ System ready\n", flush=True)

    print(f"\n{'='*60}")
    print(f"  STOCKPREDICT2 — Paper Trader")
    print(f"  ${args.capital:,.0f} | Hold:{HOLD}d | SL:{STOP_LOSS}% | MaxSector:{MAX_SECTOR}%")
    print(f"  Verified: +8.7%/mo 78.1% win (2021-2026 backtest)")
    print(f"{'='*60}\n")

    pf=Portfolio(args.capital); cycle_n=0
    try:
        while True:
            cycle_n+=1
            if args.cycles and cycle_n>args.cycles: break
            cycle(pf,datetime.now().strftime("%Y-%m-%d"))
            if args.once: break
            for rem in range(args.interval*60,0,-60):
                if rem%600==0: print(f"  Next in {rem//60}m",flush=True)
                time.sleep(60)
    except KeyboardInterrupt: print("\n  Stopped.",flush=True)
    finally:
        pf.save(); _sleep_lock(False)
        s=pf.sum(); print(f"\n  Final: ${s['eq']:,} ({s['pl%']:+.1f}%) | {s['t']} trades\n")

if __name__=="__main__":
    main()