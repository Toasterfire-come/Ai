"""
NYSE/AMEX/NASDAQ Ticker Discovery — gets the full listed stock universe.
Sources: NASDAQ Trader HTTPS with FTP fallback.
Filters to common stocks only (no warrants, rights, ETFs, preferred shares).
"""
import csv, io, os, re
from pathlib import Path
from typing import Dict, List, Optional, Set, Tuple

import pandas as pd
import requests

from ..config import TICKERS_DIR

NASDAQ_TRADER_HTTPS = {
    "nasdaq": "https://www.nasdaqtrader.com/dynamic/SymDir/nasdaqlisted.txt",
    "other": "https://www.nasdaqtrader.com/dynamic/SymDir/otherlisted.txt",
}

NON_EQUITY_SUFFIXES = {
    ".WI", ".WT", ".W",      # warrants
    ".PR", ".PRA", ".PRB", ".PRC", ".PRD", ".PRE", ".PRF", ".PRG",  # preferred
    ".RT", ".RI",            # rights
    ".U", ".UN",             # units
    ".CL",                   # when-issued
}

EXCLUDED_SYMBOLS = set()


def fetch_nasdaq_listed() -> pd.DataFrame:
    return _fetch_ticker_file("nasdaq")


def fetch_other_listed() -> pd.DataFrame:
    return _fetch_ticker_file("other")


def _fetch_ticker_file(name: str) -> pd.DataFrame:
    url = NASDAQ_TRADER_HTTPS[name]
    try:
        resp = requests.get(url, timeout=30)
        if resp.status_code != 200:
            raise Exception(f"HTTP {resp.status_code}")
    except Exception:
        cached = TICKERS_DIR / f"{name}_listed.txt"
        if cached.exists():
            print(f"  Using cached ticker list: {cached}")
            with open(cached) as f:
                content = f.read()
        else:
            raise RuntimeError(f"Cannot fetch ticker list from {url}")

    content = resp.text
    cache_path = TICKERS_DIR / f"{name}_listed.txt"
    with open(cache_path, "w") as f:
        f.write(content)

    lines = content.strip().split("\n")
    reader = csv.DictReader(io.StringIO("\n".join(lines)), delimiter="|")
    rows = []
    for row in reader:
        if "File Creation Time" in row.get("Symbol", ""):
            continue
        rows.append(row)
    df = pd.DataFrame(rows)
    print(f"  {name}: {len(df)} symbols")
    return df


def get_all_listed(exchanges: List[str] = None,
                   exclude_etfs: bool = True,
                   exclude_preferred: bool = True,
                   save: bool = True) -> pd.DataFrame:
    """Get all listed common stocks from NYSE, NASDAQ, NYSE American."""
    nasdaq_df = fetch_nasdaq_listed()
    other_df = fetch_other_listed()

    def parse_nasdaq(row):
        return {
            "symbol": row.get("Symbol", "").strip(),
            "security_name": row.get("Security Name", ""),
            "exchange": "NASDAQ",
            "market_category": row.get("Market Category", ""),
            "etf": row.get("ETF", "").strip().lower() == "y",
            "financial_status": row.get("Financial Status", ""),
            "round_lot_size": row.get("Round Lot Size", 100),
        }

    exchange_map = {"N": "NYSE", "A": "NYSE American", "P": "NYSE ARCA", "Z": "BATS"}

    def parse_other(row):
        return {
            "symbol": row.get("ACT Symbol", "").strip(),
            "security_name": row.get("Security Name", ""),
            "exchange": exchange_map.get(row.get("Exchange", "").strip(), row.get("Exchange", "")),
            "market_category": "",
            "etf": row.get("ETF", "").strip().lower() == "y",
            "financial_status": "",
            "round_lot_size": row.get("Round Lot Size", 100),
        }

    all_stocks = pd.DataFrame(
        [parse_nasdaq(r) for _, r in nasdaq_df.iterrows()] +
        [parse_other(r) for _, r in other_df.iterrows()]
    )
    print(f"\nTotal before filtering: {len(all_stocks)}")

    before = len(all_stocks)
    if exclude_etfs:
        all_stocks = all_stocks[~all_stocks["etf"]]
        print(f"  After ETF filter: {len(all_stocks)} (removed {before - len(all_stocks)})")
        before = len(all_stocks)

    if exclude_preferred:
        pattern = r"^[A-Z]+(" + "|".join(re.escape(s) for s in NON_EQUITY_SUFFIXES) + r")$"
        mask = ~all_stocks["symbol"].str.match(pattern, na=False)
        all_stocks = all_stocks[mask]
        print(f"  After preferred/warrant filter: {len(all_stocks)} (removed {before - len(all_stocks)})")

    all_stocks = all_stocks[all_stocks["financial_status"].fillna("") != "D"]
    all_stocks = all_stocks[all_stocks["symbol"] != "TEST"]
    all_stocks = all_stocks[~all_stocks["symbol"].isin(EXCLUDED_SYMBOLS)]

    if exchanges:
        all_stocks = all_stocks[all_stocks["exchange"].str.lower().isin([e.lower() for e in exchanges])]

    # Only keep 1-5 char uppercase symbols (common stock pattern)
    common_stock = all_stocks["symbol"].str.match(r"^[A-Z]{1,5}$", na=False)
    n_removed = (~common_stock).sum()
    all_stocks = all_stocks[common_stock].reset_index(drop=True)
    print(f"  After symbol pattern filter: {len(all_stocks)} (removed {n_removed})")

    if save:
        path = TICKERS_DIR / "nyse.parquet"
        all_stocks.to_parquet(path)
        print(f"\nSaved {len(all_stocks)} tickers to {path}")
    return all_stocks


def load_ticker_list(source: str = None) -> pd.DataFrame:
    path = TICKERS_DIR / (source or "nyse.parquet")
    if not path.exists():
        return get_all_listed()
    return pd.read_parquet(path)


def get_ticker_symbols(exchange: str = None, n: int = None) -> List[str]:
    df = load_ticker_list()
    if exchange:
        df = df[df["exchange"].str.contains(exchange, case=False, na=False)]
    symbols = sorted(df["symbol"].unique().tolist())
    if n:
        symbols = symbols[:n]
    return symbols


def get_exchange_counts() -> Dict[str, int]:
    df = load_ticker_list()
    return df["exchange"].value_counts().to_dict()


if __name__ == "__main__":
    stocks = get_all_listed()
    print("\nBreakdown by exchange:")
    print(stocks["exchange"].value_counts().to_string())