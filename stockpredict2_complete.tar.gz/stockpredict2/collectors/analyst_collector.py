"""
Analyst Consensus Collector — Yahoo Finance Analysis page scrape.

Strategy:
  - Scrape Yahoo Finance /quote/{TICKER}/analysis/ page for consensus data
  - Extract: mean price target, low/high estimates, buy/hold/sell counts
  - Uses Selenium browser (same pattern as news collector) to bypass rate limits
  - Free, no API key required

Yahoo Finance provides analyst consensus on every US-listed stock for free.
The data is browser-accessible but has no official API — Selenium gives access.
"""
import json, time
from datetime import datetime
from typing import List, Optional, Tuple

import pandas as pd
import requests

from ..storage import CheckpointTracker, ParquetStore

PHASE = "analyst"
BROWSER_CHECKPOINT = 500  # restart browser every N tickers


def fetch_analyst_consensus_browser(ticker: str, driver=None) -> Optional[dict]:
    """
    Fetch analyst data from Yahoo Finance /analysis/ page via browser.
    """
    url = f"https://finance.yahoo.com/quote/{ticker}/analysis/"

    if driver is not None:
        try:
            driver.get(url)
            time.sleep(2)

            # Extract price target
            js_price = """
              const el = document.querySelector('[data-test="priceTarget-mean"]');
              return el ? el.textContent.trim() : null;
            """
            mean_target = driver.execute_script(js_price)

            js_low = """
              const el = document.querySelector('[data-test="priceTarget-low"]');
              return el ? el.textContent.trim() : null;
            """
            low_target = driver.execute_script(js_low)

            js_high = """
              const el = document.querySelector('[data-test="priceTarget-high"]');
              return el ? el.textContent.trim() : null;
            """
            high_target = driver.execute_script(js_high)

            # Extract recommendation breakdown
            js_recs = """
              const rows = document.querySelectorAll('table tr');
              const result = {};
              rows.forEach(row => {
                const cells = row.querySelectorAll('td, th');
                if (cells.length >= 2) {
                  const label = cells[0].textContent.trim();
                  const val = cells[1].textContent.trim();
                  if (label.match(/current|target|recommendation/i)) {
                    result[label] = val;
                  }
                }
              });
              return JSON.stringify(result);
            """
            recs_raw = driver.execute_script(js_recs)
            recs = json.loads(recs_raw) if recs_raw else {}

            result = {
                "ticker": ticker.upper(),
                "date": datetime.today().strftime("%Y-%m-%d"),
                "mean_price_target": _parse_num(mean_target),
                "low_estimate": _parse_num(low_target),
                "high_estimate": _parse_num(high_target),
                "recommendation": recs.get("Recommendation", ""),
                "current_price": _parse_num(recs.get("Current Price", "")),
                "target_upside_pct": None,
            }

            # Compute upside
            if result["mean_price_target"] and result["current_price"] and result["current_price"] > 0:
                result["target_upside_pct"] = round(
                    (result["mean_price_target"] / result["current_price"] - 1) * 100, 2
                )

            return result

        except Exception:
            return None

    return None


def fetch_analyst_consensus_http(ticker: str) -> Optional[dict]:
    """
    Fallback: extract from Yahoo Finance v8 API endpoint.
    This is rate-limited but doesn't need Selenium.
    """
    try:
        url = f"https://query1.finance.yahoo.com/v8/finance/chart/{ticker}"
        resp = requests.get(url, timeout=10,
            headers={"User-Agent": "Mozilla/5.0"})
        if resp.status_code != 200:
            return None

        data = resp.json()
        meta = data.get("chart", {}).get("result", [{}])[0].get("meta", {})
        current_price = meta.get("regularMarketPrice", meta.get("chartPreviousClose"))

        # Yahoo Finance v10 financial API for analyst data
        fin_url = f"https://query1.finance.yahoo.com/v10/finance/quoteSummary/{ticker}?modules=financialData"
        fin_resp = requests.get(fin_url, timeout=10,
            headers={"User-Agent": "Mozilla/5.0"})
        if fin_resp.status_code == 200:
            fin_data = fin_resp.json()
            fin = fin_data.get("quoteSummary", {}).get("result", [{}])[0].get("financialData", {})
            if isinstance(fin, dict):
                target_mean = fin.get("targetMeanPrice", {}).get("raw")
                target_low = fin.get("targetLowPrice", {}).get("raw")
                target_high = fin.get("targetHighPrice", {}).get("raw")
                rec = fin.get("recommendationKey", "")

                return {
                    "ticker": ticker.upper(),
                    "date": datetime.today().strftime("%Y-%m-%d"),
                    "mean_price_target": target_mean,
                    "low_estimate": target_low,
                    "high_estimate": target_high,
                    "recommendation": rec.title() if rec else "",
                    "current_price": current_price,
                    "target_upside_pct": round((target_mean / current_price - 1) * 100, 2)
                    if target_mean and current_price and current_price > 0 else None,
                }

    except Exception:
        return None

    return None


def _parse_num(s: Optional[str]) -> Optional[float]:
    if s is None:
        return None
    s = s.replace("+", "").replace("%", "").replace("$", "").replace(",", "").strip()
    try:
        return float(s)
    except (ValueError, TypeError):
        return None


def run_analyst_collection(tickers: List[str],
                            resume: bool = True,
                            use_browser: bool = False) -> dict:
    """
    Collect analyst consensus data for all tickers.

    Primary: Yahoo Finance /analysis/ page (via Selenium or direct HTTP)
    Free, unlimited for browser-based access.

    ~3 sec/ticker = ~5.5 hours for 6,589 tickers.
    """
    cp = CheckpointTracker()

    if resume:
        remaining = cp.get_remaining(PHASE, tickers)
        skipped = len(tickers) - len(remaining)
        print(f"  Analyst: {len(tickers)} total, {len(remaining)} remaining, "
              f"{skipped} done (resume)")
        tickers_to_process = remaining
    else:
        tickers_to_process = tickers

    if not tickers_to_process:
        print("  All analyst data already collected!")
        return {"total": len(tickers), "succeeded": 0}

    # Initialize browser if requested
    driver = None
    if use_browser:
        try:
            from selenium import webdriver
            from selenium.webdriver.chrome.options import Options
            opts = Options()
            opts.add_argument('--headless=new')
            opts.add_argument('--no-sandbox')
            opts.add_argument('--disable-dev-shm-usage')
            driver = webdriver.Chrome(options=opts)
            print("  Selenium browser initialized for analyst data")
        except Exception as e:
            print(f"  Selenium unavailable ({e}), using HTTP API")
            driver = None

    succeeded = 0
    empty = 0
    errors = 0
    start_time = time.time()

    try:
        for i, ticker in enumerate(tickers_to_process):
            t0 = time.time()

            try:
                if driver:
                    result = fetch_analyst_consensus_browser(ticker, driver)
                else:
                    result = fetch_analyst_consensus_http(ticker)

                if result:
                    df = pd.DataFrame([result])
                    ParquetStore.save_analyst(ticker, df)
                    cp.mark_completed(PHASE, ticker, rows=1)
                    succeeded += 1
                else:
                    cp.mark_completed(PHASE, ticker, rows=0)
                    empty += 1

            except Exception as e:
                cp.mark_error(PHASE, ticker, str(e)[:80])
                errors += 1

            elapsed = time.time() - t0
            if elapsed < 1.0:
                time.sleep(1.0 - elapsed)

            # Progress every 500
            if (i + 1) % 500 == 0:
                elapsed_total = time.time() - start_time
                rate = (i + 1) / (elapsed_total / 60)
                print(f"  [{i+1}/{len(tickers_to_process)}] "
                      f"({rate:.0f}/min, {succeeded} ok, {empty} empty, {errors} errors)")

    finally:
        if driver:
            try:
                driver.quit()
            except Exception:
                pass

    total_time = time.time() - start_time
    print(f"\n  Analyst: {succeeded} with data, {empty} no data, {errors} errors")
    print(f"  {total_time/60:.0f} min ({succeeded/max(total_time/60,0.01):.1f}/min)")

    return {"total": len(tickers), "succeeded": succeeded,
            "empty": empty, "errors": errors}