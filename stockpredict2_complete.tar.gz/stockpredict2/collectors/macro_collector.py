"""
Macro Collector — FRED economic indicators + yfinance market/sector ETFs.
Free, unlimited, covers the full macro picture.

FRED:      Download CSV from fred.stlouisfed.org (free, no API key for CSV)
Yahoo:     Download sector ETFs (XLF, XLK, etc.) and market benchmarks (SPY, VIX, TNX)
Sector:    11 sector ETFs for stock-vs-sector alpha computations
"""
import time
from datetime import datetime
from typing import Dict, List, Optional

import pandas as pd
import requests
import yfinance as yf

from ..config import MACRO_DIR, FRED_SERIES, SECTOR_ETFS, MARKET_ETFS

PHASE = "macro"


def download_fred_series(sid: str) -> Optional[pd.DataFrame]:
    """Download a single FRED series as CSV. Free, no API key."""
    url = f"https://fred.stlouisfed.org/graph/fredgraph.csv?id={sid}" \
          f"&cosd=2016-01-01&coed={datetime.today().strftime('%Y-%m-%d')}"
    try:
        resp = requests.get(url, timeout=30)
        if resp.status_code != 200:
            return None
        lines = resp.text.strip().split("\n")
        if len(lines) < 2:
            return None
        header = lines[0].split(",")
        if len(header) < 2:
            return None
        data = []
        for l in lines[1:]:
            parts = l.split(",")
            if len(parts) >= 2 and parts[1].strip() not in ("", "."):
                data.append((parts[0].strip(), float(parts[1].strip())))
        if not data:
            return None
        df = pd.DataFrame(data, columns=["date", sid])
        df["date"] = pd.to_datetime(df["date"]).dt.strftime("%Y-%m-%d")
        return df
    except Exception:
        return None


def download_etf_data(ticker: str, start: str = "2016-01-01") -> Optional[pd.Series]:
    """Download daily close prices for an ETF via yfinance."""
    try:
        df = yf.download(ticker, start=start, auto_adjust=True, progress=False)
        if df.empty:
            return None
        if isinstance(df.columns, pd.MultiIndex):
            close = df.xs("Close", axis=1, level=0).iloc[:, 0]
        else:
            close = df["Close"] if "Close" in df.columns else df.iloc[:, 0]
        return close.squeeze()
    except Exception:
        return None


def run_macro_collection(fred_only: bool = False, **kwargs) -> dict:
    """
    Collect all macro-economic data:
      - FRED economic indicators (employment, production, housing, sentiment, yields)
      - Market benchmarks (SPY, VIX, TNX, IRX, FVX, QQQ, IWM)
      - Sector ETFs (XLF, XLK, XLV, XLI, XLP, XLE, XLU, XLB, XLRE, XLC, XLY)

    FRED is free CSV download (no key needed).
    Sector/market ETFs from yfinance (free).
    Total: ~30 data series, ~5 minutes to collect.
    """
    results = {"fred": 0, "market_etfs": 0, "sector_etfs": 0}
    all_macro = None

    # ── Phase 1: FRED Economic Indicators ──
    print("\n1. FRED Economic Indicators...")
    saved = 0
    for sid, name in FRED_SERIES.items():
        path = MACRO_DIR / f"{sid}.parquet"
        if path.exists():
            print(f"  {sid} ({name}): cached, skipping")
            continue

        df = download_fred_series(sid)
        if df is not None:
            df.to_parquet(path, index=False)
            saved += 1
            print(f"  {sid} ({name}): {len(df)} rows \u2713")
        else:
            print(f"  {sid} ({name}): failed")
        time.sleep(0.5)
    results["fred"] = saved

    # ── Phase 2: Market Benchmarks ──
    print("\n2. Market Benchmarks (SPY, VIX, Yields)...")
    market_data = {}
    for ticker, col_name in MARKET_ETFS.items():
        close = download_etf_data(ticker)
        if close is not None:
            market_data[col_name] = close
            results["market_etfs"] += 1
            print(f"  {ticker:6s} \u2192 {col_name:15s}: {len(close)} days")
        else:
            print(f"  {ticker:6s} \u2192 failed")
        time.sleep(1.0)

    if market_data:
        market_df = pd.DataFrame(market_data)
        market_df.index = pd.to_datetime(market_df.index)
        market_df = market_df.sort_index().ffill()

        # Compute derived metrics
        if "SPY_CLOSE" in market_df.columns:
            market_df["SPY_RET_5D"] = market_df["SPY_CLOSE"].pct_change(5) * 100
            market_df["SPY_RET_21D"] = market_df["SPY_CLOSE"].pct_change(21) * 100
        if "VIX_CLOSE" in market_df.columns:
            market_df["VIX_PCTILE_252"] = market_df["VIX_CLOSE"].rolling(252).apply(
                lambda x: (x.iloc[-1] <= x).mean() * 100 if len(x) == 252 else 50
            )
        if "TNX_CLOSE" in market_df.columns and "IRX_CLOSE" in market_df.columns:
            market_df["YIELD_SPREAD_10Y_3M"] = market_df["TNX_CLOSE"] - market_df["IRX_CLOSE"]
        if "FVX_CLOSE" in market_df.columns and "IRX_CLOSE" in market_df.columns:
            market_df["YIELD_5Y_2Y"] = market_df["FVX_CLOSE"] - market_df["IRX_CLOSE"]
        if "QQQ_CLOSE" in market_df.columns and "SPY_CLOSE" in market_df.columns:
            market_df["QQQ_SPY_RATIO"] = market_df["QQQ_CLOSE"] / market_df["SPY_CLOSE"]
        if "IWM_CLOSE" in market_df.columns and "SPY_CLOSE" in market_df.columns:
            market_df["IWM_SPY_RATIO"] = market_df["IWM_CLOSE"] / market_df["SPY_CLOSE"]

        market_df = market_df.reset_index().rename(columns={"index": "date", "Date": "date"})
        market_df["date"] = pd.to_datetime(market_df["date"]).astype(str)
        market_df.to_parquet(MACRO_DIR / "market_benchmarks.parquet", index=False)
        print(f"  Market benchmarks saved: {len(market_df)} days x {len(market_df.columns)} cols")

    # ── Phase 3: Sector ETFs ──
    if not fred_only:
        print("\n3. Sector ETFs (XLB..XLY)...")
        sector_data = {}
        for ticker in SECTOR_ETFS:
            close = download_etf_data(ticker)
            if close is not None:
                col = f"SECTOR_{ticker}"
                sector_data[col] = close
                results["sector_etfs"] += 1
                print(f"  {ticker}: {len(close)} days")
            else:
                print(f"  {ticker}: failed")
            time.sleep(1.0)

        if sector_data:
            sector_df = pd.DataFrame(sector_data)
            sector_df.index = pd.to_datetime(sector_df.index)
            sector_df = sector_df.sort_index().ffill()

            # Daily returns for each sector
            for col in sector_data.keys():
                sector_df[f"{col}_RET_1D"] = sector_df[col].pct_change() * 100
                sector_df[f"{col}_RET_5D"] = sector_df[col].pct_change(5) * 100
                sector_df[f"{col}_RET_21D"] = sector_df[col].pct_change(21) * 100

            sector_df = sector_df.reset_index().rename(columns={"index": "date", "Date": "date"})
            sector_df["date"] = pd.to_datetime(sector_df["date"]).astype(str)
            sector_df.to_parquet(MACRO_DIR / "sector_etfs.parquet", index=False)
            print(f"  Sector ETFs saved: {len(sector_df)} days x {len(sector_df.columns)} cols")

    # Merge all saved series into one master file
    print("\n4. Merging all macro data...")
    merged = None

    for f in sorted(MACRO_DIR.glob("*.parquet")):
        df = pd.read_parquet(f)
        if "date" not in df.columns:
            continue
        df["date"] = pd.to_datetime(df["date"]).dt.strftime("%Y-%m-%d")
        if merged is None:
            merged = df
        else:
            merged = pd.merge(merged, df, on="date", how="outer")

    if merged is not None:
        merged = merged.sort_values("date").ffill().bfill().fillna(0)
        merged.to_parquet(MACRO_DIR / "master_macro.parquet", index=False)
        print(f"  Master macro: {len(merged)} rows x {len(merged.columns)} cols")

    print(f"\n  Macro Collection: {results['fred']} FRED, "
          f"{results['market_etfs']} market, {results['sector_etfs']} sector ETFs")
    return results