"""
News Collector — Yahoo Finance search API + Google News RSS.
No GDELT (too noisy). Yahoo Finance via browser JS gives proper ticker attribution.

Strategy:
  - Yahoo Finance v1 search API: 10 recent articles per ticker with official ticker tags
  - Google News RSS: broader coverage, free, unlimited
  - FinBERT sentiment on article titles
  - No GDELT (regex matching on 6K tickers produces too many false positives)
"""
import json, re, time
from collections import defaultdict
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Set

import numpy as np
import pandas as pd
import requests

from ..config import NEWS_AGG_DIR, DATA_START_DATE
from ..nlp.sentiment import SentimentAnalyzer
from ..storage import CheckpointTracker, ParquetStore
from ..config import COMMON_WORD_TICKERS

PHASE = "news"
BATCH_CHECKPOINT = 200  # save aggregated every N tickers


def fetch_yahoo_news_browser(ticker: str, driver=None) -> List[dict]:
    """
    Fetch news from Yahoo Finance v1 search API via browser JS execution.
    This bypasses rate limits because the request originates from the browser.
    If no driver provided, falls back to direct HTTP request (rate-limited).
    """
    url = f"https://query2.finance.yahoo.com/v1/finance/search?q={ticker}&newsCount=10"

    if driver is not None:
        js = f"""
          return await fetch('{url}')
            .then(r => r.json())
            .then(d => JSON.stringify((d.news || []).map(n => ({{
              title: n.title || '',
              date: n.providerPublishTime ? new Date(n.providerPublishTime * 1000).toISOString().split('T')[0] : '',
              publisher: n.publisher || '',
              link: n.link || '',
            }}))))
            .catch(e => JSON.stringify({{}}))
        """
        result = driver.execute_script(js)
        data = json.loads(result)
        if isinstance(data, dict) and 'error' in data:
            return []
        return data
    else:
        # Direct HTTP fallback — may be rate-limited but simpler
        try:
            resp = requests.get(url, timeout=10,
                headers={"User-Agent": "Mozilla/5.0"})
            if resp.status_code == 200:
                data = resp.json()
                articles = data.get("news", [])
                return [{
                    "title": a.get("title", ""),
                    "date": datetime.fromtimestamp(a.get("providerPublishTime", 0)).strftime("%Y-%m-%d")
                           if a.get("providerPublishTime") else "",
                    "publisher": a.get("publisher", ""),
                } for a in articles]
        except Exception:
            return []
    return []


def fetch_google_news_rss(ticker: str) -> List[dict]:
    """
    Fetch news headlines from Google News RSS for a ticker.
    Free, no API key, unlimited requests.
    Search format: "TICKER stock" or "TICKER shares"
    """
    articles = []
    for query in [f"{ticker} stock", f"{ticker} shares", f"{ticker} earnings"]:
        url = f"https://news.google.com/rss/search?q={query}&hl=en-US&gl=US&ceid=US:en"
        try:
            resp = requests.get(url, timeout=10,
                headers={"User-Agent": "Mozilla/5.0"})
            if resp.status_code != 200:
                continue

            # Parse RSS XML
            import xml.etree.ElementTree as ET
            root = ET.fromstring(resp.content)
            for item in root.findall(".//item"):
                title = item.findtext("title", "")
                pub_date = item.findtext("pubDate", "")
                source = item.findtext("source", "")

                # Parse RSS date format
                date_str = ""
                if pub_date:
                    try:
                        dt = datetime.strptime(pub_date, "%a, %d %b %Y %H:%M:%S %Z")
                        date_str = dt.strftime("%Y-%m-%d")
                    except ValueError:
                        date_str = pub_date[:10]

                if title and ticker.upper() in title.upper():
                    articles.append({
                        "title": title,
                        "date": date_str,
                        "publisher": source or "Google News",
                    })

            # Short delay between queries
            time.sleep(0.5)
        except Exception:
            continue

        # If we found enough from one query, stop
        if len(articles) >= 10:
            break

    return articles[:10]


def run_news_collection(tickers: List[str] = None,
                         resume: bool = True,
                         use_google_news: bool = True,
                         use_yahoo_browser: bool = False) -> dict:
    """
    Collect news sentiment for all tickers.

    Two sources:
      1. Yahoo Finance search API (preferred — proper ticker attribution)
      2. Google News RSS (free, broader coverage, fallback)

    The old GDELT approach is dropped — its regex-based ticker matching
    on 6K+ symbols produced unacceptable false positive rates.

    FinBERT sentiment is applied to article titles.
    Results saved as per-ticker aggregated parquet.
    """
    analyzer = SentimentAnalyzer()
    cp = CheckpointTracker()

    if tickers is None:
        from .ticker_list import get_ticker_symbols
        tickers = get_ticker_symbols()

    if resume:
        remaining = cp.get_remaining(PHASE, tickers)
        skipped = len(tickers) - len(remaining)
        print(f"  News: {len(tickers)} total, {len(remaining)} remaining, "
              f"{skipped} done (resume)")
        tickers_to_process = remaining
    else:
        tickers_to_process = tickers

    if not tickers_to_process:
        print("  All news already collected!")
        return {"total": len(tickers), "succeeded": 0}

    # Initialize Selenium browser if using Yahoo browser method
    driver = None
    if use_yahoo_browser:
        try:
            from selenium import webdriver
            from selenium.webdriver.chrome.options import Options
            opts = Options()
            opts.add_argument('--headless=new')
            opts.add_argument('--no-sandbox')
            opts.add_argument('--disable-dev-shm-usage')
            driver = webdriver.Chrome(options=opts)
            driver.get('https://finance.yahoo.com/')
            time.sleep(3)
            print("  Selenium browser initialized for Yahoo Finance news")
        except Exception as e:
            print(f"  Selenium unavailable ({e}), using HTTP fallback for Yahoo Finance")
            driver = None

    succeeded = 0
    total_articles = 0
    start_time = time.time()

    try:
        for i, ticker in enumerate(tickers_to_process):
            t0 = time.time()
            articles = []

            # Try Yahoo Finance first (proper ticker attribution)
            yahoo_articles = fetch_yahoo_news_browser(ticker, driver)
            articles.extend(yahoo_articles)

            # Fall back to Google News for broader coverage
            if use_google_news and len(articles) < 3:
                google_articles = fetch_google_news_rss(ticker)
                articles.extend(google_articles)
                time.sleep(0.3)  # be polite to Google

            if articles:
                # Deduplicate by title
                seen_titles = set()
                unique = []
                for a in articles:
                    title = a.get("title", "").strip()
                    if title and title not in seen_titles:
                        seen_titles.add(title)
                        unique.append(a)
                articles = unique

                # Run FinBERT on titles
                titles = [a.get("title", "") for a in articles if a.get("title")]
                sentiments = analyzer.score(titles)

                # Build aggregated row
                dates = [a.get("date", "") for a in articles]
                pos = [s["pos"] for s in sentiments]
                neg = [s["neg"] for s in sentiments]
                neu = [s["neu"] for s in sentiments]

                today_str = datetime.today().strftime("%Y-%m-%d")

                row = {
                    "ticker": ticker,
                    "date": today_str,
                    "article_count": len(articles),
                    "latest_article_date": max(d for d in dates if d) if any(dates) else today_str,
                    "sentiment_pos": sum(pos) / len(pos),
                    "sentiment_neg": sum(neg) / len(neg),
                    "sentiment_neu": sum(neu) / len(neu),
                }

                # Save article-level data
                articles_df = pd.DataFrame([{
                    "ticker": ticker,
                    "date": a.get("date", today_str),
                    "title": a.get("title", "")[:200],
                    "publisher": a.get("publisher", ""),
                    "sentiment_pos": sentiments[j]["pos"],
                    "sentiment_neg": sentiments[j]["neg"],
                    "sentiment_neu": sentiments[j]["neu"],
                } for j, a in enumerate(articles) if a.get("title")])

                ParquetStore.save_news_aggregated(ticker, articles_df)
                total_articles += len(articles)
                succeeded += 1
            else:
                # No articles found — still mark as completed
                succeeded += 1

            cp.mark_completed(PHASE, ticker, rows=len(articles))

            # Progress report
            if (i + 1) % 100 == 0:
                rate = (i + 1) / max((time.time() - start_time), 1) * 60
                print(f"  [{i+1}/{len(tickers_to_process)}] {ticker}: "
                      f"{len(articles)} articles ({rate:.0f}/min)")

            # Brief pause between tickers
            elapsed = time.time() - t0
            if elapsed < 0.5:
                time.sleep(0.5 - elapsed)

            # Restart browser periodically to prevent memory leaks
            if driver and i > 0 and i % 500 == 0:
                driver.quit()
                time.sleep(2)
                from selenium import webdriver
                from selenium.webdriver.chrome.options import Options
                opts = Options()
                opts.add_argument('--headless=new')
                opts.add_argument('--no-sandbox')
                opts.add_argument('--disable-dev-shm-usage')
                driver = webdriver.Chrome(options=opts)
                driver.get('https://finance.yahoo.com/')
                time.sleep(3)
                print(f"  Browser restarted at ticker {i}")

    finally:
        if driver:
            try:
                driver.quit()
            except Exception:
                pass

    total_time = time.time() - start_time
    print(f"\n  News: {succeeded} tickers processed, {total_articles} articles")
    print(f"  {total_time/60:.0f} min")

    return {"total": len(tickers), "succeeded": succeeded,
            "articles": total_articles, "minutes": total_time / 60}


def news_stats(tickers: List[str]) -> dict:
    """Aggregate stats on collected news data."""
    in_news = set(p.stem for p in NEWS_AGG_DIR.glob("*.parquet"))
    total_articles = 0
    for path in NEWS_AGG_DIR.glob("*.parquet"):
        total_articles += len(pd.read_parquet(path))
    return {
        "tickers_with_news": len(in_news),
        "total_articles": total_articles,
        "pct_coverage": f"{len(in_news) / max(len(tickers), 1) * 100:.1f}%" if tickers else "?",
    }