"""
Price Collector — one-time bulk backfill via CSV/Kaggle, then daily yfinance updates.

Strategy (from cheapest to most practical):
  1. One-time backfill from a pre-compiled CSV or parquet of historical prices
     (Kaggle datasets, downloadable from SEC/CRSP mirrors, or yfinance bulk).
  2. Daily incremental updates via yfinance — only fetch dates newer than what's stored.
  3. Technical indicators computed from stored prices (no extra API calls).

For the free path: yfinance at ~7.5 tickers/min covers all 6.6K tickers in ~14 hours
one-time. Then daily updates are just a few minutes.
"""
import time
from datetime import datetime
from typing import List, Optional, Tuple

import numpy as np
import pandas as pd
import yfinance as yf

from ..config import DATA_START_DATE, PRICES_DIR, YFINANCE_DELAY, YFINANCE_BATCH_SIZE, YFINANCE_BATCH_WAIT
from ..storage import CheckpointTracker, ParquetStore

PHASE = "prices"
MAX_RETRIES = 3
REPORT_EVERY = 100


def download_ticker(ticker: str) -> Tuple[bool, str, pd.DataFrame]:
    """Download price data for one ticker via yfinance. Fresh Ticker per call."""
    for attempt in range(MAX_RETRIES):
        try:
            t = yf.Ticker(ticker)
            df = t.history(period="10y", auto_adjust=True, actions=True)
            if df is not None and not df.empty:
                return True, "ok", df
            return False, "empty", pd.DataFrame()
        except Exception as e:
            err = str(e)
            if "429" in err or "Rate limited" in err or "Too Many" in err:
                if attempt < MAX_RETRIES - 1:
                    time.sleep(30 * (attempt + 1))
                    continue
                return False, "rate_limited", pd.DataFrame()
            if "No data" in err:
                return False, "no_data", pd.DataFrame()
            if attempt < MAX_RETRIES - 1:
                time.sleep(5)
                continue
            return False, f"error: {err[:80]}", pd.DataFrame()
    return False, "failed", pd.DataFrame()


def process_ticker_df(ticker: str, df: pd.DataFrame) -> pd.DataFrame:
    """Normalize downloaded DataFrame to consistent schema."""
    df = df.reset_index()
    if isinstance(df.columns, pd.MultiIndex):
        df.columns = [c[0].lower().replace(" ", "_") for c in df.columns]
    else:
        df.columns = [c.lower().replace(" ", "_") for c in df.columns]

    rename = {"stock_splits": "stock_split", "dividends": "dividend"}
    df = df.rename(columns={k: v for k, v in rename.items() if k in df.columns})
    if "adj_close" not in df.columns:
        df["adj_close"] = df.get("close", 0.0)

    if "index" in df.columns:
        df = df.rename(columns={"index": "date"})
    df["date"] = pd.to_datetime(df["date"]).dt.strftime("%Y-%m-%d")
    df = df.sort_values("date").dropna(subset=["close"])

    expected = ["date", "open", "high", "low", "close", "volume",
                "adj_close", "dividend", "stock_split"]
    for c in expected:
        if c not in df.columns:
            df[c] = 0.0 if c != "date" else ""
    return df[expected]


def run_price_collection(tickers: List[str],
                         start: str = DATA_START_DATE,
                         resume: bool = True,
                         quiet: bool = False,
                         incremental_only: bool = False) -> dict:
    """
    Full price collection via yfinance.

    If incremental_only=True and a ticker has existing parquet data, only fetches
    dates newer than the stored max date (faster daily updates).

    For the initial backfill, set incremental_only=False (default) to get 10-year history.
    """
    checkpoint = CheckpointTracker()

    if resume:
        remaining = checkpoint.get_remaining(PHASE, tickers)
        skipped = len(tickers) - len(remaining)
        if not quiet:
            print(f"  Prices: {len(tickers)} total, {len(remaining)} remaining, "
                  f"{skipped} already done (resume)")
        tickers_to_process = remaining
    else:
        tickers_to_process = tickers

    if not tickers_to_process:
        print("  All price data already collected!")
        return {"total": len(tickers), "succeeded": 0, "skipped": skipped}

    succeeded, empty_count, rate_limited, errors = 0, 0, 0, 0
    total_rows = 0
    start_time = time.time()

    for i, ticker in enumerate(tickers_to_process):
        # Rate limiting: pause between batches
        if i > 0 and i % YFINANCE_BATCH_SIZE == 0:
            elapsed = time.time() - start_time
            rate = i / (elapsed / 60)
            remaining_time = (len(tickers_to_process) - i) / rate if rate > 0 else 0
            if not quiet:
                print(f"\n  Batch pause {YFINANCE_BATCH_WAIT}s (rate limit reset)... "
                      f"({rate:.1f}/min, est {remaining_time:.0f}m remaining)\n")
            time.sleep(YFINANCE_BATCH_WAIT)

        t0 = time.time()
        success, status, df = download_ticker(ticker)

        if success and not df.empty:
            cleaned = process_ticker_df(ticker, df)

            if incremental_only and ParquetStore.price_exists(ticker):
                existing = ParquetStore.load_price(ticker)
                if not existing.empty:
                    max_known = existing["date"].max()
                    cleaned = cleaned[cleaned["date"] > max_known]

            if not cleaned.empty:
                ParquetStore.save_price(ticker, cleaned)
                checkpoint.mark_completed(PHASE, ticker, rows=len(cleaned))
                succeeded += 1
                total_rows += len(cleaned)
                if not quiet:
                    print(f"  [{i+1}/{len(tickers_to_process)}] {ticker}: "
                          f"{len(cleaned)}d ({cleaned['date'].iloc[0]}→{cleaned['date'].iloc[-1]})")
            else:
                # Already up to date
                checkpoint.mark_completed(PHASE, ticker, rows=0)
                succeeded += 1
        elif status in ("empty", "no_data"):
            checkpoint.mark_completed(PHASE, ticker, rows=0)
            empty_count += 1
        elif status == "rate_limited":
            checkpoint.mark_error(PHASE, ticker, "rate_limited")
            rate_limited += 1
            if not quiet:
                print(f"  [{i+1}/{len(tickers_to_process)}] {ticker}: RATE LIMITED")
            time.sleep(YFINANCE_BATCH_WAIT)
        else:
            checkpoint.mark_error(PHASE, ticker, status)
            errors += 1

        elapsed = time.time() - t0
        if elapsed < YFINANCE_DELAY:
            time.sleep(YFINANCE_DELAY - elapsed)

        if (i + 1) % REPORT_EVERY == 0 and not quiet:
            elapsed_total = time.time() - start_time
            rate = (i + 1) / (elapsed_total / 60)
            print(f"\n  [{i+1}/{len(tickers_to_process)}] "
                  f"({rate:.1f}/min, {succeeded} ok, {empty_count} empty, "
                  f"{rate_limited} rl, {errors} err)\n")

    total_time = time.time() - start_time
    print(f"\n  Price Collection: {succeeded} ok, {empty_count} empty, "
          f"{rate_limited} rate-limited, {errors} err")
    print(f"  {total_rows:,} rows in {total_time/60:.0f} min "
          f"({succeeded/max(total_time/60,0.01):.1f}/min)")

    return {"total": len(tickers), "succeeded": succeeded,
            "empty": empty_count, "rate_limited": rate_limited,
            "errors": errors, "rows": total_rows, "minutes": total_time/60}


def compute_technical_indicators(ticker: str) -> pd.DataFrame:
    """Compute technical indicators from stored price data. No API calls needed."""
    df = ParquetStore.load_price(ticker)
    if df.empty or len(df) < 20:
        return df
    df = df.sort_values("date").copy()
    close = df["close"].astype(float)

    for w in [10, 20, 50, 200]:
        df[f"sma_{w}"] = close.rolling(w).mean()
    df["ema_12"] = close.ewm(span=12, adjust=False).mean()
    df["ema_26"] = close.ewm(span=26, adjust=False).mean()
    df["macd"] = df["ema_12"] - df["ema_26"]
    df["macd_signal"] = df["macd"].ewm(span=9, adjust=False).mean()

    delta = close.diff()
    gain = delta.where(delta > 0, 0.0).rolling(14).mean()
    loss = (-delta.where(delta < 0, 0.0)).rolling(14).mean()
    rs = gain / loss.replace(0, 1e-10)
    df["rsi_14"] = 100 - (100 / (1 + rs))

    df["bb_mid"] = close.rolling(20).mean()
    bb_std = close.rolling(20).std()
    df["bb_width"] = 2 * bb_std / df["bb_mid"].replace(0, 1e-10)

    high_low = df["high"].astype(float) - df["low"].astype(float)
    high_close = (df["high"].astype(float) - close.shift(1)).abs()
    low_close = (df["low"].astype(float) - close.shift(1)).abs()
    tr = pd.concat([high_low, high_close, low_close], axis=1).max(axis=1)
    df["atr_14"] = tr.rolling(14).mean()
    df["vol_sma_20"] = df["volume"].astype(float).rolling(20).mean()
    df["vol_ratio"] = df["volume"].astype(float) / df["vol_sma_20"].replace(0, 1)
    df["pct_change_1d"] = close.pct_change() * 100
    df["pct_change_5d"] = close.pct_change(5) * 100
    df["pct_change_21d"] = close.pct_change(21) * 100
    df["pct_change_63d"] = close.pct_change(63) * 100
    df["volatility_21d"] = df["pct_change_1d"].rolling(21).std()
    df["volatility_63d"] = df["pct_change_1d"].rolling(63).std()
    df["adx_14"] = 100 * tr.rolling(14).mean() / close.replace(0, 1e-10)

    ParquetStore.save_price(ticker, df)
    return df


def compute_all_technical_indicators(tickers: List[str]):
    """Compute technical indicators for all tickers that have price data."""
    count = 0
    for t in tickers:
        if ParquetStore.price_exists(t):
            df = compute_technical_indicators(t)
            if not df.empty:
                count += 1
    print(f"  Indicators computed for {count} tickers")


def price_data_stats(tickers: List[str]) -> dict:
    """Aggregate stats on collected price data."""
    total_rows, total_tickers = 0, 0
    min_date, max_date = None, None
    for t in tickers:
        df = ParquetStore.load_price(t)
        if not df.empty:
            total_rows += len(df)
            total_tickers += 1
            dmin, dmax = df["date"].min(), df["date"].max()
            if min_date is None or dmin < min_date:
                min_date = dmin
            if max_date is None or dmax > max_date:
                max_date = dmax
    return {
        "tickers": total_tickers,
        "rows": total_rows,
        "date_range": f"{min_date} → {max_date}" if min_date else "N/A",
        "avg_days": total_rows // max(total_tickers, 1),
    }