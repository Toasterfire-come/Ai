"""
SEC Form 4 Insider Trade Collector — downloads all insider transactions since 2016.
Uses SEC EDGAR quarterly master index files — efficient batch processing.

Source: https://www.sec.gov/Archives/edgar/full-index/{year}/QTR{quarter}/master.gz
Free and unlimited. Process recent quarters first (more valuable data).
"""
import gzip, json, re, time
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import pandas as pd
import requests
import xml.etree.ElementTree as ET

from ..config import FORM4_DIR, DATA_DIR
from ..storage import ParquetStore

PHASE = "form4"
HEADERS = {'User-Agent': 'StockPredictBot/2.0 (ckiefer@dropkit.me)'}
BASE = "https://www.sec.gov/Archives/edgar/full-index"
SEC_RATE = 0.15  # 150ms between requests (polite ~7/sec)


def download_master_index(year: int, quarter: int) -> Optional[str]:
    """Download SEC master index gzip for a quarter."""
    url = f"{BASE}/{year}/QTR{quarter}/master.gz"
    for attempt in range(2):
        try:
            r = requests.get(url, headers=HEADERS, timeout=300, stream=True)
            if r.status_code == 200:
                content = b""
                for chunk in r.iter_content(chunk_size=8192):
                    if chunk:
                        content += chunk
                print(f"  Downloaded {year} Q{quarter}: {len(content):,} bytes", flush=True)
                return gzip.decompress(content).decode("latin-1")
            else:
                print(f"  {year} Q{quarter}: HTTP {r.status_code}", flush=True)
                return None
        except requests.Timeout:
            print(f"  {year} Q{quarter}: timeout (attempt {attempt+1})", flush=True)
        except Exception as e:
            print(f"  {year} Q{quarter}: {e}", flush=True)
            return None
    return None


def parse_master_index(content: str) -> List[dict]:
    """Parse SEC master index, return Form 4 filings only."""
    filings = []
    for line in content.split("\n"):
        parts = line.split("|")
        if len(parts) >= 5 and parts[2].strip() == "4":
            filings.append({
                "cik": parts[0].strip().zfill(10),
                "company": parts[1].strip(),
                "form": parts[2].strip(),
                "date": parts[3].strip(),
                "filename": parts[4].strip(),
            })
    return filings


def download_form4(filename: str) -> Optional[str]:
    """Download a Form 4 filing and extract embedded XML."""
    url = f"https://www.sec.gov/Archives/{filename}"
    try:
        r = requests.get(url, headers=HEADERS, timeout=30)
        if r.status_code != 200:
            return None
        m = re.search(r'<XML>\s*(.*?)\s*</XML>', r.text, re.DOTALL)
        return m.group(1) if m else r.text
    except Exception:
        return None


def parse_form4_xml(xml_text: str, ticker: str = "") -> List[dict]:
    """Extract transactions from Form 4 XML text."""
    transactions = []
    try:
        if not ticker:
            m = re.search(r'<tradingSymbol>([^<]+)', xml_text)
            if m:
                ticker = m.group(1).strip().upper()
            if not ticker:
                m = re.search(r'<issuerTradingSymbol>([^<]+)', xml_text)
                if m:
                    ticker = m.group(1).strip().upper()
        if not ticker:
            return []

        # Owner info
        owner_name = ""
        m = re.search(r'<rptOwnerName>([^<]+)', xml_text)
        if m:
            owner_name = m.group(1).strip()

        is_director = bool(re.search(r'<isDirector>\s*1\s*</isDirector>', xml_text))
        is_officer = bool(re.search(r'<isOfficer>\s*1\s*</isOfficer>', xml_text))
        is_tenpct = bool(re.search(r'<isTenPercentOwner>\s*1\s*</isTenPercentOwner>', xml_text))

        officer_title = ""
        m = re.search(r'<officerTitle>([^<]+)', xml_text)
        if m:
            officer_title = m.group(1).strip()

        relationship = "Other"
        if is_director:
            relationship = "Director"
        if is_officer:
            relationship = f"Officer ({officer_title})" if officer_title else "Officer"
        if is_tenpct:
            relationship = "10% Owner"

        # Parse non-derivative transactions
        for table_match in re.finditer(
            r'<nonDerivativeTable>(.*?)</nonDerivativeTable>', xml_text, re.DOTALL
        ):
            table = table_match.group(1)
            tx_date = ""
            m = re.search(r'<transactionDate>\s*<value>(\d{4}-\d{2}-\d{2})', table)
            if m:
                tx_date = m.group(1)

            tx_code = ""
            m = re.search(r'<transactionCode>([PSADFG])</transactionCode>', table)
            if m:
                tx_code = m.group(1)

            shares = 0
            m = re.search(r'<transactionShares>\s*<value>([\d.]+)', table)
            if m:
                shares = float(m.group(1))

            price = 0.0
            m = re.search(r'<transactionPricePerShare>\s*<value>([\d.]+)', table)
            if m:
                price = float(m.group(1))

            if tx_date and shares > 0:
                transactions.append({
                    "ticker": ticker,
                    "owner": owner_name,
                    "relationship": relationship,
                    "transaction_date": tx_date,
                    "transaction_code": tx_code,
                    "transaction_type": {"P": "Buy", "S": "Sell", "A": "Grant",
                                         "D": "Sale to Issuer"}.get(tx_code, tx_code),
                    "shares": int(shares),
                    "price": round(price, 2),
                    "value": round(shares * price, 2),
                })
    except Exception:
        pass

    return transactions


def run_form4_collection(resume: bool = True, **kwargs) -> dict:
    """
    Download all Form 4 insider transactions from 2016-present.
    Processes recent quarters first (most valuable data).

    Uses parallel workers (10 threads) for filing downloads.
    CIK-to-ticker mapping from SEC's company_tickers.json.
    """
    from ..collectors.ticker_list import load_ticker_list

    # Load known tickers
    ticker_df = load_ticker_list()
    known_tickers = set(ticker_df["symbol"].unique()) if not ticker_df.empty else set()
    print(f"Form 4: {len(known_tickers)} known tickers", flush=True)

    # Load or download CIK→ticker mapping
    cik_path = DATA_DIR / "cik_map.json"
    if cik_path.exists():
        import json as _json
        with open(cik_path) as f:
            cik_to_ticker = _json.load(f)
        print(f"  CIK map: {len(cik_to_ticker)} tickers (cached)", flush=True)
    else:
        print("  Downloading CIK map from SEC...", flush=True)
        cik_url = "https://www.sec.gov/files/company_tickers.json"
        cik_to_ticker = {}
        for attempt in range(3):
            try:
                resp = requests.get(cik_url, headers=HEADERS, timeout=60)
                if resp.status_code == 200:
                    data = resp.json()
                    for entry in data.values():
                        t = entry.get("ticker", "").upper()
                        cik = str(entry.get("cik_str", "")).zfill(10)
                        if t and cik:
                            cik_to_ticker[cik] = t
                    import json as _json
                    with open(cik_path, "w") as f:
                        _json.dump(cik_to_ticker, f)
                    print(f"  CIK map: {len(cik_to_ticker)} tickers (downloaded)", flush=True)
                    break
                else:
                    print(f"  CIK download: HTTP {resp.status_code}, retrying...", flush=True)
            except Exception as e:
                print(f"  CIK download: {e}, retrying...", flush=True)
            time.sleep(5 * (attempt + 1))

    known_ciks = set(cik_to_ticker.keys())
    print(f"  Known CIKs: {len(known_ciks):,}", flush=True)

    # Determine quarters to process
    current_year = datetime.today().year
    current_quarter = (datetime.today().month - 1) // 3 + 1

    quarters = []
    for year in range(2016, current_year + 1):
        for q in range(1, 5):
            if year == current_year and q > current_quarter:
                break
            quarters.append((year, q))
    quarters.reverse()  # recent first
    print(f"  Quarters: {len(quarters)} (processing recent first)", flush=True)

    all_transactions = []
    total_searched = 0

    for year, qtr in quarters:
        check_file = DATA_DIR / f"form4_quarter_{year}_q{qtr}.done"
        if check_file.exists():
            print(f"  {year} Q{qtr}: already done, skipping", flush=True)
            continue

        print(f"\n{year} Q{qtr}: downloading master index...", flush=True)
        content = download_master_index(year, qtr)
        if not content:
            continue
        time.sleep(SEC_RATE)

        filings = parse_master_index(content)
        targeted = [f for f in filings if f["cik"] in known_ciks]
        print(f"  Form 4: {len(filings):,} total \u2192 {len(targeted):,} targeted", flush=True)
        total_searched += len(filings)

        batch_tx = 0
        batch_tickers = set()

        def process_filing(filing):
            xml = download_form4(filing["filename"])
            if not xml:
                return []
            return parse_form4_xml(xml, cik_to_ticker.get(filing["cik"], ""))

        with ThreadPoolExecutor(max_workers=10) as pool:
            futures = {pool.submit(process_filing, f): f for f in targeted}
            for i, future in enumerate(as_completed(futures)):
                tx_list = future.result()
                if tx_list:
                    all_transactions.extend(tx_list)
                    batch_tx += len(tx_list)
                    for t in tx_list:
                        batch_tickers.add(t["ticker"])

                if (i + 1) % 5000 == 0:
                    print(f"  {i+1}/{len(targeted)} processed, "
                          f"{len(all_transactions):,} transactions", flush=True)

        print(f"  \u2192 {batch_tx} transactions, {len(batch_tickers)} tickers", flush=True)

        if all_transactions:
            df = pd.DataFrame(all_transactions)
            df.to_parquet(FORM4_DIR / "form4_all.parquet", index=False)
            print(f"  Saved: {len(df):,} tx, {df['ticker'].nunique():,} tickers", flush=True)

        check_file.touch()
        time.sleep(3)

    # Final save and per-ticker breakdown
    if all_transactions:
        df = pd.DataFrame(all_transactions)
        path = FORM4_DIR / "form4_all.parquet"
        df.to_parquet(path, index=False)
        print(f"\nFinal: {len(df):,} insider transactions")
        print(f"  Tickers: {df['ticker'].nunique():,}")
        print(f"  By type: {df['transaction_type'].value_counts().to_dict()}")

        # Also save per-ticker parquet files for easy merge into FM
        for ticker, group in df.groupby("ticker"):
            ParquetStore.save_form4(ticker, group.reset_index(drop=True))

        return {"total_transactions": len(df), "tickers": df["ticker"].nunique(),
                "quarters_processed": len(quarters), "filings_searched": total_searched}

    print("No transactions found")
    return {"total_transactions": 0}