"""
Fundamentals Collector — SEC EDGAR XBRL (10-K/10-Q quarterly financials).
Free, official, time-series going back 10+ years.

Strategy:
  - Use the SEC EDGAR full-text search API to find 10-K and 10-Q filings for each ticker
  - Download the XBRL (iXBRL or inline XBRL) filing
  - Parse standardized GAAP concepts: Revenue, COGS, SG&A, R&D, Total Assets,
    Current Assets, Total Liabilities, Current Liabilities, Cash, Debt, Equity,
    Operating Cash Flow, Capex, Free Cash Flow, etc.
  - Store as quarterly time-series per ticker

This replaces yfinance Ticker.info (which is a single snapshot) with proper
quarterly financial statements going back 10+ years.

SEC EDGAR is free and unlimited — just be polite (max 10 req/sec).
"""
import json, re, time
from datetime import datetime
from typing import Dict, List, Optional, Tuple
from pathlib import Path

import pandas as pd
import requests
import xml.etree.ElementTree as ET

from ..storage import CheckpointTracker, ParquetStore
from ..config import SEC_RATE_DELAY, DATA_DIR

PHASE = "fundamentals"

HEADERS = {'User-Agent': 'StockPredictBot/2.0 (research project; ckiefer@dropkit.me)'}

# Standard GAAP concept mapping — these are the XBRL tags used in SEC filings
# Maps readable names to common XBRL element names
FUNDAMENTAL_FIELDS = {
    # Income Statement
    "revenue": [
        "RevenueFromContractWithCustomerExcludingAssessedTax",
        "RevenueTotal",
        "Revenues",
        "SalesRevenueNet",
        "TotalRevenue",
    ],
    "cost_of_revenue": [
        "CostOfRevenue",
        "CostOfGoodsSold",
        "CostOfGoodsAndServicesSold",
    ],
    "gross_profit": [
        "GrossProfit",
    ],
    "sga_expense": [
        "SellingGeneralAndAdministrativeExpense",
        "SellingAndMarketingExpense",
    ],
    "research_development": [
        "ResearchAndDevelopmentExpense",
        "ResearchDevelopmentExpense",
    ],
    "operating_income": [
        "OperatingIncomeLoss",
        "IncomeLossFromContinuingOperationsBeforeIncomeTaxesExtraordinaryItemsNoncontrollingInterest",
    ],
    "net_income": [
        "NetIncomeLoss",
        "ProfitLoss",
        "NetIncomeLossAvailableToCommonStockholdersBasic",
    ],
    "ebitda": [
        "EarningsBeforeInterestTaxesDepreciationAndAmortization",
    ],
    # Balance Sheet
    "total_assets": [
        "Assets",
        "AssetsTotal",
    ],
    "current_assets": [
        "AssetsCurrent",
        "CurrentAssets",
    ],
    "cash_and_equivalents": [
        "CashAndCashEquivalentsAtCarryingValue",
        "CashCashEquivalentsRestrictedCashAndRestrictedCashEquivalents",
        "CashEquivalentsAtCarryingValue",
    ],
    "total_liabilities": [
        "Liabilities",
        "LiabilitiesTotal",
    ],
    "current_liabilities": [
        "LiabilitiesCurrent",
        "CurrentLiabilities",
    ],
    "long_term_debt": [
        "LongTermDebtNoncurrent",
        "LongTermDebt",
        "DebtLongTermAndCapitalLeaseObligations",
    ],
    "total_equity": [
        "StockholdersEquity",
        "StockholdersEquityIncludingPortionAttributableToNoncontrollingInterest",
        "Equity",
    ],
    "retained_earnings": [
        "RetainedEarningsAccumulatedDeficit",
        "RetainedEarnings",
    ],
    # Cash Flow Statement
    "operating_cash_flow": [
        "NetCashProvidedByUsedInOperatingActivities",
        "CashProvidedByUsedInOperatingActivitiesContinuingOperations",
    ],
    "capital_expenditures": [
        "PaymentsToAcquirePropertyPlantAndEquipment",
        "CapitalExpendituresIncurredButNotYetPaid",
    ],
    "free_cash_flow": [
        # Computed: OCF - Capex
    ],
    # Per Share
    "eps_basic": [
        "EarningsPerShareBasic",
        "EarningsPerShareBasicWeightedAverage",
    ],
    "eps_diluted": [
        "EarningsPerShareDiluted",
        "EarningsPerShareDilutedWeightedAverage",
    ],
    # Context
    "shares_outstanding": [
        "WeightedAverageNumberOfSharesOutstandingBasic",
        "CommonStockSharesOutstanding",
    ],
}


def _safe_float(v) -> Optional[float]:
    if v is None:
        return None
    try:
        return float(v.replace(",", ""))
    except (ValueError, AttributeError):
        return None


def _search_sec_edgar(ticker: str, form_type: str = "10-K") -> List[dict]:
    """
    Search SEC EDGAR for filings of a given type for a ticker.
    Uses SEC's full-text search API (free, no key required).
    """
    # Use the EFTS (EDGAR Full Text Search) API
    url = "https://efts.sec.gov/LATEST/search-index"
    params = {
        "q": f"ticker:{ticker.upper()} AND form-type:{form_type}",
        "dateRange": "all",
        "from": 0,
        "size": 50,  # max 10 years of quarters
    }
    try:
        resp = requests.get(url, params=params, headers=HEADERS, timeout=30)
        if resp.status_code != 200:
            return []
        data = resp.json()
        hits = data.get("hits", {}).get("hits", []) if isinstance(data, dict) else []
        results = []
        for hit in hits:
            src = hit.get("_source", {})
            if isinstance(src, dict):
                results.append({
                    "form": src.get("form_type", ""),
                    "filing_date": src.get("file_date", ""),
                    "period_end": src.get("period_ending", ""),
                    "cik": src.get("cik", ""),
                    "company": src.get("display_names", [""])[0] if src.get("display_names") else "",
                })
        return results
    except Exception as e:
        print(f"  SEC search error for {ticker} {form_type}: {e}")
        return []


def _fetch_xbrl_filing(cik: str, filing_date: str) -> Optional[str]:
    """
    Fetch the XBRL/XML content of a filing from SEC EDGAR.
    Returns the raw XML text.
    """
    # The SEC EDGAR filing URL pattern:
    # https://www.sec.gov/Archives/edgar/data/{CIK}/{accession}/{primary-document}
    # We need to first find the filing directory
    cik_padded = cik.zfill(10)
    accession_base = filing_date.replace("-", "")  # rough approximation

    # For simplicity, use the SEC's xbrl API endpoint
    # Note: This is a simplified approach. Real implementation would follow
    # the filing chain from the master index.
    # For now, we rely on the filing metadata from the search API.
    return None  # Placeholder — needs proper SEC URL construction


def run_fundamentals_collection(tickers: List[str],
                                 resume: bool = True,
                                 quiet: bool = False,
                                 test_mode: bool = False) -> dict:
    """
    Collect fundamental data from SEC EDGAR Company Facts API.
    Uses pre-parsed XBRL data for each ticker — 10+ years of quarterly financials.

    SEC Company Facts API: https://data.sec.gov/api/xbrl/companyfacts/CIK{cik}.json
    Free, unlimited, official GAAP statements going back 15+ years.

    Each ticker returns ALL XBRL facts (50+ GAAP concepts per quarter).
    ~1.5 sec/ticker = ~2.5 hours for 6,589 tickers.
    """
    return run_fundamentals_collection_from_facts(
        tickers, resume=resume, quiet=quiet, test_mode=test_mode
    )


def fetch_company_facts(ticker: str, cik: str = None) -> Optional[pd.DataFrame]:
    """
    Fetch company facts from SEC's Company Facts API.
    This is the preferred method — SEC provides pre-parsed XBRL data.

    URL: https://data.sec.gov/api/xbrl/companyfacts/CIK{cik_padded}.json
    Returns all XBRL facts for the company in a structured JSON format.

    Free, no API key, just polite rate limiting (10 req/sec).
    """
    if not cik:
        return None
    cik_padded = cik.zfill(10)
    url = f"https://data.sec.gov/api/xbrl/companyfacts/CIK{cik_padded}.json"

    try:
        resp = requests.get(url, headers=HEADERS, timeout=30)
        if resp.status_code != 200:
            return None

        data = resp.json()
        facts = data.get("facts", {}).get("us-gaap", {})

        # Build a DataFrame from all numeric facts
        all_rows = []
        for concept_name, concept_data in facts.items():
            for unit_data in concept_data.get("units", {}).values():
                for point in unit_data:
                    all_rows.append({
                        "concept": concept_name,
                        "date": point.get("end", ""),
                        "value": point.get("val"),
                        "filed": point.get("filed", ""),
                        "fy": point.get("fy"),
                        "fp": point.get("fp"),  # FY/Q1/Q2/Q3/Q4
                        "frame": point.get("frame", ""),
                    })

        if not all_rows:
            return None

        df = pd.DataFrame(all_rows)

        # Filter to key GAAP concepts and reshape to wide format per quarter
        key_concepts = set()
        for field, tags in FUNDAMENTAL_FIELDS.items():
            for tag in tags:
                key_concepts.add(tag)

        df_key = df[df["concept"].isin(key_concepts)].copy()
        if df_key.empty:
            # Fall back to all concepts if key ones not found
            df_key = df

        # Pivot: one row per (date, fp) with concepts as columns
        df_key = df_key.dropna(subset=["date", "value"])
        df_key["date"] = df_key["date"].str[:10]

        # Keep the latest value for each concept per quarter
        df_key = df_key.sort_values("filed").drop_duplicates(
            subset=["concept", "date"], keep="last"
        )

        pivot = df_key.pivot_table(
            index=["date", "fp"],
            columns="concept",
            values="value",
            aggfunc="first",
        ).reset_index()

        # Flatten columns
        pivot.columns = [str(c).replace(" ", "_") if c else str(c) for c in pivot.columns]
        pivot["ticker"] = ticker

        return pivot

    except Exception as e:
        print(f"  Company facts error for {ticker}: {e}")
        return None


def run_fundamentals_collection_from_facts(tickers: List[str],
                                            resume: bool = True,
                                            quiet: bool = False,
                                            test_mode: bool = False) -> dict:
    """
    Alternative fundamentals collection using SEC Company Facts API.
    This gives pre-parsed XBRL data — far richer than the search API approach.

    Requires a CIK-to-ticker mapping (downloaded from SEC).
    ~2 sec/ticker for 6,589 tickers ≈ 3.6 hours.
    """
    cp = CheckpointTracker()
    phase = PHASE + "_facts"

    if resume:
        remaining = cp.get_remaining(phase, tickers)
        skipped = len(tickers) - len(remaining)
        if not quiet:
            print(f"  Fundamentals (SEC Facts): {len(tickers)} total, "
                  f"{len(remaining)} remaining, {skipped} done")
        tickers_to_process = remaining
    else:
        tickers_to_process = tickers

    if not tickers_to_process:
        print("  All fundamentals already collected!")
        return {"total": len(tickers), "succeeded": 0}

    # Load CIK map
    cik_path = DATA_DIR / "cik_map.json"
    if cik_path.exists():
        with open(cik_path) as f:
            cik_to_ticker = json.load(f)
        # Reverse: ticker -> cik
        ticker_to_cik = {v.upper(): k for k, v in cik_to_ticker.items()}
    else:
        print("  Downloading CIK map from SEC...")
        url = "https://www.sec.gov/files/company_tickers.json"
        resp = requests.get(url, headers=HEADERS, timeout=60)
        if resp.status_code == 200:
            data = resp.json()
            ticker_to_cik = {}
            for entry in data.values():
                t = entry.get("ticker", "").upper()
                cik = str(entry.get("cik_str", "")).zfill(10)
                if t and cik:
                    ticker_to_cik[t] = cik
            with open(cik_path, "w") as f:
                json.dump({v: k for k, v in ticker_to_cik.items()}, f)
            if not quiet:
                print(f"  CIK map: {len(ticker_to_cik)} tickers")
        else:
            print(f"  Failed to download CIK map (HTTP {resp.status_code})")
            return {"total": len(tickers), "succeeded": 0, "error": "no CIK map"}

    succeeded, empty, errors = 0, 0, 0
    start_time = time.time()

    for i, ticker in enumerate(tickers_to_process):
        t0 = time.time()
        cik = ticker_to_cik.get(ticker.upper())

        if not cik:
            cp.mark_completed(phase, ticker, rows=0)
            empty += 1
            continue

        try:
            df = fetch_company_facts(ticker, cik)
            if df is not None and not df.empty:
                ParquetStore.save_financial(ticker, df)
                cp.mark_completed(phase, ticker, rows=len(df))
                succeeded += 1
                if not quiet and succeeded % 500 == 1:
                    print(f"  [{i+1}/{len(tickers_to_process)}] {ticker}: {len(df)} financial periods")
            else:
                cp.mark_completed(phase, ticker, rows=0)
                empty += 1

        except Exception as e:
            cp.mark_error(phase, ticker, str(e)[:100])
            errors += 1

        elapsed = time.time() - t0
        if elapsed < SEC_RATE_DELAY:
            time.sleep(SEC_RATE_DELAY - elapsed)

        # Progress every 500
        if (i + 1) % 500 == 0 and not quiet:
            elapsed_total = time.time() - start_time
            rate = (i + 1) / (elapsed_total / 60)
            remaining_t = (len(tickers_to_process) - i - 1) / rate
            print(f"  [{i+1}/{len(tickers_to_process)}] "
                  f"({rate:.0f}/min, {succeeded} ok, {empty} empty, {errors} err, "
                  f"~{remaining_t:.0f} min remaining)")

    total_time = time.time() - start_time
    print(f"\n  Fundamentals (SEC Facts): {succeeded} ok, {empty} empty, {errors} err")
    print(f"  {total_time/60:.0f} min ({succeeded/max(total_time/60,0.01):.1f}/min)")

    return {"total": len(tickers), "succeeded": succeeded,
            "empty": empty, "errors": errors}