#!/usr/bin/env python3
"""
Windows Paper Trader Entry Point.
No macOS-specific code. No cron. No pmset. No lid-detect.
Concurrent data fetching using ThreadPoolExecutor + aiohttp-style asyncio.

Usage:
    python windows_trader.py                         # Run continuously (hourly cycles)
    python windows_trader.py --once                  # Single cycle
    python windows_trader.py --interval 30           # 30 min between cycles
    python windows_trader.py --cycles 10             # Max 10 cycles then stop
    python windows_trader.py --capital 50000         # Start with $50,000

On Windows, schedule with Task Scheduler to run at startup:
    Trigger: At startup
    Action: python C:\...\stockpredict2\windows_trader.py --once
    Repeat every: 1 hour indefinitely
"""
import sys, os
from pathlib import Path

# Add project to path (parent too for package imports)
_root = Path(__file__).resolve().parent
sys.path.insert(0, str(_root))
sys.path.insert(0, str(_root.parent))

if __name__ == "__main__":
    # Set multiprocessing start method for Windows compatibility
    if sys.platform == "win32":
        import multiprocessing
        multiprocessing.set_start_method("spawn", force=True)

    # Run paper trader
    from trader.paper_trader import main
    main()