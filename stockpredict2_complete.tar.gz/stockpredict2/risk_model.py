"""
Risk Model — quality screens and risk-adjusted scoring for stock selection.

Filters (all must pass):
  1. Price >= $5 (no penny stocks)
  2. Equity >= $300M (no micro-caps)
  3. Avg daily volume >= 100K shares (liquidity)
  4. Volatility < 80th percentile (cap extreme vol)

Risk-adjusted score:
  base_score = ensemble consensus score
  risk_penalty = weighted blend of relative vol, beta, drawdown, volatility trend
  final_score = base_score * (1 - 0.3 * risk_penalty)

Position sizing by market cap band:
  $300M-$1B: max 3%
  $1B-$10B:  max 6%
  $10B+:     max 10%

For configurable thresholds, import and pass parameters:
  apply_risk_filters(df, min_price=5.0, min_equity=300e6, min_volume=100000)
"""
import numpy as np
import pandas as pd

from .config import RISK_DEFAULTS

# Default thresholds (overridable via kwargs)
MIN_PRICE = RISK_DEFAULTS["min_price"]
MIN_EQUITY = RISK_DEFAULTS["min_equity"]
MIN_VOLUME = RISK_DEFAULTS["min_volume"]
VOL_CAP_PCTILE = RISK_DEFAULTS["max_vol_percentile"]
RISK_PENALTY_WEIGHT = RISK_DEFAULTS["risk_penalty_weight"]


def apply_risk_filters(df, **kwargs):
    """Apply quality/risk pre-filters. Returns boolean mask."""
    min_price = kwargs.get("min_price", MIN_PRICE)
    min_equity = kwargs.get("min_equity", MIN_EQUITY)
    min_volume = kwargs.get("min_volume", MIN_VOLUME)
    vol_pctile = kwargs.get("vol_cap_pctile", VOL_CAP_PCTILE)

    mask = pd.Series(True, index=df.index)

    n_fail_price = 0
    n_fail_equity = 0
    n_fail_vol = 0
    n_fail_volcap = 0

    if "p_sma_10" in df.columns:
        price_ok = df["p_sma_10"].fillna(0) >= min_price
        mask &= price_ok
        n_fail_price = (~price_ok).sum()

    if "f_equity" in df.columns:
        equity_ok = df["f_equity"].fillna(0) >= min_equity
        mask &= equity_ok
        n_fail_equity = (~equity_ok).sum()

    if "p_vol_sma_20" in df.columns:
        vol_ok = df["p_vol_sma_20"].fillna(0) >= min_volume
        mask &= vol_ok
        n_fail_vol = (~vol_ok).sum()

    if "z_ivol" in df.columns:
        ivol = df["z_ivol"].values
        threshold = np.percentile(ivol[~np.isnan(ivol)], vol_pctile * 100)
        vol_cap_ok = df["z_ivol"].fillna(0) <= threshold
        mask &= vol_cap_ok
        n_fail_volcap = (~vol_cap_ok).sum()
    elif "p_volatility_21d" in df.columns:
        ivol = df["p_volatility_21d"].fillna(0).values
        threshold = np.percentile(ivol, vol_pctile * 100)
        vol_cap_ok = df["p_volatility_21d"].fillna(0) <= threshold
        mask &= vol_cap_ok
        n_fail_volcap = (~vol_cap_ok).sum()

    n_pass = mask.sum()
    print(f"  Risk filters: {n_pass}/{len(df)} pass  "
          f"(price<${min_price}: {n_fail_price}, "
          f"equity<${min_equity/1e6:.0f}M: {n_fail_equity}, "
          f"vol<{min_volume/1000:.0f}K: {n_fail_vol}, "
          f"volcap: {n_fail_volcap})", flush=True)

    return mask


def compute_risk_scores(df):
    """Compute composite risk score (0=low risk, 1=high risk)."""
    risk_factors = []

    if "z_ivol" in df.columns:
        risk_factors.append(df["z_ivol"].fillna(0).values)
    elif "p_volatility_21d" in df.columns:
        v = df["p_volatility_21d"].fillna(0).values
        risk_factors.append((v - v.mean()) / max(v.std(), 1e-8))

    if "z_beta" in df.columns:
        risk_factors.append(df["z_beta"].fillna(0).values)
    elif "rsi_mom" in df.columns:
        v = df["rsi_mom"].fillna(0).values
        risk_factors.append((v - v.mean()) / max(v.std(), 1e-8))

    if "z_max_dd_90d" in df.columns:
        risk_factors.append(df["z_max_dd_90d"].fillna(0).values)
    if "z_vol_trend" in df.columns:
        risk_factors.append(df["z_vol_trend"].fillna(0).values)

    if not risk_factors:
        return np.zeros(len(df))

    risk_score = np.zeros(len(df))
    for vals in risk_factors:
        clipped = np.clip(vals, -3, 3)
        normalized = (clipped - clipped.min()) / max(clipped.max() - clipped.min(), 1e-8)
        risk_score += normalized
    risk_score /= len(risk_factors)
    return risk_score


def compute_risk_adjusted_score(ensemble_scores, risk_scores, weight=RISK_PENALTY_WEIGHT):
    """final_score = ensemble_score * (1 - weight * risk_score)"""
    return ensemble_scores * (1.0 - weight * risk_scores)


def get_risk_sizing(risk_scores, max_weight=0.10, min_weight=0.02):
    """Position sizing inversely proportional to risk."""
    inv_risk = 1.0 - risk_scores
    weights = min_weight + (max_weight - min_weight) * inv_risk
    weights /= weights.sum()
    return weights


def get_mcap_band_sizing(equity_values):
    """Market-cap band position sizing."""
    weights = np.ones(len(equity_values), dtype=np.float32) * 0.02
    for i, eq in enumerate(equity_values):
        if np.isfinite(eq) and eq >= 10e9:
            weights[i] = 0.10
        elif np.isfinite(eq) and eq >= 1e9:
            weights[i] = 0.06
        elif np.isfinite(eq) and eq >= 300e6:
            weights[i] = 0.03
        else:
            weights[i] = 0.01
    weights /= weights.sum()
    return weights


def apply_full_risk_model(df, ensemble_scores, **kwargs):
    """Run full risk model pipeline: filter → score → adjust → size."""
    df = df.copy()
    df["ensemble_score"] = ensemble_scores
    mask = apply_risk_filters(df, **kwargs)
    filtered = df[mask].copy()
    risk_scores = compute_risk_scores(filtered)
    filtered["risk_score"] = risk_scores
    adjusted = compute_risk_adjusted_score(filtered["ensemble_score"].values, risk_scores)
    filtered["risk_adjusted_score"] = adjusted
    sizes = get_risk_sizing(risk_scores)
    filtered["position_weight"] = sizes
    stats = {
        "n_total": len(df),
        "n_passed": len(filtered),
        "n_failed": len(df) - len(filtered),
        "pass_rate": len(filtered) / len(df) if len(df) > 0 else 0,
        "avg_risk_score": float(np.mean(risk_scores)) if len(risk_scores) > 0 else 0,
    }
    return filtered, stats