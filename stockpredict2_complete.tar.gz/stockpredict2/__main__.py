#!/usr/bin/env python3
"""
stockpredict2 — Data pipeline CLI.

Usage:
    python -m stockpredict2 pipeline run          Run full data pipeline
    python -m stockpredict2 pipeline status       Show collection progress
    python -m stockpredict2 pipeline tickers      Discover and save ticker list
    python -m stockpredict2 build-fm              Build feature matrix from all sources
"""

from .cli import main

if __name__ == "__main__":
    main()