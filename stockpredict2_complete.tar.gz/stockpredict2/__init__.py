"""
stockpredict2 — High-quality training data pipeline for equity selection.

Data sources:
  - Prices:    Yahoo Finance (yfinance) with one-time Kaggle backfill
  - Financials: SEC EDGAR XBRL (10-K/10-Q quarterly time-series)
  - News:      Yahoo Finance search API + Google News RSS
  - Analyst:   Yahoo Finance Analysis page consensus
  - Macro:     FRED economic indicators + yfinance sector ETFs
  - Insiders:  SEC Form 4 filings via EDGAR
  - Events:    SEC 8-K filing event timeline
"""